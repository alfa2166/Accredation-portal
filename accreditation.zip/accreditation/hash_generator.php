<?php
// Use this file to generate a password hash.
// Replace 'password123' with the password you want to hash.
$passwordToHash = 'password123';

// Hash the password
$hashedPassword = password_hash($passwordToHash, PASSWORD_DEFAULT);

// Display the hash. Copy this entire string and paste it into the `password` column in phpMyAdmin.
echo "Password: " . $passwordToHash . "<br>";
echo "Hashed Value: " . $hashedPassword;
?>