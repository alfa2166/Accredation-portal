<?php
session_start();
require_once 'config/db.php';

// Security check: only HODs can perform these actions
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'HOD') {
    $_SESSION['message'] = ['type' => 'error', 'text' => 'Access Denied.'];
    header("Location: index.php");
    exit();
}

$hod_department_id = $_SESSION['user_department_id'];

if (isset($_POST['action'])) {

    // --- ACTION: HOD ADDS A NEW FACULTY MEMBER ---
    if ($_POST['action'] == 'add_faculty') {
        $name = trim($_POST['name']);
        $email = trim($_POST['email']);
        $employee_id = !empty(trim($_POST['employee_id'])) ? trim($_POST['employee_id']) : null;
        $password = $_POST['password'];
        $job_description_id = !empty($_POST['job_description_id']) ? $_POST['job_description_id'] : null;
        $role_id = 4; // Hard-coded to 'Faculty' role

        if (empty($name) || empty($email) || empty($password)) {
            $_SESSION['message'] = ['type' => 'error', 'text' => 'Name, Email, and Password are required.'];
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $sql = "INSERT INTO users (name, email, employee_id, password, role_id, department_id, job_description_id) VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmt = $mysqli->prepare($sql);
            $stmt->bind_param("ssssiii", $name, $email, $employee_id, $hashed_password, $role_id, $hod_department_id, $job_description_id);

            if ($stmt->execute()) {
                $_SESSION['message'] = ['type' => 'success', 'text' => 'Faculty member added successfully.'];
                
                // Get job description name for notification
                $job_description_name = 'Not assigned';
                if ($job_description_id) {
                    $stmt_jd = $mysqli->prepare("SELECT name FROM job_descriptions WHERE id = ?");
                    $stmt_jd->bind_param("i", $job_description_id);
                    $stmt_jd->execute();
                    $jd_result = $stmt_jd->get_result()->fetch_assoc();
                    if ($jd_result) {
                        $job_description_name = $jd_result['name'];
                    }
                    $stmt_jd->close();
                }
                
                // Create detailed notification
                $message = "New faculty member '{$name}' has been added to your department.";
                $detailed_message = $message . "\n\nDetails:\n";
                $detailed_message .= "• Name: {$name}\n";
                $detailed_message .= "• Email: {$email}\n";
                $detailed_message .= "• Employee ID: " . ($employee_id ?? 'Not set') . "\n";
                $detailed_message .= "• Job Description: {$job_description_name}\n";
                $detailed_message .= "• Role: Faculty\n";
                
                // Insert notification for the HOD
                $stmt_notify = $mysqli->prepare("INSERT INTO notifications (user_id, message, link) VALUES (?, ?, ?)");
                $link = 'hod_dashboard.php#faculty';
                $stmt_notify->bind_param("iss", $_SESSION['user_id'], $detailed_message, $link);
                $stmt_notify->execute();
                $stmt_notify->close();
                
            } else {
                $_SESSION['message'] = ['type' => 'error', 'text' => 'Error: Could not add faculty. Email or Employee ID may already exist.'];
            }
            $stmt->close();
        }
        header("Location: hod_dashboard.php#faculty");
        exit();
    }

    // --- ACTION: HOD EDITS AN EXISTING FACULTY MEMBER ---
    if ($_POST['action'] == 'edit_faculty') {
        $faculty_id = $_POST['faculty_id'];
        $name = trim($_POST['name']);
        $email = trim($_POST['email']);
        $employee_id = !empty(trim($_POST['employee_id'])) ? trim($_POST['employee_id']) : null;
        $job_description_id = !empty($_POST['job_description_id']) ? $_POST['job_description_id'] : null;

        if (empty($faculty_id) || empty($name) || empty($email)) {
             $_SESSION['message'] = ['type' => 'error', 'text' => 'Name and Email are required.'];
        } else {
            // Get current faculty data for comparison
            $stmt_old = $mysqli->prepare("
                SELECT u.*, jd.name as job_description_name
                FROM users u
                LEFT JOIN job_descriptions jd ON u.job_description_id = jd.id
                WHERE u.id = ? AND u.department_id = ?
            ");
            $stmt_old->bind_param("ii", $faculty_id, $hod_department_id);
            $stmt_old->execute();
            $old_faculty_data = $stmt_old->get_result()->fetch_assoc();
            $stmt_old->close();
            
            $sql = "UPDATE users SET name = ?, email = ?, employee_id = ?, job_description_id = ? WHERE id = ? AND department_id = ?";
            $stmt = $mysqli->prepare($sql);
            $stmt->bind_param("sssiii", $name, $email, $employee_id, $job_description_id, $faculty_id, $hod_department_id);

            if ($stmt->execute()) {
                $_SESSION['message'] = ['type' => 'success', 'text' => 'Faculty details updated successfully.'];
                
                // Get updated faculty data for comparison
                $stmt_new = $mysqli->prepare("
                    SELECT u.*, jd.name as job_description_name
                    FROM users u
                    LEFT JOIN job_descriptions jd ON u.job_description_id = jd.id
                    WHERE u.id = ? AND u.department_id = ?
                ");
                $stmt_new->bind_param("ii", $faculty_id, $hod_department_id);
                $stmt_new->execute();
                $new_faculty_data = $stmt_new->get_result()->fetch_assoc();
                $stmt_new->close();
                
                // Compare changes
                $changes = [];
                if ($old_faculty_data['name'] !== $name) {
                    $changes['Name'] = ['old' => $old_faculty_data['name'], 'new' => $name];
                }
                if ($old_faculty_data['email'] !== $email) {
                    $changes['Email'] = ['old' => $old_faculty_data['email'], 'new' => $email];
                }
                if ($old_faculty_data['employee_id'] !== $employee_id) {
                    $changes['Employee ID'] = [
                        'old' => $old_faculty_data['employee_id'] ?? 'Not set',
                        'new' => $employee_id ?? 'Not set'
                    ];
                }
                if ($old_faculty_data['job_description_id'] !== $job_description_id) {
                    $changes['Job Description'] = [
                        'old' => $old_faculty_data['job_description_name'] ?? 'Not assigned',
                        'new' => $new_faculty_data['job_description_name'] ?? 'Not assigned'
                    ];
                }
                
                // Create detailed notification if there are changes
                if (!empty($changes)) {
                    $message = "Faculty details for '{$name}' have been updated.";
                    $detailed_message = $message . "\n\nChanges made:\n";
                    foreach ($changes as $field => $change) {
                        $detailed_message .= "• {$field}: {$change['old']} → {$change['new']}\n";
                    }
                    
                    // Insert notification for the HOD
                    $stmt_notify = $mysqli->prepare("INSERT INTO notifications (user_id, message, link) VALUES (?, ?, ?)");
                    $link = 'hod_dashboard.php#faculty';
                    $stmt_notify->bind_param("iss", $_SESSION['user_id'], $detailed_message, $link);
                    $stmt_notify->execute();
                    $stmt_notify->close();
                }
                
            } else {
                $_SESSION['message'] = ['type' => 'error', 'text' => 'Error: Could not update faculty details.'];
            }
            $stmt->close();
        }
        header("Location: hod_dashboard.php#faculty");
        exit();
    }

    if ($action === 'mark_notification_read' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $notification_id = $_POST['notification_id'];
        if (!empty($notification_id)) {
            $stmt = $mysqli->prepare("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?");
            $stmt->bind_param("ii", $notification_id, $_SESSION['user_id']);
            $stmt->execute();
            $stmt->close();
        }
        // Respond with a success status
        http_response_code(200);
        exit();
    }
}

// Fallback redirect if file is accessed directly
header("Location: hod_dashboard.php");
exit();
?>