<?php
// Test file to demonstrate the approval system
// This file can be used to test the document approval workflow

require_once 'config/db.php';

echo "<h1>Document Approval System Test</h1>";
echo "<p>This page demonstrates the approval system functionality.</p>";

// Check if pending_updates table exists
$table_check = $mysqli->query("SHOW TABLES LIKE 'pending_updates'");
if ($table_check->num_rows > 0) {
    echo "<div style='background: #d4edda; color: #155724; padding: 10px; border-radius: 4px; margin: 10px 0;'>";
    echo "✓ pending_updates table exists";
    echo "</div>";
} else {
    echo "<div style='background: #f8d7da; color: #721c24; padding: 10px; border-radius: 4px; margin: 10px 0;'>";
    echo "✗ pending_updates table does not exist";
    echo "</div>";
}

// Show current pending requests
echo "<h2>Current Pending Requests</h2>";
$pending_query = "
    SELECT 
        pu.*, 
        u.name AS requester_name,
        CASE 
            WHEN pu.update_type = 'criterion_template' THEN c.name 
            ELSE m.name 
        END as target_name
    FROM pending_updates pu
    JOIN users u ON pu.requested_by_user_id = u.id
    LEFT JOIN criteria c ON pu.target_id = c.id AND pu.update_type = 'criterion_template'
    LEFT JOIN metrics m ON pu.target_id = m.id AND pu.update_type = 'metric_attachment'
    ORDER BY pu.requested_at DESC
";

$result = $mysqli->query($pending_query);

if ($result && $result->num_rows > 0) {
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr style='background: #f8f9fa;'>";
    echo "<th>ID</th><th>Type</th><th>Target</th><th>Requester</th><th>Status</th><th>Requested</th><th>File</th>";
    echo "</tr>";
    
    while ($row = $result->fetch_assoc()) {
        $status_color = $row['status'] === 'Pending' ? '#fff3cd' : ($row['status'] === 'Approved' ? '#d4edda' : '#f8d7da');
        echo "<tr style='background: $status_color;'>";
        echo "<td>{$row['id']}</td>";
        echo "<td>{$row['update_type']}</td>";
        echo "<td>{$row['target_name']}</td>";
        echo "<td>{$row['requester_name']}</td>";
        echo "<td>{$row['status']}</td>";
        echo "<td>" . date('d M, Y H:i', strtotime($row['requested_at'])) . "</td>";
        echo "<td>{$row['original_filename']}</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>No pending requests found.</p>";
}

// Show statistics
echo "<h2>Approval Statistics</h2>";
$stats_query = "SELECT status, COUNT(*) as count FROM pending_updates GROUP BY status";
$stats_result = $mysqli->query($stats_query);

if ($stats_result && $stats_result->num_rows > 0) {
    echo "<div style='display: flex; gap: 20px; margin: 20px 0;'>";
    while ($stat = $stats_result->fetch_assoc()) {
        $color = $stat['status'] === 'Pending' ? '#ffc107' : ($stat['status'] === 'Approved' ? '#28a745' : '#dc3545');
        echo "<div style='background: $color; color: white; padding: 15px; border-radius: 8px; text-align: center;'>";
        echo "<div style='font-size: 2rem; font-weight: bold;'>{$stat['count']}</div>";
        echo "<div>{$stat['status']}</div>";
        echo "</div>";
    }
    echo "</div>";
}

echo "<h2>How to Test the System</h2>";
echo "<ol>";
echo "<li><strong>As a Criterion Lead:</strong> Log in to the lead dashboard and go to 'Manage Metric Documents' or 'Manage Task Format' sections.</li>";
echo "<li><strong>Submit a Request:</strong> Upload a new file to replace an existing document. This will create a pending request.</li>";
echo "<li><strong>As an Admin:</strong> Log in to the admin dashboard and go to the 'Approval Hub' section.</li>";
echo "<li><strong>Review Requests:</strong> You'll see all pending requests with options to approve or reject them.</li>";
echo "<li><strong>Take Action:</strong> Click 'Approve' or 'Reject' with optional remarks.</li>";
echo "<li><strong>Check Status:</strong> The lead can check the status of their requests in their dashboard.</li>";
echo "</ol>";

echo "<h2>Key Features</h2>";
echo "<ul>";
echo "<li>✓ Secure file upload with unique naming</li>";
echo "<li>✓ Admin approval workflow</li>";
echo "<li>✓ Status tracking (Pending, Approved, Rejected)</li>";
echo "<li>✓ Remarks and feedback system</li>";
echo "<li>✓ File comparison (new vs current)</li>";
echo "<li>✓ Statistics and filtering</li>";
echo "<li>✓ Email notifications (can be added)</li>";
echo "</ul>";

echo "<p><a href='admin_dashboard.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px;'>Go to Admin Dashboard</a></p>";
echo "<p><a href='lead_dashboard.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px;'>Go to Lead Dashboard</a></p>";
?> 