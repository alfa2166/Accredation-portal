<?php
require_once 'includes/auth_check.php';
require_once 'config/db.php';

// Security: Only allow HODs to view this page and get their details
if ($_SESSION['user_role'] !== 'HOD') {
    die("Access Denied.");
}
$department_id = $_SESSION['user_department_id'];
$hod_id = $_SESSION['user_id'];

// Fetch job descriptions from the database for the forms
$job_descriptions_array = $mysqli->query("SELECT * FROM job_descriptions ORDER BY name")->fetch_all(MYSQLI_ASSOC);

$page_title = 'HOD Dashboard';
require_once 'includes/header.php';
echo '<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>';

// === Fetch HOD's name for greeting ===
$hod_name = '';
$stmt_user = $mysqli->prepare("SELECT name FROM users WHERE id = ?");
if ($stmt_user) {
    $stmt_user->bind_param("i", $hod_id);
    $stmt_user->execute();
    $user_res = $stmt_user->get_result();
    if ($user_res->num_rows > 0) {
        $hod_name = $user_res->fetch_assoc()['name'];
    }
    $stmt_user->close();
}

// === DATA FETCHING & FILTER LOGIC ===
$filter_faculty_id = $_GET['filter_faculty_id'] ?? 'all';
$filter_metric_id = $_GET['filter_metric_id'] ?? 'all';
$filter_status = $_GET['filter_status'] ?? 'All';
$allowed_statuses = ['All', 'Pending', 'In Progress', 'Submitted', 'Approved', 'Rejected'];
if (!in_array($filter_status, $allowed_statuses)) { $filter_status = 'All'; }

// Fetch lists for filter dropdowns
$stmt = $mysqli->prepare("SELECT id, name FROM users WHERE role_id = 4 AND department_id = ? ORDER BY name");
$stmt->bind_param("i", $department_id);
$stmt->execute();
$faculty_array = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$metrics_list = $mysqli->query("SELECT id, name FROM metrics ORDER BY name")->fetch_all(MYSQLI_ASSOC);

$dynamic_title_suffix = '';
if ($filter_faculty_id !== 'all') {
    foreach($faculty_array as $f) { if ($f['id'] == $filter_faculty_id) { $dynamic_title_suffix = " for " . htmlspecialchars($f['name']); break; } }
}

// Data for Progress Cards
$sql_stats = "SELECT t.status, COUNT(DISTINCT t.id) as count FROM tasks t JOIN task_assignees ta ON t.id = ta.task_id JOIN users u ON ta.user_id = u.id";
$where_stats = ["u.department_id = ?"]; $stats_params = [$department_id];
$types_stats = "i";
if ($filter_faculty_id !== 'all') { $where_stats[] = "u.id = ?"; $stats_params[] = (int)$filter_faculty_id; $types_stats .= "i"; }
if ($filter_metric_id !== 'all') { $where_stats[] = "t.metric_id = ?"; $stats_params[] = (int)$filter_metric_id; $types_stats .= "i"; }
$sql_stats .= " WHERE " . implode(" AND ", $where_stats) . " GROUP BY t.status";

$stmt = $mysqli->prepare($sql_stats);
$stmt->bind_param($types_stats, ...$stats_params);
$stmt->execute();
$result_stats = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
$stats = array_column($result_stats, 'count', 'status') + ['Pending' => 0, 'In Progress' => 0, 'Submitted' => 0, 'Approved' => 0, 'Rejected' => 0];

// Data for Graphical Views
$where_charts_base = "u.department_id = ?";
$chart_params_base = [$department_id];
$types_charts_base = "i";
if ($filter_faculty_id !== 'all') { $where_charts_base .= " AND u.id = ?"; $chart_params_base[] = (int)$filter_faculty_id; $types_charts_base .= "i"; }
if ($filter_metric_id !== 'all') { $where_charts_base .= " AND t.metric_id = ?"; $chart_params_base[] = (int)$filter_metric_id; $types_charts_base .= "i"; }
$where_clause_charts = " WHERE " . $where_charts_base;

$sql_dept_stats_chart = "SELECT status, COUNT(*) as count, GROUP_CONCAT(DISTINCT u.name SEPARATOR ', ') as faculty_names FROM tasks t JOIN task_assignees ta ON t.id=ta.task_id JOIN users u ON ta.user_id=u.id" . $where_clause_charts . " GROUP BY status";
$stmt = $mysqli->prepare($sql_dept_stats_chart);
$stmt->bind_param($types_charts_base, ...$chart_params_base);
$stmt->execute();
$dept_stats_chart = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$sql_perf_chart = "SELECT u.name, t.status, COUNT(t.id) as count FROM tasks t JOIN task_assignees ta ON t.id=ta.task_id JOIN users u ON ta.user_id=u.id" . $where_clause_charts . " AND u.role_id=4 GROUP BY u.id, t.status";
$stmt = $mysqli->prepare($sql_perf_chart);
$stmt->bind_param($types_charts_base, ...$chart_params_base);
$stmt->execute();
$perf_chart_data = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$sql_urgent_tasks = "SELECT u.name, COUNT(DISTINCT t.id) as urgent_count FROM tasks t JOIN task_assignees ta ON t.id=ta.task_id JOIN users u ON ta.user_id=u.id" . $where_clause_charts . " AND t.due_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY) AND t.status NOT IN ('Approved', 'Submitted') GROUP BY u.id ORDER BY urgent_count DESC";
$stmt = $mysqli->prepare($sql_urgent_tasks);
$stmt->bind_param($types_charts_base, ...$chart_params_base);
$stmt->execute();
$urgent_tasks_data = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$metric_where_charts = "1=1"; $metric_chart_params = [$department_id];
$metric_types = "i";
if ($filter_faculty_id !== 'all') { $metric_where_charts .= " AND u.id = ?"; $metric_chart_params[] = (int)$filter_faculty_id; $metric_types .= "i"; }
$sql_metric_progress = "SELECT m.name, COUNT(t.id) as total, SUM(CASE WHEN t.status = 'Approved' THEN 1 ELSE 0 END) as approved, GROUP_CONCAT(DISTINCT u.name SEPARATOR ', ') as faculty_names FROM metrics m LEFT JOIN tasks t ON m.id = t.metric_id LEFT JOIN task_assignees ta ON t.id=ta.task_id LEFT JOIN users u ON ta.user_id=u.id AND u.department_id = ? WHERE " . $metric_where_charts . " GROUP BY m.id ORDER BY m.name";

$stmt = $mysqli->prepare($sql_metric_progress);
$stmt->bind_param($metric_types, ...$metric_chart_params);
$stmt->execute();
$metric_progress_data = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Data for main Task List
$sql_tasks = "SELECT DISTINCT t.id, t.*, m.name as metric_name, m.description, (SELECT GROUP_CONCAT(u_inner.name SEPARATOR ', ') FROM task_assignees ta_inner JOIN users u_inner ON ta_inner.user_id = u_inner.id WHERE ta_inner.task_id = t.id) as faculty_names FROM tasks t JOIN metrics m ON t.metric_id = m.id JOIN task_assignees ta ON t.id = ta.task_id JOIN users u_assignee ON ta.user_id = u_assignee.id";
$where_tasks = ["u_assignee.department_id = ?"]; $task_params = [$department_id];
$types_tasks = "i";
if ($filter_status !== 'All') { $where_tasks[] = "t.status = ?"; $task_params[] = $filter_status; $types_tasks .= "s"; }
if ($filter_faculty_id !== 'all') { $where_tasks[] = "u_assignee.id = ?"; $task_params[] = (int)$filter_faculty_id; $types_tasks .= "i"; }
if ($filter_metric_id !== 'all') { $where_tasks[] = "t.metric_id = ?"; $task_params[] = (int)$filter_metric_id; $types_tasks .= "i"; }
$sql_tasks .= " WHERE " . implode(" AND ", $where_tasks) . " ORDER BY FIELD(t.status, 'Submitted', 'Rejected', 'Pending', 'In Progress', 'Approved'), t.due_date ASC";

$stmt = $mysqli->prepare($sql_tasks);
$stmt->bind_param($types_tasks, ...$task_params);
$stmt->execute();
$tasks_result = $stmt->get_result();

// Data for Faculty Management Table (QUERY FIXED)
$sql_faculty = "SELECT u.id, u.name, u.email, u.employee_id, u.job_description_id, jd.name as job_description_name
                FROM users u
                LEFT JOIN job_descriptions jd ON u.job_description_id = jd.id
                WHERE u.role_id = 4 AND u.department_id = ? 
                ORDER BY u.name";
$stmt_faculty = $mysqli->prepare($sql_faculty);
$stmt_faculty->bind_param("i", $department_id);
$stmt_faculty->execute();
$faculty_details_array = $stmt_faculty->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt_faculty->close();

// Fetch unread notifications for the HOD
$notifications_result = $mysqli->prepare("SELECT * FROM notifications WHERE user_id = ? AND is_read = 0 ORDER BY created_at DESC");
$notifications_result->bind_param("i", $_SESSION['user_id']);
$notifications_result->execute();
$notifications = $notifications_result->get_result()->fetch_all(MYSQLI_ASSOC);
$unread_count = count($notifications);
?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<style>
    /* === All of your original CSS styles === */
    html { scroll-padding-top: 65px; scroll-behavior: smooth; }
    body { background-color: #f4f7f9; font-family: sans-serif; }
    .main-content { margin-top: 65px; padding: 25px; }
    .main-header { position: fixed; top: 0; left: 0; right: 0; height: 65px; background: #ffffff; box-shadow: 0 2px 4px rgba(0,0,0,0.1); z-index: 990; display: grid; grid-template-columns: 1fr auto 1fr; align-items: center; padding: 0 20px; }
    #menu-toggle { grid-column: 1; justify-self: start; background: transparent; border: 1px solid #dcdcdc; width: 40px; height: 40px; border-radius: 50%; color: #333; font-size: 1rem; cursor: pointer; display: flex; align-items: center; justify-content: center; transition: all 0.2s ease; }
    .header-title { grid-column: 2; font-size: 1.5rem; font-weight: 600; color: #2c3e50; }
    .header-right { grid-column: 3; justify-self: end; display: flex; align-items: center; gap: 20px; }
    .user-greeting { font-size: 1rem; color: #555; font-weight: 500; }
    .logout-button { display: flex; align-items: center; justify-content: center; background: transparent; border: 1px solid #dcdcdc; width: 40px; height: 40px; border-radius: 50%; color: #e74c3c; font-size: 1rem; cursor: pointer; text-decoration: none; transition: all 0.2s ease; }
    #menu-toggle:hover { background: #f1f1f1; border-color: #aaa; }
    .logout-button:hover { background: #f1f1f1; border-color: #c0392b; }
    #menu-toggle .icon-close { display: none; }
    .menu-open #menu-toggle .icon-hamburger { display: none; }
    .menu-open #menu-toggle .icon-close { display: block; }
    .sidebar { width: 280px; background-color: #ffffff; color: #333; position: fixed; top: 0; left: 0; height: 100%; z-index: 1000; transform: translateX(-100%); transition: transform 0.3s ease-in-out; display: flex; flex-direction: column; box-shadow: 0 0 15px rgba(0,0,0,0.2); }
    .sidebar.show { transform: translateX(0); }
    .overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 999; opacity: 0; visibility: hidden; transition: opacity 0.3s ease-in-out, visibility 0s 0.3s; }
    .overlay.show { opacity: 1; visibility: visible; transition: opacity 0.3s ease-in-out; }
    .sidebar-header { padding: 20px; text-align: center; border-bottom: 1px solid #e9ecef; background-color: #5c67f2; color: white; }
    .sidebar-header h3 { margin: 0; font-size: 1.4rem; }
    .sidebar-nav { list-style-type: none; padding: 15px 0; margin: 0; flex-grow: 1; }
    .sidebar-nav a { display: flex; align-items: center; gap: 12px; padding: 12px 25px; text-decoration: none; color: #495057; border-radius: 6px; font-weight: 500; margin: 0 10px 5px 10px; transition: background-color 0.2s, color 0.2s; }
    .sidebar-nav a:hover { background-color: #f8f9fa; color: #0056b3; }
    .sidebar-nav a.active { background-color: #5c67f2; color: #fff; }
    .sidebar-nav a .fa-fw { width: 20px; text-align: center; }
    .content-section { display: none; }
    .content-section.active { display: block; }
    .dashboard-section { background: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); margin-bottom: 25px; }
    .assignment-item-hod { display: grid; background: #fff; border: 1px solid #ddd; border-left: 5px solid #6c757d; border-radius: 8px; margin-bottom: 15px; grid-template-columns: 1fr auto; grid-template-rows: auto auto; grid-template-areas: "info status" "docs actions"; }
    .assignment-item-hod.status-approved { border-left-color: #28a745; }
    .assignment-item-hod.status-submitted { border-left-color: #007bff; }
    .assignment-item-hod.status-in-progress { border-left-color: #6f42c1; }
    .assignment-item-hod.status-pending { border-left-color: #ffc107; }
    .assignment-item-hod.status-rejected { border-left-color: #dc3545; }
    .item-main-info, .item-status, .item-actions, .item-proofs { padding: 15px; }
    .item-main-info { grid-area: info; }
    .item-status { grid-area: status; text-align: right; }
    .item-actions { grid-area: actions; display: flex; justify-content: flex-end; align-items: center; border-top: 1px solid #eee; }
    .item-proofs { grid-area: docs; border-top: 1px solid #eee; padding-top: 10px; }
    .item-proofs .btn-download { margin-right: 10px; margin-bottom: 5px; font-size: 0.9em; }
    .item-proofs .no-proof { color: #888; font-style: italic; }
    .stat-card.active-filter { box-shadow: 0 0 0 3px #5c67f2; border-color: #5c67f2; }
    .progress-filter { background-color: #f1f1f1; padding: 15px 20px; border-radius: 8px; margin: 10px 0 25px 0; display: flex; flex-wrap: wrap; align-items: flex-end; gap: 20px;}
    .chart-row { display: flex; flex-wrap: wrap; gap: 20px; margin-bottom: 20px; }
    .chart-box, .insight-card { flex: 1 1 300px; min-width: 300px; height: 380px; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); border: 1px solid #e9ecef; position: relative; }
    .user-form-container { background-color: #f8f9fa; padding: 20px; border-radius: 8px; border: 1px solid #e9ecef; }
    .notification-container {
        position: relative;
        display: inline-block;
    }
    .notification-bell {
        background: none;
        border: none;
        font-size: 1.5rem;
        color: #333;
        cursor: pointer;
        position: relative;
    }
    .notification-count {
        position: absolute;
        top: -5px;
        right: -5px;
        background: #dc3545;
        color: white;
        border-radius: 50%;
        padding: 2px 6px;
        font-size: 0.75rem;
    }
    .notification-dropdown {
        display: none;
        position: absolute;
        right: 0;
        top: 100%;
        background: white;
        border: 1px solid #ddd;
        border-radius: 4px;
        width: 400px;
        max-height: 400px;
        overflow-y: auto;
        z-index: 1000;
    }
    .notification-item {
        padding: 10px;
        border-bottom: 1px solid #eee;
        white-space: pre-line;
        font-size: 0.9em;
        line-height: 1.4;
    }
    .notification-item a {
        text-decoration: none;
        color: #333;
        display: block;
    }
</style>

<!-- Fixed Header Bar -->
<header class="main-header">
    <button id="menu-toggle" title="Toggle Menu">
        <i class="fas fa-bars icon-hamburger"></i>
        <i class="fas fa-times icon-close"></i>
    </button>
    <div class="header-title">HOD Dashboard</div>
    <div class="header-right">
        <span class="user-greeting">Welcome, <?php echo htmlspecialchars(explode(' ', $hod_name)[0]); ?>!</span>
        <div class="notification-container">
            <button id="notification-bell" class="notification-bell">
                <i class="fas fa-bell"></i>
                <?php if ($unread_count > 0): ?>
                    <span class="notification-count"><?php echo $unread_count; ?></span>
                <?php endif; ?>
            </button>
            <div id="notification-dropdown" class="notification-dropdown">
                <?php if (!empty($notifications)): ?>
                    <?php foreach ($notifications as $notification): ?>
                        <div class="notification-item">
                            <a href="<?php echo htmlspecialchars($notification['link']); ?>" data-id="<?php echo $notification['id']; ?>">
                                <?php echo htmlspecialchars($notification['message']); ?>
                            </a>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="notification-item">No new notifications</div>
                <?php endif; ?>
            </div>
        </div>
        <a href="logout.php" class="logout-button" title="Logout">
            <i class="fas fa-sign-out-alt"></i>
        </a>
    </div>
</header>

<!-- Overlay and Sidebar -->
<div class="overlay"></div>
<div class="sidebar">
    <div class="sidebar-header"><h3><i class="fas fa-sitemap"></i> HOD Menu</h3></div>
    <nav class="sidebar-nav">
        <a href="#progress" data-target="progress" class="nav-link"><i class="fa-fw fas fa-tachometer-alt"></i> Department Progress</a>
        <a href="#overview" data-target="overview" class="nav-link"><i class="fa-fw fas fa-chart-pie"></i> Graphical Overview</a>
        <a href="#tasks" data-target="tasks" class="nav-link"><i class="fa-fw fas fa-list-check"></i> Task List</a>
        <a href="#faculty" data-target="faculty" class="nav-link"><i class="fa-fw fas fa-users-cog"></i> Manage Faculty</a>
    </nav>
</div>

<!-- Main Content Area -->
<main class="main-content">
    <?php if (isset($_SESSION['message'])): ?>
    <div class="message <?php echo $_SESSION['message']['type']; ?>"><?php echo htmlspecialchars($_SESSION['message']['text']); unset($_SESSION['message']); ?></div>
    <?php endif; ?>

    <!-- Section 1: Department Progress -->
    <div id="progress" class="content-section">
        <div class="dashboard-section">
            <h2><i class="fas fa-filter"></i> Department Progress</h2>
            <div class="progress-filter">
                <form action="hod_dashboard.php" method="GET" style="display: contents;">
                    <div class="form-group"><label for="filter_faculty_id" style="font-weight:bold;">Show Progress For:</label><select name="filter_faculty_id" id="filter_faculty_id" class="form-control" onchange="this.form.submit()"><option value="all">Entire Department</option><?php foreach($faculty_array as $faculty): ?><option value="<?php echo $faculty['id']; ?>" <?php if($filter_faculty_id == $faculty['id']) echo 'selected'; ?>><?php echo htmlspecialchars($faculty['name']); ?></option><?php endforeach; ?></select></div>
                    <div class="form-group"><label for="filter_metric_id" style="font-weight:bold;">Under Metric:</label><select name="filter_metric_id" id="filter_metric_id" class="form-control" onchange="this.form.submit()"><option value="all">All Metrics</option><?php foreach($metrics_list as $metric): ?><option value="<?php echo $metric['id']; ?>" <?php if($filter_metric_id == $metric['id']) echo 'selected'; ?>><?php echo htmlspecialchars($metric['name']); ?></option><?php endforeach; ?></select></div>
                </form>
            </div>
            <div class="stats-container">
                <?php $status_order = ['Pending', 'Submitted', 'In Progress', 'Approved', 'Rejected']; foreach ($status_order as $status): $count = $stats[$status] ?? 0; $icon_class = ['Approved' => 'fa-check-circle', 'Submitted' => 'fa-paper-plane', 'In Progress' => 'fa-spinner', 'Pending' => 'fa-clock', 'Rejected' => 'fa-times-circle']; $color_class = ['Approved' => 'green', 'Submitted' => 'blue', 'In Progress' => 'purple', 'Pending' => 'orange', 'Rejected' => 'red']; $is_active = ($filter_status === $status) ? 'active-filter' : ''; $link = "hod_dashboard.php?filter_status=".urlencode($status)."&filter_faculty_id=".urlencode($filter_faculty_id)."&filter_metric_id=".urlencode($filter_metric_id)."#tasks";?>
                <div class="stat-card <?php echo $is_active; ?>"><a href="<?php echo $link; ?>" class="stat-link"><i class="fas <?php echo $icon_class[$status] ?? 'fa-question-circle'; ?> icon-<?php echo $color_class[$status] ?? 'grey'; ?>"></i><div class="stat-info"><h4><?php echo htmlspecialchars($status); ?></h4><span><?php echo $count; ?></span></div></a></div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- Section 2: Graphical Overview -->
    <div id="overview" class="content-section">
         <div class="dashboard-section">
            <h2><i class="fas fa-chart-pie"></i> Graphical Overview <small style="font-weight:normal;"><?php echo $dynamic_title_suffix; if ($filter_metric_id !== 'all') { foreach($metrics_list as $m) { if ($m['id'] == $filter_metric_id) echo " under " . htmlspecialchars($m['name']); } } ?></small></h2>
            <div class="chart-container"><div class="chart-row"><div class="chart-box"><h3>Task Status<?php echo $dynamic_title_suffix; ?></h3><canvas id="statusDoughnutChart"></canvas></div><div class="chart-box"><h3>Faculty Performance<?php echo $dynamic_title_suffix; ?></h3><canvas id="performanceStackedChart"></canvas></div></div><div class="chart-row"><div class="chart-box"><h3>Metric Progress<?php echo $dynamic_title_suffix; ?></h3><p class="text-muted" style="font-size:0.8em; margin-top:-10px;">(Not filtered by metric)</p><canvas id="metricProgressChart"></canvas></div><div class="insight-card"><h3><i class="fas fa-exclamation-triangle"></i> Urgent Tasks<?php echo $dynamic_title_suffix; ?></h3><p class="text-muted text-center">Due in next 7 days.</p><?php if (empty($urgent_tasks_data)): ?><p class="text-center mt-5">No urgent tasks found.</p><?php else: ?><ul><?php foreach($urgent_tasks_data as $urgent_item): ?><li><?php echo htmlspecialchars($urgent_item['name']); ?>: <strong><?php echo $urgent_item['urgent_count']; ?></strong></li><?php endforeach; ?></ul><?php endif; ?></div></div></div>
        </div>
    </div>
    
    <!-- Section 3: Department Task List -->
    <div id="tasks" class="content-section">
        <div class="dashboard-section">
            <h2><i class="fas fa-list-check"></i> Task List</h2>
            <div class="assignments-list-hod">
                <?php if ($tasks_result && $tasks_result->num_rows > 0): while($task = $tasks_result->fetch_assoc()): ?>
                <div class="assignment-item-hod status-<?php echo strtolower(str_replace(' ', '-', $task['status'])); ?>">
                    <div class="item-main-info"><strong><?php echo htmlspecialchars($task['metric_name']); ?></strong><br><small>Assigned to: <?php echo htmlspecialchars($task['faculty_names']); ?> | Due: <?php echo date("d M, Y", strtotime($task['due_date'])); ?></small><p style="margin-top: 5px; font-size: 0.9em; color: #555;"><?php echo htmlspecialchars($task['description'] ?? ''); ?></p></div>
                    <div class="item-status"><span class="status-badge"><?php echo htmlspecialchars($task['status']); ?></span></div>
                    <div class="item-proofs"><strong>Proofs:</strong> <?php $proof_stmt = $mysqli->prepare("SELECT p.file_path, p.original_filename FROM proofs p JOIN task_assignees ta ON p.task_assignee_id = ta.id WHERE ta.task_id = ?"); if($proof_stmt){ $proof_stmt->bind_param("i", $task['id']); $proof_stmt->execute(); $proofs = $proof_stmt->get_result(); if ($proofs->num_rows > 0) { while($proof = $proofs->fetch_assoc()) { echo '<a href="' . htmlspecialchars($proof['file_path']) . '" class="btn-action btn-download" target="_blank" title="Download"><i class="fas fa-download"></i> ' . htmlspecialchars($proof['original_filename']) . '</a>'; } } else { echo '<span class="no-proof">No Proofs Uploaded</span>'; } $proof_stmt->close(); } ?></div>
                    <div class="item-actions"></div>
                </div>
                <?php endwhile; $tasks_result->close(); else: ?><p>No tasks found for the current filter combination.</p><?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Section 4: Manage Department Faculty (CORRECTED) -->
    <div id="faculty" class="content-section">
         <div class="dashboard-section">
            <h2><i class="fas fa-users-cog"></i> Manage Department Faculty</h2>
            <div class="user-form-container">
                <h4><i class="fas fa-user-plus"></i> Add New Faculty</h4>
                <form action="hod_actions.php" method="POST" class="user-form">
                    <input type="hidden" name="action" value="add_faculty">
                    <div class="form-row"><div class="form-group"><label for="add-name">Full Name</label><input type="text" id="add-name" name="name" required class="form-control"></div><div class="form-group"><label for="add-email">Email Address</label><input type="email" id="add-email" name="email" required class="form-control"></div></div>
                    <div class="form-row"><div class="form-group"><label for="add-employee_id">Employee ID</label><input type="text" id="add-employee_id" name="employee_id" class="form-control"></div><div class="form-group"><label for="add-password">Set Initial Password</label><input type="password" id="add-password" name="password" required class="form-control"></div></div>
                    <div class="form-row"><div class="form-group" style="flex: 1;"><label for="add-job_description_id">Job Description</label><select id="add-job_description_id" name="job_description_id" class="form-control"><option value="">-- None --</option><?php foreach($job_descriptions_array as $desc): ?><option value="<?php echo $desc['id']; ?>"><?php echo htmlspecialchars($desc['name']); ?></option><?php endforeach; ?></select></div></div>
                    <div class="form-actions"><button type="submit" class="btn btn-primary"><i class="fas fa-plus"></i> Add Faculty</button></div>
                </form>
            </div>
            <hr style="margin: 30px 0;">
            <h4>Existing Faculty List</h4>
            <table class="data-table">
                <thead><tr><th>Name</th><th>Email</th><th>Employee ID</th><th>Job Description</th><th>Actions</th></tr></thead>
                <tbody>
                    <?php if (count($faculty_details_array) > 0): foreach($faculty_details_array as $faculty_item): ?>
                    <tr id="faculty-display-<?php echo $faculty_item['id']; ?>">
                        <td><?php echo htmlspecialchars($faculty_item['name']); ?></td>
                        <td><?php echo htmlspecialchars($faculty_item['email']); ?></td>
                        <td><?php echo htmlspecialchars($faculty_item['employee_id']); ?></td>
                        <td><?php echo htmlspecialchars($faculty_item['job_description_name'] ?? 'N/A'); ?></td>
                        <td><button class="btn-action btn-edit" onclick="toggleEditForm(<?php echo $faculty_item['id']; ?>)"><i class="fas fa-edit"></i> Edit</button></td>
                    </tr>
                    <tr id="faculty-edit-<?php echo $faculty_item['id']; ?>" style="display: none;">
                        <td colspan="5">
                            <form action="hod_actions.php" method="POST" class="user-form-inline">
                                <input type="hidden" name="action" value="edit_faculty"><input type="hidden" name="faculty_id" value="<?php echo $faculty_item['id']; ?>">
                                <div class="form-row"><div class="form-group"><label>Name</label><input type="text" name="name" value="<?php echo htmlspecialchars($faculty_item['name']); ?>" required class="form-control"></div><div class="form-group"><label>Email</label><input type="email" name="email" value="<?php echo htmlspecialchars($faculty_item['email']); ?>" required class="form-control"></div></div>
                                <div class="form-row"><div class="form-group"><label>Employee ID</label><input type="text" name="employee_id" value="<?php echo htmlspecialchars($faculty_item['employee_id']); ?>" class="form-control"></div><div class="form-group"><label>Job Description</label><select name="job_description_id" class="form-control"><option value="">-- None --</option><?php foreach($job_descriptions_array as $desc): ?><option value="<?php echo $desc['id']; ?>" <?php if ($faculty_item['job_description_id'] == $desc['id']) echo 'selected'; ?>><?php echo htmlspecialchars($desc['name']); ?></option><?php endforeach; ?></select></div></div>
                                <div class="form-actions"><button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save</button><button type="button" class="btn btn-secondary" onclick="toggleEditForm(<?php echo $faculty_item['id']; ?>)">Cancel</button></div>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; else: ?>
                    <tr><td colspan="5">No faculty members found in your department.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</main>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const body = document.body;
    const menuToggle = document.getElementById('menu-toggle');
    const sidebar = document.querySelector('.sidebar');
    const overlay = document.querySelector('.overlay');
    const navLinks = document.querySelectorAll('.sidebar-nav a');
    const contentSections = document.querySelectorAll('.content-section');

    const openMenu = () => { body.classList.add('menu-open'); sidebar.classList.add('show'); overlay.classList.add('show'); };
    const closeMenu = () => { body.classList.remove('menu-open'); sidebar.classList.remove('show'); overlay.classList.remove('show'); };

    menuToggle.addEventListener('click', e => { e.stopPropagation(); sidebar.classList.contains('show') ? closeMenu() : openMenu(); });
    overlay.addEventListener('click', closeMenu);

    function showSection(targetId) {
        contentSections.forEach(section => section.classList.remove('active'));
        navLinks.forEach(link => link.classList.remove('active'));
        
        const targetSection = document.getElementById(targetId);
        const targetLink = document.querySelector(`.sidebar-nav a[data-target="${targetId}"]`);
        
        if (targetSection) targetSection.classList.add('active');
        if (targetLink) targetLink.classList.add('active');
    }

    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.dataset.target;
            history.pushState(null, null, `#${targetId}`);
            showSection(targetId);
            closeMenu();
        });
    });

    const initialHash = window.location.hash.substring(1);
    const validSectionIds = Array.from(contentSections).map(s => s.id);
    if (initialHash && validSectionIds.includes(initialHash)) {
        showSection(initialHash);
    } else {
        showSection('progress'); // Default view
    }
    
    window.toggleEditForm = function(facultyId) {
        const displayRow = document.getElementById('faculty-display-' + facultyId);
        const editRow = document.getElementById('faculty-edit-' + facultyId);
        if (displayRow && editRow) {
            displayRow.style.display = displayRow.style.display === 'none' ? '' : 'none';
            editRow.style.display = editRow.style.display === 'none' ? '' : 'none';
        }
    }

    // Chart.js Initializations
    const statusColors = { 'Approved': '#28a745', 'Submitted': '#007bff', 'In Progress': '#6f42c1', 'Pending': '#ffc107', 'Rejected': '#dc3545' };
    const statusData = <?php echo json_encode($dept_stats_chart); ?>;
    const statusChartCanvas = document.getElementById('statusDoughnutChart');
    if (statusChartCanvas && statusData.length > 0) { new Chart(statusChartCanvas, { type: 'doughnut', data: { labels: statusData.map(d => d.status), datasets: [{ data: statusData.map(d => d.count), backgroundColor: statusData.map(d => statusColors[d.status] || '#ccc') }] }, options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'top' }, tooltip: { callbacks: { label: function(context) { const point = statusData[context.dataIndex]; return ` ${point.status}: ${point.count}`; }, afterLabel: function(context) { const point = statusData[context.dataIndex]; return `Faculty: ${point.faculty_names || 'N/A'}`; } } } } } }); }
    
    const perfDataRaw = <?php echo json_encode($perf_chart_data); ?>;
    const perfChartCanvas = document.getElementById('performanceStackedChart');
    if (perfChartCanvas && perfDataRaw.length > 0) { const perfLabels = [...new Set(perfDataRaw.map(item => item.name))]; const perfDatasets = Object.keys(statusColors).map(status => ({ label: status, data: perfLabels.map(label => perfDataRaw.find(d => d.name === label && d.status === status)?.count || 0), backgroundColor: statusColors[status] })); new Chart(perfChartCanvas, { type: 'bar', data: { labels: perfLabels, datasets: perfDatasets }, options: { responsive: true, maintainAspectRatio: false, scales: { x: { stacked: true }, y: { stacked: true } }, plugins: { legend: { position: 'top' } } } }); }
    
    const metricData = <?php echo json_encode($metric_progress_data); ?>;
    const metricChartCanvas = document.getElementById('metricProgressChart');
    if (metricChartCanvas && metricData.length > 0) { const percentages = metricData.map(d => d.total > 0 ? (d.approved / d.total) * 100 : 0); const getProgressColor = (value) => (value < 33) ? 'rgba(220, 53, 69, 0.7)' : (value < 66) ? 'rgba(255, 193, 7, 0.7)' : 'rgba(40, 167, 69, 0.7)'; new Chart(metricChartCanvas, { type: 'bar', data: { labels: metricData.map(d => d.name), datasets: [{ label: '% Complete', data: percentages, backgroundColor: percentages.map(p => getProgressColor(p)) }] }, options: { indexAxis: 'y', responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false }, tooltip: { callbacks: { label: (c) => ` ${metricData[c.dataIndex].approved || 0} of ${metricData[c.dataIndex].total} approved (${Math.round(percentages[c.dataIndex])}%)`, afterLabel: (c) => `Faculty: ${metricData[c.dataIndex].faculty_names || 'N/A'}` } } }, scales: { x: { max: 100, title: { display: true, text: 'Completion %' } } } } }); }

    const notificationBell = document.getElementById('notification-bell');
    const notificationDropdown = document.getElementById('notification-dropdown');

    notificationBell.addEventListener('click', function() {
        notificationDropdown.style.display = notificationDropdown.style.display === 'block' ? 'none' : 'block';
    });

    document.addEventListener('click', function(e) {
        if (!notificationBell.contains(e.target) && !notificationDropdown.contains(e.target)) {
            notificationDropdown.style.display = 'none';
        }
    });

    const notificationLinks = notificationDropdown.querySelectorAll('a');
    notificationLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const notificationId = this.dataset.id;
            fetch('hod_actions.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `action=mark_notification_read&notification_id=${notificationId}`
            }).then(() => {
                window.location.href = this.href;
            });
        });
    });
});
</script>

<?php require_once 'includes/footer.php'; ?>