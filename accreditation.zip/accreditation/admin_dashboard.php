<?php
require_once 'includes/auth_check.php';
require_once 'config/db.php';

// Security: Only allow Admins to view this page
if ($_SESSION['user_role'] !== 'Admin') {
    die("Access Denied.");
}

$page_title = 'Admin Dashboard';
require_once 'includes/header.php';
echo '<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>';

// === DATA FETCHING FOR ALL SECTIONS ===
$criteria_array = $mysqli->query("SELECT * FROM criteria ORDER BY name")->fetch_all(MYSQLI_ASSOC);
$metrics_list = $mysqli->query("SELECT m.id, m.name, m.criterion_id, c.name AS criterion_name FROM metrics m JOIN criteria c ON m.criterion_id = c.id ORDER BY c.name, m.name")->fetch_all(MYSQLI_ASSOC);
$roles_array = $mysqli->query("SELECT * FROM roles ORDER BY name")->fetch_all(MYSQLI_ASSOC);
$departments_array = $mysqli->query("SELECT * FROM departments ORDER BY name")->fetch_all(MYSQLI_ASSOC);
$job_descriptions_array = $mysqli->query("SELECT * FROM job_descriptions ORDER BY name")->fetch_all(MYSQLI_ASSOC);

// Data for Progress Dashboards & Task Hub
$selected_dept_ids = [];
if (isset($_GET['departments']) && is_array($_GET['departments'])) {
    $selected_dept_ids = array_map('intval', $_GET['departments']);
}
$stats = ['Pending' => 0, 'In Progress' => 0, 'Submitted' => 0, 'Approved' => 0, 'Rejected' => 0];
$sql_stats = "SELECT t.status, COUNT(DISTINCT t.id) as count FROM tasks t";
$stats_params = []; $stats_types = '';
if (!empty($selected_dept_ids)) {
    $sql_stats .= " JOIN task_assignees ta ON t.id = ta.task_id JOIN users u ON ta.user_id = u.id WHERE u.department_id IN (" . implode(',', array_fill(0, count($selected_dept_ids), '?')) . ")";
    $stats_types = str_repeat('i', count($selected_dept_ids));
    $stats_params = $selected_dept_ids;
}
$sql_stats .= " GROUP BY t.status";
$stmt_stats = $mysqli->prepare($sql_stats);
if (!empty($stats_params)) { $stmt_stats->bind_param($stats_types, ...$stats_params); }
$stmt_stats->execute();
$result_stats = $stmt_stats->get_result();
while ($row = $result_stats->fetch_assoc()) { if(isset($stats[$row['status']])) { $stats[$row['status']] = $row['count']; } }
$stmt_stats->close();

$filter_status = $_GET['filter'] ?? 'All';
$allowed_filters = ['All', 'Pending', 'In Progress', 'Submitted', 'Approved', 'Rejected'];
if (!in_array($filter_status, $allowed_filters)) { $filter_status = 'All'; }
$sql_tasks = "SELECT DISTINCT t.id, t.*, m.name as metric_name, c.name as criterion_name, (SELECT GROUP_CONCAT(u_inner.name SEPARATOR ', ') FROM task_assignees ta_inner JOIN users u_inner ON ta_inner.user_id = u_inner.id WHERE ta_inner.task_id = t.id) as faculty_names FROM tasks t JOIN metrics m ON t.metric_id = m.id JOIN criteria c ON m.criterion_id = c.id";
$task_where_clauses = []; $task_params = []; $task_types = '';
if(!empty($selected_dept_ids)){
    $sql_tasks .= " JOIN task_assignees ta ON t.id = ta.task_id JOIN users u ON ta.user_id = u.id";
    $placeholders = implode(',', array_fill(0, count($selected_dept_ids), '?'));
    $task_where_clauses[] = "u.department_id IN ($placeholders)";
    foreach($selected_dept_ids as $dept_id) { $task_params[] = $dept_id; $task_types .= 'i'; }
}
if ($filter_status !== 'All') { $task_where_clauses[] = "t.status = ?"; $task_params[] = $filter_status; $task_types .= 's'; }
if (!empty($task_where_clauses)) { $sql_tasks .= " WHERE " . implode(' AND ', $task_where_clauses); }
$sql_tasks .= " ORDER BY FIELD(t.status, 'Submitted', 'Rejected', 'Pending', 'In Progress', 'Approved'), t.due_date ASC";
$stmt_tasks = $mysqli->prepare($sql_tasks);
if (!empty($task_params)) { $stmt_tasks->bind_param($task_types, ...$task_params); }
$stmt_tasks->execute();
$tasks_result = $stmt_tasks->get_result();
$stmt_tasks->close();

// Data for User Management
$filter_role_id = $_GET['filter_role_id'] ?? 'all';
$filter_dept_id = $_GET['filter_dept_id'] ?? 'all';
$sql_users = "SELECT u.*, r.name as role_name, d.name as department_name, jd.name as job_description_name, c.name as criterion_name FROM users u JOIN roles r ON u.role_id = r.id LEFT JOIN departments d ON u.department_id = d.id LEFT JOIN job_descriptions jd ON u.job_description_id = jd.id LEFT JOIN criteria c ON u.criterion_id = c.id";
$where_users = [];
if ($filter_role_id !== 'all') { $where_users[] = "u.role_id = " . (int)$filter_role_id; }
if ($filter_dept_id !== 'all') { $where_users[] = "u.department_id = " . (int)$filter_dept_id; }
if (!empty($where_users)) { $sql_users .= " WHERE " . implode(' AND ', $where_users); }
$sql_users .= " ORDER BY u.name ASC";
$users_result = $mysqli->query($sql_users);

// Data for Department Performance Chart
$dept_perf_data = $mysqli->query("SELECT d.name as department_name, t.status, COUNT(t.id) as count, (SELECT u_hod.name FROM users u_hod WHERE u_hod.department_id = d.id AND u_hod.role_id = 2 LIMIT 1) as hod_name FROM tasks t JOIN task_assignees ta ON t.id = ta.task_id JOIN users u ON u.id = ta.user_id JOIN departments d ON u.department_id = d.id GROUP BY d.id, t.status")->fetch_all(MYSQLI_ASSOC);

// Data for Urgent Tasks
$urgent_tasks_result = $mysqli->query("SELECT t.id, m.name as metric_name, t.due_date, d.name as department_name, (SELECT GROUP_CONCAT(u.name SEPARATOR ', ') FROM task_assignees ta JOIN users u ON ta.user_id = u.id WHERE ta.task_id = t.id) as assignees FROM tasks t JOIN metrics m ON t.metric_id = m.id JOIN task_assignees ta_outer ON t.id = ta_outer.task_id JOIN users u_outer ON ta_outer.user_id = u_outer.id JOIN departments d ON u_outer.department_id = d.id WHERE t.due_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY) AND t.status NOT IN ('Approved', 'Submitted') GROUP BY t.id ORDER BY t.due_date ASC");

// Data for Metric Attachments
$metrics_attachments_result = $mysqli->query("SELECT m.id AS metric_id, m.name AS metric_name, c.name AS criterion_name, ma.file_path, ma.original_filename FROM metrics m JOIN criteria c ON m.criterion_id = c.id LEFT JOIN metric_attachments ma ON m.id = ma.metric_id ORDER BY c.name, m.name");

// Data for Approval Hub
$approval_stats = ['Pending' => 0, 'Approved' => 0, 'Rejected' => 0];
$stats_query = "SELECT status, COUNT(*) as count FROM pending_updates GROUP BY status";
$stats_result = $mysqli->query($stats_query);
if ($stats_result) {
    while ($stat = $stats_result->fetch_assoc()) {
        if (isset($approval_stats[$stat['status']])) {
            $approval_stats[$stat['status']] = $stat['count'];
        }
    }
}

$pending_updates_result = $mysqli->query("
    SELECT 
        pu.*, 
        u.name AS requester_name,
        CASE 
            WHEN pu.update_type = 'criterion_template' THEN c.name 
            ELSE m.name 
        END as target_name,
        CASE 
            WHEN pu.update_type = 'criterion_template' THEN ct.file_path
            ELSE ma.file_path
        END as current_file_path
    FROM pending_updates pu
    JOIN users u ON pu.requested_by_user_id = u.id
    LEFT JOIN criteria c ON pu.target_id = c.id AND pu.update_type = 'criterion_template'
    LEFT JOIN metrics m ON pu.target_id = m.id AND pu.update_type = 'metric_attachment'
    LEFT JOIN criterion_templates ct ON pu.target_id = ct.criterion_id AND pu.update_type = 'criterion_template'
    LEFT JOIN metric_attachments ma ON pu.target_id = ma.metric_id AND pu.update_type = 'metric_attachment'
    ORDER BY pu.requested_at ASC
");
?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<style>
    /* --- Base Layout & Navigation --- */
    html { scroll-padding-top: 65px; scroll-behavior: smooth; }
    body { background-color: #f4f7f9; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; }
    .main-header { position: fixed; top: 0; left: 0; right: 0; height: 65px; background: #ffffff; box-shadow: 0 2px 4px rgba(0,0,0,0.1); z-index: 990; }
    .main-content { margin-top: 65px; padding: 25px; }
    #menu-toggle { position: absolute; top: 50%; left: 20px; transform: translateY(-50%); background: transparent; border: 1px solid #dcdcdc; width: 40px; height: 40px; border-radius: 50%; color: #333; font-size: 1rem; cursor: pointer; display: flex; align-items: center; justify-content: center; transition: all 0.2s ease; }
    .header-title { position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); font-size: 1.5rem; font-weight: 600; color: #2c3e50; }
    .logout-button { position: absolute; top: 50%; right: 40px; transform: translateY(-50%); display: flex; align-items: center; justify-content: center; background: transparent; border: 1px solid #dcdcdc; width: 40px; height: 40px; border-radius: 50%; color: #e74c3c; font-size: 1rem; cursor: pointer; text-decoration: none; transition: all 0.2s ease; }
    #menu-toggle:hover, .logout-button:hover { background: #f1f1f1; }
    #menu-toggle .icon-close { display: none; }
    .menu-open #menu-toggle .icon-hamburger { display: none; }
    .menu-open #menu-toggle .icon-close { display: block; }
    .sidebar { width: 280px; background-color: #ffffff; color: #333; position: fixed; top: 0; left: 0; height: 100%; z-index: 1000; transform: translateX(-100%); transition: transform 0.3s ease-in-out; display: flex; flex-direction: column; box-shadow: 0 0 15px rgba(0,0,0,0.2); }
    .sidebar.show { transform: translateX(0); }
    .overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 999; opacity: 0; visibility: hidden; transition: opacity 0.3s ease-in-out, visibility 0s 0.3s; }
    .overlay.show { opacity: 1; visibility: visible; }
    .sidebar-header { padding: 20px; text-align: center; border-bottom: 1px solid #e9ecef; background-color: #2c3e50; color: white; }
    .sidebar-header h3 { margin: 0; font-size: 1.4rem; }
    .sidebar-nav { list-style-type: none; padding: 15px 0; margin: 0; flex-grow: 1; }
    .sidebar-nav li a { display: flex; align-items: center; color: #555; padding: 15px 25px; text-decoration: none; transition: all 0.2s ease; border-left: 4px solid transparent; font-weight: 500; }
    .sidebar-nav li a:hover { background-color: #f8f9fa; color: #007bff; }
    .sidebar-nav li a.active { background-color: #e9ecef; color: #007bff; border-left-color: #007bff; }
    .sidebar-nav li a i { margin-right: 15px; width: 20px; text-align: center; color: #888; }
    .sidebar-nav li a.active i, .sidebar-nav li a:hover i { color: #007bff; }
    .dashboard-section { display: none; background: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); margin-bottom: 25px; }
    .dashboard-section.active { display: block; }
    .dashboard-section h2 { margin-top: 0; border-bottom: 2px solid #e9ecef; padding-bottom: 10px; margin-bottom: 20px; font-size: 1.8rem; color: #2c3e50; }
    .dashboard-section h4 { font-size: 1.2rem; color: #34495e; margin-top: 0; margin-bottom: 15px; }
    .chart-box { height: 420px; }
    .grid-container-2col { display: grid; grid-template-columns: repeat(auto-fit, minmax(450px, 1fr)); gap: 25px; }
    .grid-item { min-width: 0; }
    .department-filter-form { background-color: #f8f9fa; padding: 20px; border-radius: 8px; border: 1px solid #e9ecef; margin-bottom: 25px; }
    .department-filter-form form { display: flex; align-items: center; gap: 20px; flex-wrap: wrap; }
    .department-filter-form .checkbox-group { display: flex; flex-wrap: nowrap; overflow-x: auto; padding-bottom: 10px; gap: 20px; flex-grow: 1; min-width: 0; }
    .department-filter-form .checkbox-item { flex-shrink: 0; display: flex; align-items: center; gap: 5px; }
    .department-filter-form .filter-buttons { display: flex; gap: 10px; flex-shrink: 0; }
    .stats-container { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 20px; margin-top: 20px; }
    .stat-card { background: #fff; border: 1px solid #e9ecef; border-radius: 8px; padding: 20px; transition: all 0.2s ease-in-out; }
    .stat-card:hover { transform: translateY(-3px); box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
    .stat-card.active-filter { box-shadow: 0 0 0 3px #007bff; border-color: #007bff; }
    .stat-link { text-decoration: none; color: inherit; display: flex; align-items: center; gap: 15px; }
    .stat-info h4 { margin: 0 0 5px 0; font-size: 1.1rem; color: #34495e; }
    .stat-info span { font-size: 2rem; font-weight: bold; color: #2c3e50; }
    .stat-link i { font-size: 2rem; }
    .icon-green { color: #28a745; } .icon-blue { color: #007bff; } .icon-purple { color: #6f42c1; } .icon-orange { color: #fd7e14; } .icon-red { color: #dc3545; }
    .assignments-list-hod { display: flex; flex-direction: column; gap: 15px; }
    .assignment-item-hod { display: flex; align-items: center; gap: 15px; padding: 15px; background: #f8f9fa; border-radius: 6px; border-left: 5px solid #ccc; flex-wrap: wrap; }
    .status-submitted { border-left-color: #007bff; } .status-approved { border-left-color: #28a745; } .status-rejected { border-left-color: #dc3545; } .status-in-progress { border-left-color: #6f42c1; } .status-pending { border-left-color: #ffc107; }
    .item-main-info { flex: 1 1 300px; } .item-proofs { flex: 1 1 250px; display: flex; flex-direction: column; gap: 5px; } .item-actions { flex: 0 0 auto; } .review-form { display: flex; gap: 10px; align-items: center; }
    .user-form-container { background: #fdfdff; border: 1px solid #e9ecef; padding: 20px; border-radius: 8px; }
    .user-form, .user-form-inline { display: flex; flex-direction: column; gap: 15px; }
    .form-row { display: flex; gap: 20px; flex-wrap: wrap; }
    .form-group { flex: 1; display: flex; flex-direction: column; min-width: 200px; }
    .form-group label { margin-bottom: 5px; font-weight: 500; color: #555; }
    .form-group input, .form-group select, .form-group textarea { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; }
    .form-actions { display: flex; gap: 10px; justify-content: flex-end; align-items: center; }
    .user-filters { display: flex; gap: 15px; margin-bottom: 20px; background: #f8f9fa; padding: 15px; border-radius: 6px; }
    .data-table { width: 100%; border-collapse: collapse; margin-top: 20px; }
    .data-table th, .data-table td { padding: 12px 15px; border: 1px solid #e9ecef; text-align: left; vertical-align: middle; }
    .data-table thead { background-color: #f8f9fa; }
    .data-table tbody tr:nth-child(even) { background-color: #fdfdff; }
    .data-table tbody tr:hover { background-color: #e9ecef; }
    .data-table .actions { width: 150px; text-align: center; }
    .attachment-form { display: flex; gap: 5px; align-items: center; }
    .criterion-field { display: none; }
    
    /* Approval Hub Specific Styles */
    .pending-row { background-color: #fff3cd !important; }
    .approved-row { background-color: #d4edda !important; }
    .rejected-row { background-color: #f8d7da !important; }
    
    .approval-stats .stat-card {
        background: #fff;
        border: 1px solid #e9ecef;
        border-radius: 8px;
        padding: 20px;
        transition: all 0.2s ease-in-out;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
    
    .approval-stats .stat-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
    
    .approval-stats .stat-info h4 {
        margin: 0 0 5px 0;
        font-size: 0.9rem;
        color: #6c757d;
        font-weight: 500;
    }
    
    .approval-stats .stat-info span {
        font-size: 2rem;
        font-weight: bold;
        color: #2c3e50;
    }
    
    .approval-filters {
        background: #f8f9fa;
        padding: 15px;
        border-radius: 8px;
        border: 1px solid #e9ecef;
        margin-bottom: 20px;
    }
    
    .approval-filters form {
        display: flex;
        gap: 15px;
        align-items: center;
        flex-wrap: wrap;
    }
    
    .approval-filters .form-group {
        margin: 0;
    }
    
    .approval-filters label {
        margin-bottom: 5px;
        font-weight: 500;
        color: #495057;
    }
    
    .approval-filters select {
        padding: 8px;
        border: 1px solid #ddd;
        border-radius: 4px;
        background: #fff;
    }
    
    .approval-table-container {
        overflow-x: auto;
        border-radius: 8px;
        border: 1px solid #e9ecef;
    }
    
    .data-table .pending-row:hover {
        background-color: #ffeaa7 !important;
    }
    
    .data-table .approved-row:hover {
        background-color: #c3e6cb !important;
    }
    
    .data-table .rejected-row:hover {
        background-color: #f5c6cb !important;
    }
    
    .btn-action {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        padding: 5px 10px;
        border-radius: 4px;
        text-decoration: none;
        transition: all 0.2s ease;
    }
    
    .btn-action:hover {
        transform: translateY(-1px);
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    
    .btn-download {
        background: #e3f2fd;
        border: 1px solid #2196f3;
        color: #1976d2;
    }
    
    .btn-download:hover {
        background: #bbdefb;
        color: #1565c0;
    }
</style>

<!-- HEADER AND SIDEBAR HTML -->
<header class="main-header">
    <button id="menu-toggle" title="Toggle Menu"><i class="fas fa-bars icon-hamburger"></i><i class="fas fa-times icon-close"></i></button>
    <div class="header-title">Admin Dashboard</div>
    <a href="logout.php" class="logout-button" title="Logout"><i class="fas fa-sign-out-alt"></i></a>
</header>
<div class="overlay"></div>
<div class="sidebar">
    <div class="sidebar-header"><h3><i class="fas fa-user-shield"></i> Admin Menu</h3></div>
    <ul class="sidebar-nav">
        <li><a href="#overall-progress" class="nav-link"><i class="fas fa-chart-pie"></i> Overall Progress</a></li>
        <li><a href="#approval-hub" class="nav-link"><i class="fas fa-check-double"></i> Approval Hub</a></li>
        <li><a href="#department-progress" class="nav-link"><i class="fas fa-chart-bar"></i> Department Progress</a></li>
        <li><a href="#urgent-tasks" class="nav-link"><i class="fas fa-exclamation-triangle"></i> Urgent Tasks</a></li>
        <li><a href="#task-hub" class="nav-link"><i class="fas fa-list-check"></i> Task Management Hub</a></li>
        <li><a href="#user-management" class="nav-link"><i class="fas fa-users-cog"></i> Manage Users</a></li>
        <li><a href="#criteria-metrics" class="nav-link"><i class="fas fa-sitemap"></i> Manage Criteria & Metrics</a></li>
        <li><a href="#job-descriptions" class="nav-link"><i class="fas fa-briefcase"></i> Manage Job Descriptions</a></li>
        <li><a href="#metric-attachments" class="nav-link"><i class="fas fa-paperclip"></i> Manage Attachments</a></li>
    </ul>
</div>

<!-- MAIN CONTENT AREA -->
<main class="main-content">
    <?php if (isset($_SESSION['message'])): ?>
    <div class="message <?php echo $_SESSION['message']['type']; ?>"><?php echo htmlspecialchars($_SESSION['message']['text']); unset($_SESSION['message']); ?></div>
    <?php endif; ?>

    <!-- Section 1: Overall Progress -->
    <div id="overall-progress" class="dashboard-section">
        <h2><i class="fas fa-chart-pie"></i> Overall Progress</h2>
        <div class="department-filter-form">
            <h4><i class="fas fa-filter"></i> Filter Progress by Department</h4>
            <form action="admin_dashboard.php#overall-progress" method="GET">
                <div class="checkbox-group">
                    <div class="checkbox-item"><input type="checkbox" id="select-all-depts" style="width: 1.1em; height: 1.1em;"><label for="select-all-depts" style="white-space: nowrap; font-weight: bold;">Select All</label></div>
                    <?php foreach ($departments_array as $dept): ?>
                    <div class="checkbox-item">
                        <input type="checkbox" name="departments[]" class="dept-checkbox" id="dept-<?php echo $dept['id']; ?>" value="<?php echo $dept['id']; ?>" <?php if (in_array($dept['id'], $selected_dept_ids)) echo 'checked'; ?>>
                        <label for="dept-<?php echo $dept['id']; ?>" style="white-space: nowrap;"><?php echo htmlspecialchars($dept['name']); ?></label>
                    </div>
                    <?php endforeach; ?>
                </div>
                <div class="filter-buttons">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> Apply</button>
                    <a href="admin_dashboard.php#overall-progress" class="btn btn-secondary">Reset</a>
                </div>
            </form>
        </div>
        <div class="stats-container">
            <?php foreach ($stats as $status => $count):
                $icon_class = ['Approved' => 'fa-check-circle','Submitted' => 'fa-paper-plane','In Progress' => 'fa-spinner fa-spin','Pending' => 'fa-clock','Rejected' => 'fa-times-circle'];
                $color_class = ['Approved' => 'green','Submitted' => 'blue','In Progress' => 'purple','Pending' => 'orange','Rejected' => 'red'];
                $is_active = ($filter_status === $status) ? 'active-filter' : '';
                $dept_query_string = http_build_query(['departments' => $selected_dept_ids]);
            ?>
            <div class="stat-card <?php echo $is_active; ?>">
                <a href="admin_dashboard.php?filter=<?php echo urlencode($status); ?>&<?php echo $dept_query_string; ?>#task-hub" class="stat-link">
                    <i class="fas <?php echo $icon_class[$status] ?? 'fa-question-circle'; ?> icon-<?php echo $color_class[$status] ?? 'grey'; ?>"></i>
                    <div class="stat-info">
                        <h4><?php echo htmlspecialchars($status); ?></h4>
                        <span><?php echo $count; ?></span>
                    </div>
                </a>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    
    <!-- Section 2: Approval Hub -->
    <div id="approval-hub" class="dashboard-section">
        <h2><i class="fas fa-check-double"></i> Document Approval Hub</h2>
        <p>Review and approve/reject change requests for criterion templates and metric attachments submitted by criterion leads.</p>
        
        <!-- Approval Statistics -->
        <div class="approval-stats" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 25px;">
            <div class="stat-card" style="border-left: 4px solid #ffc107;">
                <div class="stat-info">
                    <h4>Pending Requests</h4>
                    <span id="pending-count"><?php echo $approval_stats['Pending']; ?></span>
                </div>
                <i class="fas fa-clock" style="color: #ffc107;"></i>
            </div>
            <div class="stat-card" style="border-left: 4px solid #28a745;">
                <div class="stat-info">
                    <h4>Approved</h4>
                    <span id="approved-count"><?php echo $approval_stats['Approved']; ?></span>
                </div>
                <i class="fas fa-check-circle" style="color: #28a745;"></i>
            </div>
            <div class="stat-card" style="border-left: 4px solid #dc3545;">
                <div class="stat-info">
                    <h4>Rejected</h4>
                    <span id="rejected-count"><?php echo $approval_stats['Rejected']; ?></span>
                </div>
                <i class="fas fa-times-circle" style="color: #dc3545;"></i>
            </div>
        </div>

        <!-- Filter Options -->
        <div class="approval-filters" style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
            <div style="display: flex; gap: 15px; align-items: center; flex-wrap;">
                <div class="form-group" style="margin: 0;">
                    <label style="margin-bottom: 5px; font-weight: 500;">Filter by Status:</label>
                    <select name="approval_status" id="approval_status_filter" style="padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                        <option value="all" >All Requests</option>
                        <option value="Pending" >Pending Only</option>
                        <option value="Approved" >Approved</option>
                        <option value="Rejected" >Rejected</option>
                    </select>
                </div>
                <div class="form-group" style="margin: 0;">
                    <label style="margin-bottom: 5px; font-weight: 500;">Filter by Type:</label>
                    <select name="update_type" id="update_type_filter" style="padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                        <option value="all" >All Types</option>
                        <option value="criterion_template" >Criterion Templates</option>
                        <option value="metric_attachment" >Metric Attachments</option>
                    </select>
                </div>
                <a href="admin_dashboard.php#approval-hub" class="btn btn-secondary btn-sm">Clear Filters</a>
            </div>
        </div>

        <!-- Enhanced Approval Table -->
        <div class="approval-table-container" style="overflow-x: auto;">
            <table class="data-table">
                <thead>
                    <tr>
                        <th style="min-width: 150px;">Requested By</th>
                        <th style="min-width: 200px;">Request Details</th>
                        <th style="min-width: 250px;">Files Comparison</th>
                        <th style="min-width: 300px;">Actions</th>
                    </tr>
                </thead>
                <tbody id="approval-table-body">
                    <?php 
                    // Enhanced query with filters
                    $where_clauses = [];
                    $params = [];
                    $types = '';
                    
                    $where_sql = '';
                    if (!empty($where_clauses)) {
                        $where_sql = "WHERE " . implode(' AND ', $where_clauses);
                    }
                    
                    $enhanced_query = "
                        SELECT 
                            pu.*, 
                            u.name AS requester_name,
                            u.email AS requester_email,
                            CASE 
                                WHEN pu.update_type = 'criterion_template' THEN c.name 
                                ELSE m.name 
                            END as target_name,
                            CASE 
                                WHEN pu.update_type = 'criterion_template' THEN ct.file_path
                                ELSE ma.file_path
                            END as current_file_path,
                            CASE 
                                WHEN pu.update_type = 'criterion_template' THEN ct.original_filename
                                ELSE ma.original_filename
                            END as current_filename
                        FROM pending_updates pu
                        JOIN users u ON pu.requested_by_user_id = u.id
                        LEFT JOIN criteria c ON pu.target_id = c.id AND pu.update_type = 'criterion_template'
                        LEFT JOIN metrics m ON pu.target_id = m.id AND pu.update_type = 'metric_attachment'
                        LEFT JOIN criterion_templates ct ON pu.target_id = ct.criterion_id AND pu.update_type = 'criterion_template'
                        LEFT JOIN metric_attachments ma ON pu.target_id = ma.metric_id AND pu.update_type = 'metric_attachment'
                        $where_sql
                        ORDER BY pu.requested_at DESC
                    ";
                    
                    if (!empty($params)) {
                        $stmt = $mysqli->prepare($enhanced_query);
                        $stmt->bind_param($types, ...$params);
                        $stmt->execute();
                        $enhanced_result = $stmt->get_result();
                    } else {
                        $enhanced_result = $mysqli->query($enhanced_query);
                    }
                    
                    if ($enhanced_result && $enhanced_result->num_rows > 0): 
                        while($req = $enhanced_result->fetch_assoc()): 
                    ?>
                        <tr class="approval-request-row <?php echo $req['status'] === 'Pending' ? 'pending-row' : ($req['status'] === 'Approved' ? 'approved-row' : 'rejected-row'); ?>" data-status="<?php echo $req['status']; ?>" data-type="<?php echo $req['update_type']; ?>">
                            <td>
                                <div style="display: flex; flex-direction: column; gap: 5px;">
                                    <strong><?php echo htmlspecialchars($req['requester_name']); ?></strong>
                                    <small class="text-muted"><?php echo htmlspecialchars($req['requester_email']); ?></small>
                                    <small class="text-muted"><?php echo date('d M, Y H:i', strtotime($req['requested_at'])); ?></small>
                                    <?php if ($req['status'] !== 'Pending'): ?>
                                        <small class="text-muted">Reviewed: <?php echo date('d M, Y H:i', strtotime($req['reviewed_at'])); ?></small>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td>
                                <div style="display: flex; flex-direction: column; gap: 5px;">
                                    <div>
                                        <span class="badge <?php echo $req['update_type'] === 'criterion_template' ? 'bg-primary' : 'bg-info'; ?>" style="font-size: 0.8em;">
                                            <?php echo str_replace('_', ' ', ucwords($req['update_type'])); ?>
                                        </span>
                                    </div>
                                    <strong><?php echo htmlspecialchars($req['target_name']); ?></strong>
                                    <?php if ($req['status'] !== 'Pending' && !empty($req['remarks'])): ?>
                                        <div style="margin-top: 5px;">
                                            <small><strong>Remarks:</strong> <?php echo htmlspecialchars($req['remarks']); ?></small>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td>
                                <div style="display: flex; flex-direction: column; gap: 8px;">
                                    <div>
                                        <a href="<?php echo htmlspecialchars($req['new_file_path']); ?>" target="_blank" class="btn-action btn-download" title="Download Proposed File" style="display: inline-flex; align-items: center; gap: 5px; padding: 5px 10px; background: #e3f2fd; border: 1px solid #2196f3; border-radius: 4px; text-decoration: none; color: #1976d2;">
                                            <i class="fas fa-file-download"></i> 
                                            <span><strong>New:</strong> <?php echo htmlspecialchars($req['original_filename']); ?></span>
                                        </a>
                                    </div>
                                    <?php if ($req['current_file_path']): ?>
                                        <div>
                                            <a href="<?php echo htmlspecialchars($req['current_file_path']); ?>" target="_blank" class="btn-action" title="Download Current File" style="display: inline-flex; align-items: center; gap: 5px; padding: 5px 10px; background: #f5f5f5; border: 1px solid #ddd; border-radius: 4px; text-decoration: none; color: #666;">
                                                <i class="fas fa-file"></i> 
                                                <span><strong>Current:</strong> <?php echo htmlspecialchars($req['current_filename']); ?></span>
                                            </a>
                                        </div>
                                    <?php else: ?>
                                        <div>
                                            <span class="text-muted" style="display: inline-flex; align-items: center; gap: 5px; padding: 5px 10px; background: #f9f9f9; border: 1px solid #eee; border-radius: 4px;">
                                                <i class="fas fa-file"></i> 
                                                <span>No Current File</span>
                                            </span>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td class="actions">
                                <?php if ($req['status'] === 'Pending'): ?>
                                    <form action="admin_actions.php" method="POST" onsubmit="return confirm('Please confirm your action. This cannot be undone.');" style="display: flex; flex-direction: column; gap: 10px;">
                                        <input type="hidden" name="action" value="review_file_update">
                                        <input type="hidden" name="request_id" value="<?php echo $req['id']; ?>">
                                        <div class="form-group" style="margin: 0;">
                                            <textarea name="remarks" class="form-control-sm" placeholder="Add remarks (required for rejection)..." style="width: 100%; min-height: 60px; resize: vertical;" required></textarea>
                                        </div>
                                        <div class="form-actions" style="display: flex; gap: 10px; justify-content: center;">
                                            <button type="submit" name="decision" value="Approve" class="btn btn-success btn-sm" title="Approve Request" style="flex: 1; max-width: 120px;">
                                                <i class="fas fa-check"></i> Approve
                                            </button>
                                            <button type="submit" name="decision" value="Reject" class="btn btn-danger btn-sm" title="Reject Request" style="flex: 1; max-width: 120px;">
                                                <i class="fas fa-times"></i> Reject
                                            </button>
                                        </div>
                                    </form>
                                <?php else: ?>
                                    <div style="text-align: center;">
                                        <span class="badge <?php echo $req['status'] === 'Approved' ? 'bg-success' : 'bg-danger'; ?>" style="font-size: 1em; padding: 8px 12px;">
                                            <?php echo $req['status']; ?>
                                        </span>
                                    </div>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="4" style="text-align: center; padding: 40px; color: #666;">
                                <i class="fas fa-inbox" style="font-size: 3em; margin-bottom: 15px; display: block; color: #ddd;"></i>
                                <strong>No approval requests found</strong><br>
                                <small>There are no requests matching your current filters.</small>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Section 3: Department-wise Progress -->
    <div id="department-progress" class="dashboard-section"><h2><i class="fas fa-chart-bar"></i> Department-wise Progress</h2><div class="chart-box"><canvas id="deptPerfChart"></canvas></div></div>

    <!-- Section 4: Urgent Tasks -->
    <div id="urgent-tasks" class="dashboard-section">
        <h2><i class="fas fa-exclamation-triangle"></i> Urgent Tasks (Due in Next 7 Days)</h2>
        <div class="assignments-list-hod">
            <?php if($urgent_tasks_result && $urgent_tasks_result->num_rows > 0): 
                while($task = $urgent_tasks_result->fetch_assoc()): ?>
                <div class="assignment-item-hod status-pending">
                    <div class="item-main-info"><strong><?php echo htmlspecialchars($task['metric_name']); ?></strong><span class="badge bg-secondary"><?php echo htmlspecialchars($task['department_name']); ?></span><br><small>Assigned to: <?php echo htmlspecialchars($task['assignees']); ?> | <strong>Due: <?php echo date("d M, Y", strtotime($task['due_date'])); ?></strong></small></div>
                </div>
                <?php endwhile; 
            else: ?>
                <p>No urgent tasks due within the next 7 days.</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Section 5: Task Management Hub -->
    <div id="task-hub" class="dashboard-section">
        <h2><i class="fas fa-list-check"></i> Task Management Hub: <?php echo htmlspecialchars($filter_status); ?> Tasks</h2>
        <div class="assignments-list-hod">
            <?php if ($tasks_result && $tasks_result->num_rows > 0): 
                while($task = $tasks_result->fetch_assoc()): ?>
                <div class="assignment-item-hod status-<?php echo strtolower(str_replace(' ', '-', $task['status'])); ?>">
                    <div class="item-main-info"><strong><?php echo htmlspecialchars($task['metric_name']); ?></strong><br><small>Assigned to: <?php echo htmlspecialchars($task['faculty_names']); ?> | Due: <?php echo date("d M, Y", strtotime($task['due_date'])); ?></small></div>
                    <div class="item-status"><span class="status-badge"><?php echo htmlspecialchars($task['status']); ?></span></div>
                    <div class="item-proofs">
                        <?php 
                        $proof_stmt = $mysqli->prepare("SELECT p.file_path, p.original_filename FROM proofs p JOIN task_assignees ta ON p.task_assignee_id = ta.id WHERE ta.task_id = ?");
                        if($proof_stmt){ $proof_stmt->bind_param("i", $task['id']); $proof_stmt->execute(); $proofs = $proof_stmt->get_result(); if ($proofs->num_rows > 0) { while($proof = $proofs->fetch_assoc()) { echo '<a href="' . htmlspecialchars($proof['file_path']) . '" class="btn-action btn-download" target="_blank" title="Download ' . htmlspecialchars($proof['original_filename']) . '"><i class="fas fa-download"></i> ' . htmlspecialchars(substr($proof['original_filename'], 0, 30)) . (strlen($proof['original_filename']) > 30 ? '...' : '') . '</a>'; } } else { echo '<span class="no-proof text-muted">No Proofs</span>'; } $proof_stmt->close(); } 
                        ?>
                    </div>
                    <div class="item-actions">
                        <?php if ($task['status'] == 'Submitted'): ?>
                        <form action="admin_actions.php" method="POST" class="review-form" onsubmit="return confirm('Are you sure you want to ' + this.decision.value + ' this task?');">
                            <input type="hidden" name="action" value="review_task_admin"><input type="hidden" name="task_id" value="<?php echo $task['id']; ?>">
                            <input type="text" name="remarks" placeholder="Add remarks (required for rejection)..." class="form-control-sm" style="min-width: 200px;">
                            <button type="submit" name="decision" value="Approve" class="btn-action btn-approve" title="Approve"><i class="fas fa-check"></i></button>
                            <button type="submit" name="decision" value="Reject" class="btn-action btn-reject" title="Reject"><i class="fas fa-times"></i></button>
                        </form>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endwhile; 
            else: ?>
                <p>No tasks found for the current filter combination.</p>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Section 6: Manage Users -->
    <div id="user-management" class="dashboard-section">
        <h2><i class="fas fa-users-cog"></i> Manage Users</h2>
        <div class="user-form-container">
            <h4><i class="fas fa-user-plus"></i> Add New User</h4>
            <form action="admin_actions.php" method="POST" class="user-form">
                <input type="hidden" name="action" value="add_user">
                <div class="form-row"><div class="form-group"><label for="add-name">Full Name</label><input type="text" id="add-name" name="name" required></div><div class="form-group"><label for="add-email">Email Address</label><input type="email" id="add-email" name="email" required></div></div>
                <div class="form-row"><div class="form-group"><label for="add-employee_id">Employee ID</label><input type="text" id="add-employee_id" name="employee_id"></div><div class="form-group"><label for="add-password">Set Password</label><input type="password" id="add-password" name="password" required></div></div>
                <div class="form-row">
                    <div class="form-group"><label for="add-role_id">Role</label><select id="add-role_id" name="role_id" class="role-selector" required><option value="">-- Select Role --</option><?php foreach($roles_array as $role): ?><option value="<?php echo $role['id']; ?>"><?php echo htmlspecialchars($role['name']); ?></option><?php endforeach; ?></select></div>
                    <div class="form-group"><label for="add-department_id">Department</label><select id="add-department_id" name="department_id"><option value="">-- None --</option><?php foreach($departments_array as $dept): ?><option value="<?php echo $dept['id']; ?>"><?php echo htmlspecialchars($dept['name']); ?></option><?php endforeach; ?></select></div>
                </div>
                <div class="form-row">
                    <div class="form-group" style="flex: 1;"><label for="add-job_description_id">Job Description</label><select id="add-job_description_id" name="job_description_id"><option value="">-- None --</option><?php foreach($job_descriptions_array as $desc): ?><option value="<?php echo $desc['id']; ?>"><?php echo htmlspecialchars($desc['name']); ?></option><?php endforeach; ?></select></div>
                    <div class="form-group criterion-field" style="flex: 1;">
                        <label for="add-criterion_id">Leads Criterion</label><select id="add-criterion_id" name="criterion_id"><option value="">-- Select Criterion --</option><?php foreach($criteria_array as $crit): ?><option value="<?php echo $crit['id']; ?>"><?php echo htmlspecialchars($crit['name']); ?></option><?php endforeach; ?></select>
                    </div>
                </div>
                <div class="form-actions"><button type="submit" class="btn btn-primary"><i class="fas fa-plus"></i> Add User</button></div>
            </form>
        </div>
        <hr style="margin: 30px 0;">
        <h4><i class="fas fa-list"></i> Existing Users List</h4>
        <div class="user-filters">
            <form action="admin_dashboard.php#user-management" method="GET" style="display: contents;">
                <div class="form-group"><label for="filter_role_id">Filter by Role</label><select name="filter_role_id" id="filter_role_id" class="form-control"><option value="all">All Roles</option><?php foreach($roles_array as $role): ?><option value="<?php echo $role['id']; ?>" <?php if($filter_role_id == $role['id']) echo 'selected'; ?>><?php echo htmlspecialchars($role['name']); ?></option><?php endforeach; ?></select></div>
                <div class="form-group"><label for="filter_dept_id">Filter by Department</label><select name="filter_dept_id" id="filter_dept_id" class="form-control"><option value="all">All Departments</option><?php foreach($departments_array as $dept): ?><option value="<?php echo $dept['id']; ?>" <?php if($filter_dept_id == $dept['id']) echo 'selected'; ?>><?php echo htmlspecialchars($dept['name']); ?></option><?php endforeach; ?></select></div>
                <div class="form-actions"><button type="submit" class="btn btn-primary">Filter</button><a href="admin_dashboard.php#user-management" class="btn btn-secondary">Reset</a></div>
            </form>
        </div>
        <table class="data-table">
            <thead><tr><th>Name / Emp ID</th><th>Email</th><th>Role</th><th>Department</th><th>Leads Criterion</th><th>Actions</th></tr></thead>
            <tbody>
                <?php if ($users_result && $users_result->num_rows > 0): while($user = $users_result->fetch_assoc()): ?>
                <tr id="user-display-<?php echo $user['id']; ?>">
                    <td><?php echo htmlspecialchars($user['name']); ?><br><small class="text-muted">ID: <?php echo htmlspecialchars($user['employee_id'] ?? 'N/A'); ?></small></td>
                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                    <td><span class="badge bg-secondary"><?php echo htmlspecialchars($user['role_name']); ?></span></td>
                    <td><?php echo htmlspecialchars($user['department_name'] ?? 'N/A'); ?></td>
                    <td><span class="badge bg-info text-dark"><?php echo htmlspecialchars($user['criterion_name'] ?? 'N/A'); ?></span></td>
                    <td class="actions">
                        <button class="btn-action btn-edit" onclick="toggleEditForm(<?php echo $user['id']; ?>)" title="Edit"><i class="fas fa-edit"></i></button>
                        <form action="admin_actions.php" method="POST" onsubmit="return confirm('Delete this user? This cannot be undone.');" style="display:inline;"><input type="hidden" name="action" value="delete_user"><input type="hidden" name="user_id" value="<?php echo $user['id']; ?>"><button type="submit" class="btn-action btn-delete" title="Delete" <?php if ($user['id'] == $_SESSION['user_id']) echo 'disabled'; ?>><i class="fas fa-trash"></i></button></form>
                    </td>
                </tr>
                <tr id="user-edit-<?php echo $user['id']; ?>" style="display: none;">
                    <td colspan="6" style="background-color: #f0f8ff;">
                        <form action="admin_actions.php" method="POST" class="user-form-inline">
                            <input type="hidden" name="action" value="edit_user"><input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                            <div class="form-row"><div class="form-group"><label>Name</label><input type="text" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required></div><div class="form-group"><label>Email</label><input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required></div></div>
                            <div class="form-row"><div class="form-group"><label>Employee ID</label><input type="text" name="employee_id" value="<?php echo htmlspecialchars($user['employee_id']); ?>"></div><div class="form-group"><label>New Password</label><input type="password" name="password" placeholder="Leave blank to keep current"></div></div>
                            <div class="form-row">
                                <div class="form-group"><label>Role</label><select name="role_id" class="role-selector" required><?php foreach($roles_array as $role): ?><option value="<?php echo $role['id']; ?>" <?php if($user['role_id'] == $role['id']) echo 'selected'; ?>><?php echo htmlspecialchars($role['name']); ?></option><?php endforeach; ?></select></div>
                                <div class="form-group"><label>Department</label><select name="department_id"><option value="">-- None --</option><?php foreach($departments_array as $dept): ?><option value="<?php echo $dept['id']; ?>" <?php if($user['department_id'] == $dept['id']) echo 'selected'; ?>><?php echo htmlspecialchars($dept['name']); ?></option><?php endforeach; ?></select></div>
                            </div>
                            <div class="form-row">
                                <div class="form-group" style="flex: 1;"><label>Job Description</label><select name="job_description_id"><option value="">-- None --</option><?php foreach($job_descriptions_array as $desc): ?><option value="<?php echo htmlspecialchars($desc['id']); ?>" <?php if($user['job_description_id'] == $desc['id']) echo 'selected'; ?>><?php echo htmlspecialchars($desc['name']); ?></option><?php endforeach; ?></select></div>
                                <div class="form-group criterion-field" style="flex: 1;">
                                    <label>Leads Criterion</label><select name="criterion_id"><option value="">-- Select Criterion --</option><?php foreach($criteria_array as $crit): ?><option value="<?php echo $crit['id']; ?>" <?php if($user['criterion_id'] == $crit['id']) echo 'selected'; ?>><?php echo htmlspecialchars($crit['name']); ?></option><?php endforeach; ?></select>
                                </div>
                            </div>
                            <div class="form-actions"><button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save</button><button type="button" class="btn btn-secondary" onclick="toggleEditForm(<?php echo $user['id']; ?>, true)">Cancel</button></div>
                        </form>
                    </td>
                </tr>
                <?php endwhile; else: ?>
                <tr><td colspan="6">No users found matching the current filters.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Section 7: Manage Criteria & Metrics -->
    <div id="criteria-metrics" class="dashboard-section">
        <h2><i class="fas fa-sitemap"></i> Manage Criteria & Metrics</h2>
        <div class="grid-container-2col">
            <div class="grid-item">
                <div class="user-form-container">
                    <h4><i class="fas fa-plus-circle"></i> Add New Criterion</h4>
                    <form action="admin_actions.php" method="POST" class="user-form"><input type="hidden" name="action" value="add_criterion"><div class="form-group"><label for="add-criterion-name">Criterion Name</label><input type="text" id="add-criterion-name" name="name" required></div><div class="form-actions"><button type="submit" class="btn btn-primary"><i class="fas fa-plus"></i> Add Criterion</button></div></form>
                </div><hr style="margin: 30px 0;"><h4><i class="fas fa-list"></i> Existing Criteria</h4>
                <table class="data-table">
                    <thead><tr><th>Criterion Name</th><th>Metrics</th><th>Actions</th></tr></thead>
                    <tbody>
                        <?php if (!empty($criteria_array)): foreach($criteria_array as $crit):
                            $stmt_count = $mysqli->prepare("SELECT COUNT(*) FROM metrics WHERE criterion_id = ?"); $stmt_count->bind_param("i", $crit['id']); $stmt_count->execute(); $metric_count = $stmt_count->get_result()->fetch_row()[0]; $stmt_count->close(); ?>
                        <tr id="criterion-display-<?php echo $crit['id']; ?>"><td><?php echo htmlspecialchars($crit['name']); ?></td><td><?php echo $metric_count; ?></td>
                            <td class="actions"><button class="btn-action btn-edit" onclick="toggleCriterionEditForm(<?php echo $crit['id']; ?>)"><i class="fas fa-edit"></i></button><form action="admin_actions.php" method="POST" onsubmit="return confirm('Delete this criterion?');" style="display:inline;"><input type="hidden" name="action" value="delete_criterion"><input type="hidden" name="criterion_id" value="<?php echo $crit['id']; ?>"><button type="submit" class="btn-action btn-delete" <?php if ($metric_count > 0) echo 'disabled title="Cannot delete, has metrics"'; ?>><i class="fas fa-trash"></i></button></form></td>
                        </tr>
                        <tr id="criterion-edit-<?php echo $crit['id']; ?>" style="display: none;"><td colspan="3"><form action="admin_actions.php" method="POST" class="user-form-inline"><input type="hidden" name="action" value="edit_criterion"><input type="hidden" name="criterion_id" value="<?php echo $crit['id']; ?>"><div class="form-group" style="flex:1;"><label>Name</label><input type="text" name="name" value="<?php echo htmlspecialchars($crit['name']); ?>" required></div><div class="form-actions"><button type="submit" class="btn btn-primary">Save</button><button type="button" class="btn btn-secondary" onclick="toggleCriterionEditForm(<?php echo $crit['id']; ?>, true)">Cancel</button></div></form></td></tr>
                        <?php endforeach; else: ?><tr><td colspan="3">No criteria found.</td></tr><?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="grid-item">
                <div class="user-form-container">
                    <h4><i class="fas fa-plus-circle"></i> Add New Metric</h4>
                    <form action="admin_actions.php" method="POST" class="user-form"><input type="hidden" name="action" value="add_metric"><div class="form-group"><label for="add-metric-name">Metric Name</label><input type="text" id="add-metric-name" name="name" required></div><div class="form-group"><label for="add-metric-crit">Parent Criterion</label><select id="add-metric-crit" name="criterion_id" required><option value="">-- Select Criterion --</option><?php foreach($criteria_array as $crit): ?><option value="<?php echo $crit['id']; ?>"><?php echo htmlspecialchars($crit['name']); ?></option><?php endforeach; ?></select></div><div class="form-actions"><button type="submit" class="btn btn-primary"><i class="fas fa-plus"></i> Add Metric</button></div></form>
                </div><hr style="margin: 30px 0;"><h4><i class="fas fa-list"></i> Existing Metrics</h4>
                <table class="data-table">
                    <thead><tr><th>Metric Name</th><th>Parent Criterion</th><th>Actions</th></tr></thead>
                    <tbody>
                        <?php if (!empty($metrics_list)): foreach($metrics_list as $met): 
                            $stmt_count = $mysqli->prepare("SELECT COUNT(*) FROM tasks WHERE metric_id = ?"); $stmt_count->bind_param("i", $met['id']); $stmt_count->execute(); $task_count = $stmt_count->get_result()->fetch_row()[0]; $stmt_count->close(); ?>
                        <tr id="metric-display-<?php echo $met['id']; ?>"><td><?php echo htmlspecialchars($met['name']); ?></td><td><?php echo htmlspecialchars($met['criterion_name']); ?></td>
                            <td class="actions"><button class="btn-action btn-edit" onclick="toggleMetricEditForm(<?php echo $met['id']; ?>)"><i class="fas fa-edit"></i></button><form action="admin_actions.php" method="POST" onsubmit="return confirm('Delete this metric?');" style="display:inline;"><input type="hidden" name="action" value="delete_metric"><input type="hidden" name="metric_id" value="<?php echo $met['id']; ?>"><button type="submit" class="btn-action btn-delete" <?php if ($task_count > 0) echo 'disabled title="Cannot delete, used in tasks"'; ?>><i class="fas fa-trash"></i></button></form></td>
                        </tr>
                        <tr id="metric-edit-<?php echo $met['id']; ?>" style="display: none;"><td colspan="3"><form action="admin_actions.php" method="POST" class="user-form-inline"><input type="hidden" name="action" value="edit_metric"><input type="hidden" name="metric_id" value="<?php echo $met['id']; ?>"><div class="form-group" style="flex:1;"><label>Name</label><input type="text" name="name" value="<?php echo htmlspecialchars($met['name']); ?>" required></div><div class="form-group" style="flex:1;"><label>Criterion</label><select name="criterion_id" required><?php foreach($criteria_array as $crit): ?><option value="<?php echo $crit['id']; ?>" <?php if($met['criterion_id'] == $crit['id']) echo 'selected'; ?>><?php echo htmlspecialchars($crit['name']); ?></option><?php endforeach; ?></select></div><div class="form-actions"><button type="submit" class="btn btn-primary">Save</button><button type="button" class="btn btn-secondary" onclick="toggleMetricEditForm(<?php echo $met['id']; ?>, true)">Cancel</button></div></form></td></tr>
                        <?php endforeach; else: ?><tr><td colspan="3">No metrics found.</td></tr><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Section 8: Manage Job Descriptions -->
    <div id="job-descriptions" class="dashboard-section">
        <h2><i class="fas fa-briefcase"></i> Manage Job Descriptions</h2>
        <div class="user-form-container"><h4><i class="fas fa-plus-circle"></i> Add New Job Description</h4><form action="admin_actions.php" method="POST" class="user-form"><input type="hidden" name="action" value="add_job_description"><div class="form-row"><div class="form-group" style="flex: 1;"><label for="add-jd-name">Description Name</label><input type="text" id="add-jd-name" name="name" required></div></div><div class="form-actions"><button type="submit" class="btn btn-primary"><i class="fas fa-plus"></i> Add Description</button></div></form></div><hr style="margin: 30px 0;"><h4><i class="fas fa-list"></i> Existing Job Descriptions</h4>
        <table class="data-table">
            <thead><tr><th>Description Name</th><th>Users Assigned</th><th>Actions</th></tr></thead>
            <tbody>
                <?php if (!empty($job_descriptions_array)): foreach($job_descriptions_array as $jd):
                    $stmt_count = $mysqli->prepare("SELECT COUNT(*) FROM users WHERE job_description_id = ?"); $stmt_count->bind_param("i", $jd['id']); $stmt_count->execute(); $user_count = $stmt_count->get_result()->fetch_row()[0]; $stmt_count->close(); ?>
                <tr id="jd-display-<?php echo $jd['id']; ?>"><td><?php echo htmlspecialchars($jd['name']); ?></td><td><?php echo $user_count; ?></td>
                    <td class="actions"><button class="btn-action btn-edit" onclick="toggleJdEditForm(<?php echo $jd['id']; ?>)"><i class="fas fa-edit"></i></button><form action="admin_actions.php" method="POST" onsubmit="return confirm('Delete this description?');" style="display:inline;"><input type="hidden" name="action" value="delete_job_description"><input type="hidden" name="job_description_id" value="<?php echo $jd['id']; ?>"><button type="submit" class="btn-action btn-delete" <?php if ($user_count > 0) echo 'disabled title="Cannot delete, assigned to users"'; ?>><i class="fas fa-trash"></i></button></form></td>
                </tr>
                <tr id="jd-edit-<?php echo $jd['id']; ?>" style="display: none;"><td colspan="3"><form action="admin_actions.php" method="POST" class="user-form-inline"><input type="hidden" name="action" value="edit_job_description"><input type="hidden" name="job_description_id" value="<?php echo $jd['id']; ?>"><div class="form-row"><div class="form-group" style="flex: 1;"><label>Name</label><input type="text" name="name" value="<?php echo htmlspecialchars($jd['name']); ?>" required></div></div><div class="form-actions"><button type="submit" class="btn btn-primary">Save</button><button type="button" class="btn btn-secondary" onclick="toggleJdEditForm(<?php echo $jd['id']; ?>, true)">Cancel</button></div></form></td></tr>
                <?php endforeach; else: ?><tr><td colspan="3">No job descriptions found.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Section 9: Manage Metric Attachments -->
    <div id="metric-attachments" class="dashboard-section">
        <h2><i class="fas fa-paperclip"></i> Manage Metric Attachments</h2><p>Upload a standard document for a metric. This document will be visible to any user assigned a task for that metric. Uploading a new file will replace the existing one.</p>
        <table class="data-table"><thead><tr><th>Criterion</th><th>Metric Name</th><th>Current Attachment</th><th>Actions</th></tr></thead><tbody><?php if ($metrics_attachments_result && $metrics_attachments_result->num_rows > 0): while($metric = $metrics_attachments_result->fetch_assoc()): ?><tr><td><?php echo htmlspecialchars($metric['criterion_name']); ?></td><td><?php echo htmlspecialchars($metric['metric_name']); ?></td><td><?php if ($metric['file_path']): ?><a href="<?php echo htmlspecialchars($metric['file_path']); ?>" target="_blank"><i class="fas fa-file-alt"></i> <?php echo htmlspecialchars($metric['original_filename']); ?></a><?php else: ?><span class="text-muted">None</span><?php endif; ?></td><td class="actions"><form action="admin_actions.php" method="POST" enctype="multipart/form-data" class="attachment-form"><input type="hidden" name="action" value="upload_metric_attachment"><input type="hidden" name="metric_id" value="<?php echo $metric['metric_id']; ?>"><input type="file" name="attachment_file" class="form-control-sm" required><button type="submit" class="btn-action btn-upload" title="Upload/Replace File"><i class="fas fa-upload"></i></button></form><?php if ($metric['file_path']): ?><form action="admin_actions.php" method="POST" onsubmit="return confirm('Delete this attachment?');" style="display:inline;"><input type="hidden" name="action" value="delete_metric_attachment"><input type="hidden" name="metric_id" value="<?php echo $metric['metric_id']; ?>"><button type="submit" class="btn-action btn-delete" title="Delete Attachment"><i class="fas fa-trash"></i></button></form><?php endif; ?></td></tr><?php endwhile; else: ?><tr><td colspan="4">No metrics found.</td></tr><?php endif; ?></tbody></table>
    </div>
</main>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // --- Menu and Tab Navigation ---
    const body = document.body;
    const menuToggle = document.getElementById('menu-toggle');
    const sidebar = document.querySelector('.sidebar');
    const overlay = document.querySelector('.overlay');
    const navLinks = document.querySelectorAll('.sidebar-nav .nav-link');
    const sections = document.querySelectorAll('.main-content .dashboard-section');

    const openMenu = () => { body.classList.add('menu-open'); sidebar.classList.add('show'); overlay.classList.add('show'); };
    const closeMenu = () => { body.classList.remove('menu-open'); sidebar.classList.remove('show'); overlay.classList.remove('show'); };

    menuToggle.addEventListener('click', e => { e.stopPropagation(); sidebar.classList.contains('show') ? closeMenu() : openMenu(); });
    overlay.addEventListener('click', closeMenu);

    const showSection = (targetId) => {
        sections.forEach(s => s.classList.remove('active'));
        navLinks.forEach(l => l.classList.remove('active'));
        const targetSection = document.querySelector(targetId);
        const targetLink = document.querySelector(`.sidebar-nav .nav-link[href="${targetId}"]`);
        if (targetSection) targetSection.classList.add('active');
        if (targetLink) targetLink.classList.add('active');
    };

    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            history.pushState(null, null, targetId);
            showSection(targetId);
            closeMenu();
        });
    });

    window.addEventListener('popstate', () => { showSection(window.location.hash || '#overall-progress'); });
    showSection(window.location.hash || '#overall-progress');

    // --- Chart Logic ---
    const deptPerfCanvas = document.getElementById('deptPerfChart');
    if (deptPerfCanvas) {
        const rawData = <?php echo json_encode($dept_perf_data); ?>;
        const processDeptPerfData = data => { const labels = [...new Set(data.map(item => item.department_name))]; const statuses = ['Approved', 'Submitted', 'In Progress', 'Pending', 'Rejected']; const statusColors = {'Approved': '#28a745', 'Submitted': '#007bff', 'In Progress': '#6f42c1', 'Pending': '#ffc107', 'Rejected': '#dc3545'}; const hodMap = {}; labels.forEach(label => { const item = data.find(d => d.department_name === label); hodMap[label] = item ? (item.hod_name || 'Not Assigned') : 'Not Assigned'; }); const datasets = statuses.map(status => ({ label: status, data: labels.map(label => { const item = data.find(d => d.department_name === label && d.status === status); return item ? item.count : 0; }), backgroundColor: statusColors[status] })); return { labels, datasets, hodMap }; };
        const chartData = processDeptPerfData(rawData);
        new Chart(deptPerfCanvas, { type: 'bar', data: { labels: chartData.labels, datasets: chartData.datasets }, options: { responsive: true, maintainAspectRatio: false, scales: { x: { stacked: true }, y: { stacked: true } }, plugins: { legend: { position: 'top' }, tooltip: { callbacks: { afterTitle: context => `HOD: ${chartData.hodMap[context[0].label]}` } } } } });
    }
    
    // --- Filter Logic ---
    document.getElementById('select-all-depts')?.addEventListener('change', e => { document.querySelectorAll('.dept-checkbox').forEach(checkbox => checkbox.checked = e.target.checked); });
    document.getElementById('filter_role_id')?.addEventListener('change', function() { this.form.submit(); });
    document.getElementById('filter_dept_id')?.addEventListener('change', function() { this.form.submit(); });

    // --- User Form 'Criterion Lead' Logic ---
    const CRITERION_LEAD_ROLE_ID = 3; 
    
    const handleRoleChange = (roleSelector) => {
        const form = roleSelector.closest('form, td');
        const criterionField = form.querySelector('.criterion-field');
        if (!criterionField) return;
        
        const criterionSelect = criterionField.querySelector('select');
        
        if (parseInt(roleSelector.value) === CRITERION_LEAD_ROLE_ID) {
            criterionField.style.display = 'block';
            criterionSelect.setAttribute('required', 'required');
        } else {
            criterionField.style.display = 'none';
            criterionSelect.removeAttribute('required');
            criterionSelect.value = '';
        }
    };

    document.querySelectorAll('.role-selector').forEach(selector => {
        selector.addEventListener('change', () => handleRoleChange(selector));
        handleRoleChange(selector); // Run on page load for edit forms
    });

    // --- Approval Hub Filtering ---
    const statusFilter = document.getElementById('approval_status_filter');
    const typeFilter = document.getElementById('update_type_filter');
    const tableBody = document.getElementById('approval-table-body');
    const requestRows = tableBody.querySelectorAll('.approval-request-row');
    const pendingCountSpan = document.querySelector('#pending-count');
    const approvedCountSpan = document.querySelector('#approved-count');
    const rejectedCountSpan = document.querySelector('#rejected-count');

    function filterApprovalRequests() {
        const selectedStatus = statusFilter.value;
        const selectedType = typeFilter.value;
        let visiblePending = 0;
        let visibleApproved = 0;
        let visibleRejected = 0;

        requestRows.forEach(row => {
            const rowStatus = row.dataset.status;
            const rowType = row.dataset.type;
            const statusMatch = selectedStatus === 'all' || selectedStatus === rowStatus;
            const typeMatch = selectedType === 'all' || selectedType === rowType;

            if (statusMatch && typeMatch) {
                row.style.display = '';
                if (rowStatus === 'Pending') visiblePending++;
                if (rowStatus === 'Approved') visibleApproved++;
                if (rowStatus === 'Rejected') visibleRejected++;
            } else {
                row.style.display = 'none';
            }
        });

        pendingCountSpan.textContent = visiblePending;
        approvedCountSpan.textContent = visibleApproved;
        rejectedCountSpan.textContent = visibleRejected;
    }

    statusFilter.addEventListener('change', filterApprovalRequests);
    typeFilter.addEventListener('change', filterApprovalRequests);
    
    // Initial filter on page load
    filterApprovalRequests();
});

// --- Generic Toggle Functions ---
function toggleGenericEditForm(type, id, cancel = false) {
    const displayRow = document.getElementById(`${type}-display-${id}`);
    const editRow = document.getElementById(`${type}-edit-${id}`);
    if (displayRow && editRow) {
        if (cancel) {
            displayRow.style.display = '';
            editRow.style.display = 'none';
        } else {
            displayRow.style.display = 'none';
            editRow.style.display = '';
        }
    }
}
function toggleEditForm(id, cancel = false) { toggleGenericEditForm('user', id, cancel); }
function toggleJdEditForm(id, cancel = false) { toggleGenericEditForm('jd', id, cancel); }
function toggleCriterionEditForm(id, cancel = false) { toggleGenericEditForm('criterion', id, cancel); }
function toggleMetricEditForm(id, cancel = false) { toggleGenericEditForm('metric', id, cancel); }
</script>

<?php require_once 'includes/footer.php'; ?>