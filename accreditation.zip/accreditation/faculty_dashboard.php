<?php
// --- ALL PHP DATA FETCHING (UNCHANGED) ---
require_once 'includes/auth_check.php';
require_once 'config/db.php';

if ($_SESSION['user_role'] !== 'Faculty') { die("Access Denied."); }

$page_title = 'My Dashboard';
require_once 'includes/header.php';

$user_id = $_SESSION['user_id'];

$user_name = '';
$stmt_user = $mysqli->prepare("SELECT name FROM users WHERE id = ?");
$stmt_user->bind_param("i", $user_id);
$stmt_user->execute();
$user_res = $stmt_user->get_result();
if ($user_res->num_rows > 0) { $user_name = $user_res->fetch_assoc()['name']; }
$stmt_user->close();

$task_counts = ['Pending' => 0, 'Approved' => 0, 'Rejected' => 0];
$stmt_counts = $mysqli->prepare("SELECT t.status, COUNT(t.id) as count FROM tasks t JOIN task_assignees ta ON t.id = ta.task_id WHERE ta.user_id = ? AND t.status IN ('Pending', 'Approved', 'Rejected') GROUP BY t.status");
$stmt_counts->bind_param("i", $user_id);
$stmt_counts->execute();
$counts_result = $stmt_counts->get_result();
while ($row = $counts_result->fetch_assoc()) { if (isset($task_counts[$row['status']])) { $task_counts[$row['status']] = $row['count']; } }
$stmt_counts->close();
$total_tasks = array_sum($task_counts);
$pie_chart_data = json_encode(array_values($task_counts));
$pie_chart_labels = json_encode(array_keys($task_counts));

$urgent_tasks = [];
$seven_days_from_now = date('Y-m-d', strtotime('+7 days'));
$stmt_urgent = $mysqli->prepare("SELECT t.id, m.name as metric_name, t.due_date FROM tasks t JOIN metrics m ON t.metric_id = m.id JOIN task_assignees ta ON t.id = ta.task_id WHERE ta.user_id = ? AND t.due_date <= ? AND t.status NOT IN ('Approved', 'Submitted') ORDER BY t.due_date ASC LIMIT 5");
$stmt_urgent->bind_param("is", $user_id, $seven_days_from_now);
$stmt_urgent->execute();
$urgent_tasks_result = $stmt_urgent->get_result();
while($row = $urgent_tasks_result->fetch_assoc()) { $urgent_tasks[] = $row; }
$stmt_urgent->close();

$assigned_metrics = [];
$metric_stmt = $mysqli->prepare("SELECT DISTINCT m.id, m.name FROM metrics m JOIN tasks t ON m.id = t.metric_id JOIN task_assignees ta ON t.id = ta.task_id WHERE ta.user_id = ? ORDER BY m.name ASC");
$metric_stmt->bind_param("i", $user_id);
$metric_stmt->execute();
$metric_result = $metric_stmt->get_result();
while ($row = $metric_result->fetch_assoc()) { $assigned_metrics[] = $row; }
$metric_stmt->close();

$filter_status = $_GET['status'] ?? 'all';
$filter_metric_id = $_GET['metric_id'] ?? 'all';
$allowed_statuses = ['Pending', 'Approved', 'Rejected', 'In Progress'];

$sql = "SELECT t.*, m.id as metric_id, m.name as metric_name, m.description as metric_description, ta.id as task_assignee_id, ta.submission_status, (SELECT GROUP_CONCAT(u.name SEPARATOR ', ') FROM task_assignees ta_team JOIN users u ON ta_team.user_id = u.id WHERE ta_team.task_id = t.id) as team_members FROM tasks t JOIN metrics m ON t.metric_id = m.id JOIN task_assignees ta ON t.id = ta.task_id WHERE ta.user_id = ?";
$params = [$user_id];
$types = "i";
if ($filter_status !== 'all' && in_array($filter_status, $allowed_statuses)) { $sql .= " AND t.status = ?"; $params[] = $filter_status; $types .= "s"; }
if ($filter_metric_id !== 'all' && is_numeric($filter_metric_id)) { $sql .= " AND t.metric_id = ?"; $params[] = $filter_metric_id; $types .= "i"; }
$sql .= " ORDER BY t.due_date ASC";
$stmt = $mysqli->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$tasks_result = $stmt->get_result();
$stmt->close();
?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
    /* All CSS styles from the previous version remain the same */
    html { scroll-padding-top: 65px; scroll-behavior: smooth; }
    body { background-color: #f4f7f9; font-family: sans-serif; }
    .main-content { margin-top: 65px; padding: 25px; }
    .main-header { position: fixed; top: 0; left: 0; right: 0; height: 65px; background: #ffffff; box-shadow: 0 2px 4px rgba(0,0,0,0.1); z-index: 990; display: grid; grid-template-columns: 1fr auto 1fr; align-items: center; padding: 0 20px; }
    #menu-toggle { grid-column: 1; justify-self: start; background: transparent; border: 1px solid #dcdcdc; width: 40px; height: 40px; border-radius: 50%; color: #333; font-size: 1rem; cursor: pointer; display: flex; align-items: center; justify-content: center; transition: all 0.2s ease; }
    .header-title { grid-column: 2; font-size: 1.5rem; font-weight: 600; color: #2c3e50; }
    .header-right { grid-column: 3; justify-self: end; display: flex; align-items: center; gap: 20px; }
    .user-greeting { font-size: 1rem; color: #555; font-weight: 500; }
    .logout-button { display: flex; align-items: center; justify-content: center; background: transparent; border: 1px solid #dcdcdc; width: 40px; height: 40px; border-radius: 50%; color: #e74c3c; font-size: 1rem; cursor: pointer; text-decoration: none; transition: all 0.2s ease; }
    #menu-toggle .icon-close { display: none; }
    .menu-open #menu-toggle .icon-hamburger { display: none; }
    .menu-open #menu-toggle .icon-close { display: block; }
    .sidebar { width: 280px; background-color: #ffffff; color: #333; position: fixed; top: 0; left: 0; height: 100%; z-index: 1000; transform: translateX(-100%); transition: transform 0.3s ease-in-out; display: flex; flex-direction: column; box-shadow: 0 0 15px rgba(0,0,0,0.2); }
    .sidebar.show { transform: translateX(0); }
    .overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 999; opacity: 0; visibility: hidden; transition: opacity 0.3s ease-in-out, visibility 0s 0.3s; }
    .overlay.show { opacity: 1; visibility: visible; }
    .sidebar-header { padding: 20px; text-align: center; border-bottom: 1px solid #e9ecef; background-color: #2c3e50; color: white; }
    .sidebar-header h3 { margin: 0; font-size: 1.4rem; }
    .sidebar-nav { list-style-type: none; padding: 15px 0; margin: 0; flex-grow: 1; overflow-y: auto; }
    .sidebar-nav li .nav-link { display: flex; align-items: center; justify-content: space-between; color: #555; padding: 12px 25px; text-decoration: none; transition: all 0.2s ease; border-left: 4px solid transparent; font-weight: 500; }
    .sidebar-nav li .nav-link:hover, .sidebar-nav li .nav-link.active-view { background-color: #e9f3ff; color: #007bff; }
    .sidebar-nav li .nav-link.active { background-color: #e9f3ff; color: #007bff; border-left-color: #007bff; font-weight: 600; }
    .sidebar-nav li .nav-link .nav-text { display: flex; align-items: center; gap: 15px; }
    .sidebar-nav li .nav-link i { width: 20px; text-align: center; color: #888; }
    .sidebar-nav li .nav-link:hover i, .sidebar-nav li .nav-link.active-view i { color: #007bff; }
    .submenu-arrow { font-size: 0.8em; transition: transform 0.3s ease; }
    .nav-item-has-submenu.open > .submenu-parent .submenu-arrow { transform: rotate(180deg); }
    .sidebar-nav .submenu { list-style: none; padding: 0; max-height: 0; overflow: hidden; transition: max-height 0.4s ease-out; background-color: #fdfdfd; }
    .sidebar-nav .submenu.open { max-height: 1000px; }
    .sidebar-nav .submenu .nav-link { font-size: 0.95em; padding-left: 49px; }
    .nav-count { font-weight: bold; background-color: #e9ecef; color: #495057; padding: 2px 8px; border-radius: 12px; transition: all 0.2s ease; }
    .nav-link.active .nav-count { background-color: #007bff; color: white; }
    #graphical-view-dashboard { display: none; grid-template-columns: 1fr 1fr; gap: 25px; margin-bottom: 30px; }
    #graphical-view-dashboard.visible { display: grid; }
    .graph-card { background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.05); }
    .graph-card h3 { margin-top: 0; font-size: 1.2rem; color: #34495e; border-bottom: 1px solid #eee; padding-bottom: 10px; margin-bottom: 15px; }
    #taskPieChart { max-height: 250px; }
    .urgent-tasks-list { list-style: none; padding: 0; margin: 0; }
    .urgent-tasks-list li { display: flex; justify-content: space-between; align-items: center; padding: 10px 5px; border-bottom: 1px solid #f0f0f0; }
    .urgent-tasks-list .task-name { font-weight: 500; color: #555; }
    .urgent-tasks-list .due-date { font-size: 0.9em; background-color: #e74c3c; color: white; padding: 3px 8px; border-radius: 12px; }
    .filter-bar { background: #fff; padding: 15px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.05); margin-bottom: 30px; display: flex; align-items: center; gap: 15px; flex-wrap: wrap; }
    .filter-bar .form-group { display: flex; flex-direction: column; }
    .filter-bar label { font-size: 0.8em; color: #777; margin-bottom: 5px; }
    .filter-bar select, .filter-bar button, .filter-bar .btn-reset { padding: 8px 12px; border-radius: 5px; border: 1px solid #ccc; background: #f9f9f9; font-size: 0.95em; }
    .filter-bar button { align-self: flex-end; background: #3498db; color: white; border-color: #3498db; cursor: pointer; }
    .filter-bar .btn-reset { align-self: flex-end; text-decoration: none; color: #333; }
</style>

<!-- Header & Overlay -->
<header class="main-header">
    <button id="menu-toggle" title="Toggle Menu"><i class="fas fa-bars icon-hamburger"></i><i class="fas fa-times icon-close"></i></button>
    <div class="header-title">My Dashboard</div>
    <div class="header-right">
        <span class="user-greeting">Welcome, <?php echo htmlspecialchars(explode(' ', $user_name)[0]); ?>!</span>
        <a href="logout.php" class="logout-button" title="Logout"><i class="fas fa-sign-out-alt"></i></a>
    </div>
</header>
<div class="overlay"></div>

<!-- Sidebar with View Toggle -->
<div class="sidebar">
    <div class="sidebar-header"><h3><i class="fas fa-cogs"></i> Menu</h3></div>
    <ul class="sidebar-nav">
        <li><a href="faculty_dashboard.php" class="nav-link"><span class="nav-text"><i class="fas fa-tachometer-alt"></i> Dashboard Home</span></a></li>
        <li><a href="#" class="nav-link" id="toggle-graph-view"><span class="nav-text"><i class="fas fa-chart-bar"></i> Show Graphical View</span></a></li>
        <li class="nav-item-has-submenu open">
            <a href="#" class="nav-link submenu-parent"><span class="nav-text"><i class="fas fa-tasks"></i> Filter by Status</span><i class="fas fa-chevron-down submenu-arrow"></i></a>
            <ul class="submenu open">
                <li><a href="?status=all&metric_id=<?php echo $filter_metric_id; ?>" class="nav-link <?php if($filter_status == 'all') echo 'active'; ?>"><span>All Tasks</span><span class="nav-count"><?php echo $total_tasks; ?></span></a></li>
                <?php foreach($task_counts as $status => $count): ?>
                <li><a href="?status=<?php echo $status; ?>&metric_id=<?php echo $filter_metric_id; ?>" class="nav-link <?php if($filter_status == $status) echo 'active'; ?>"><span><?php echo $status; ?></span><span class="nav-count"><?php echo $count; ?></span></a></li>
                <?php endforeach; ?>
            </ul>
        </li>
        <?php if (!empty($assigned_metrics)): ?>
        <li class="nav-item-has-submenu open">
            <a href="#" class="nav-link submenu-parent"><span class="nav-text"><i class="fas fa-filter"></i> Filter by Metric</span><i class="fas fa-chevron-down submenu-arrow"></i></a>
            <ul class="submenu open">
                <li><a href="?status=<?php echo $filter_status; ?>&metric_id=all" class="nav-link <?php if($filter_metric_id == 'all') echo 'active'; ?>">All Metrics</a></li>
                <?php foreach ($assigned_metrics as $metric): ?>
                <li><a href="?status=<?php echo $filter_status; ?>&metric_id=<?php echo $metric['id']; ?>" class="nav-link <?php if($filter_metric_id == $metric['id']) echo 'active'; ?>"><?php echo htmlspecialchars($metric['name']); ?></a></li>
                <?php endforeach; ?>
            </ul>
        </li>
        <?php endif; ?>
        <li><a href="logout.php" class="nav-link"><span class="nav-text"><i class="fas fa-sign-out-alt"></i> Logout</span></a></li>
    </ul>
</div>

<!-- Main Content Area -->
<main class="main-content">
    
    <div id="graphical-view-dashboard">
        <div class="graph-card">
            <h3><i class="fas fa-exclamation-triangle"></i> Urgent Tasks (Due in 7 Days)</h3>
            <?php if (!empty($urgent_tasks)): ?>
                <ul class="urgent-tasks-list">
                    <?php foreach ($urgent_tasks as $task): ?>
                        <li><span class="task-name"><?php echo htmlspecialchars($task['metric_name']); ?></span><span class="due-date"><?php echo date("M d", strtotime($task['due_date'])); ?></span></li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?><p>No urgent tasks due soon. Well done!</p><?php endif; ?>
        </div>
        <div class="graph-card">
            <h3><i class="fas fa-chart-pie"></i> Task Status Overview</h3>
            <canvas id="taskPieChart"></canvas>
        </div>
    </div>

    <form action="faculty_dashboard.php" method="GET" class="filter-bar">
        <div class="form-group">
            <label for="status-filter">Status</label>
            <select name="status" id="status-filter">
                <option value="all">All Statuses</option>
                <option value="Pending" <?php if($filter_status == 'Pending') echo 'selected'; ?>>Pending</option>
                <option value="Approved" <?php if($filter_status == 'Approved') echo 'selected'; ?>>Approved</option>
                <option value="Rejected" <?php if($filter_status == 'Rejected') echo 'selected'; ?>>Rejected</option>
                <option value="In Progress" <?php if($filter_status == 'In Progress') echo 'selected'; ?>>In Progress</option>
            </select>
        </div>
        <div class="form-group">
            <label for="metric-filter">Metric</label>
            <select name="metric_id" id="metric-filter">
                <option value="all">All Metrics</option>
                <?php foreach($assigned_metrics as $metric): ?>
                <option value="<?php echo $metric['id']; ?>" <?php if($filter_metric_id == $metric['id']) echo 'selected'; ?>><?php echo htmlspecialchars($metric['name']); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <button type="submit"><i class="fas fa-filter"></i> Filter</button>
        <a href="faculty_dashboard.php" class="btn-reset">Reset</a>
    </form>

    <?php if (isset($_SESSION['message'])): ?><div class="message <?php echo $_SESSION['message']['type']; ?>"><?php echo htmlspecialchars($_SESSION['message']['text']); ?></div><?php unset($_SESSION['message']); endif; ?>

    <div class="assignments-container">
        <?php if ($tasks_result && $tasks_result->num_rows > 0): ?>
            <?php while ($task = $tasks_result->fetch_assoc()): ?>
                
                <!-- THIS IS THE RESTORED CODE BLOCK FOR DISPLAYING TASKS -->
                <div class="assignment-card status-<?php echo strtolower(str_replace(' ', '-', $task['status'])); ?>">
                    <div class="card-header">
                        <h3><?php echo htmlspecialchars($task['metric_name']); ?></h3>
                        <span class="status-badge"><?php echo htmlspecialchars($task['status']); ?></span>
                    </div>
                    <div class="card-body">
                        <p><strong>Due Date:</strong> <?php echo date("F d, Y", strtotime($task['due_date'])); ?></p>
                        <p><strong>Team Members:</strong> <?php echo htmlspecialchars($task['team_members']); ?></p>
                        <p><strong>Description:</strong> <?php echo htmlspecialchars($task['metric_description']); ?></p>
                        <?php if ($task['status'] == 'Rejected' && !empty($task['remarks'])): ?><p class="remarks"><strong><i class="fas fa-comment-dots"></i> HOD/Lead Remarks:</strong> <?php echo htmlspecialchars($task['remarks']); ?></p><?php endif; ?>
                        <?php if (!empty($task['working_file_path']) && file_exists($task['working_file_path'])): ?><div class="task-format-container"><h4><i class="fas fa-file-word"></i> Task Format Document</h4><p>Use this document to prepare your submission.</p><a href="<?php echo htmlspecialchars($task['working_file_path']); ?>" class="btn-download-format" download><i class="fas fa-download"></i> Download Format</a></div><?php endif; ?>
                        <hr>
                        <div class="standard-documents-list"><h4><i class="fas fa-book"></i> Standard Reference Documents</h4><?php $attachment_stmt = $mysqli->prepare("SELECT file_path, original_filename FROM metric_attachments WHERE metric_id = ?"); if ($attachment_stmt) { $attachment_stmt->bind_param("i", $task['metric_id']); $attachment_stmt->execute(); $attachments = $attachment_stmt->get_result(); if ($attachments->num_rows > 0) { while($attachment = $attachments->fetch_assoc()) { echo '<div><a href="' . htmlspecialchars($attachment['file_path']) . '" class="btn-download-standard" target="_blank" title="Download"><i class="fas fa-download"></i> ' . htmlspecialchars($attachment['original_filename']) . '</a></div>'; } } else { echo '<p>No standard reference documents are available for this metric.</p>'; } $attachment_stmt->close(); } ?></div>
                        <div class="proofs-list"><h4><i class="fas fa-file-alt"></i> Uploaded Proofs For This Task:</h4><?php $proof_stmt = $mysqli->prepare("SELECT p.*, u.name as uploader_name FROM proofs p JOIN task_assignees ta ON p.task_assignee_id = ta.id JOIN users u ON ta.user_id = u.id WHERE ta.task_id = ? ORDER BY p.uploaded_at DESC"); if ($proof_stmt) { $proof_stmt->bind_param("i", $task['id']); $proof_stmt->execute(); $proofs = $proof_stmt->get_result(); if ($proofs->num_rows > 0) { echo '<ul>'; while($proof = $proofs->fetch_assoc()) { echo '<li><a href="' . htmlspecialchars($proof['file_path']) . '" target="_blank">' . htmlspecialchars($proof['original_filename']) . '</a> <span class="upload-date">(by ' . htmlspecialchars($proof['uploader_name']) . ' on ' . date("d M Y", strtotime($proof['uploaded_at'])) . ')</span></li>'; } echo '</ul>'; } else { echo '<p>No proofs uploaded yet for this task.</p>'; } $proof_stmt->close(); } ?></div>
                        <?php if ( (($task['status'] == 'Pending' || $task['status'] == 'In Progress') && $task['submission_status'] == 'Not Submitted') || $task['status'] == 'Rejected' ): ?>
                        <div class="upload-section">
                            <h4>Your Submission Status: <span class="status-badge-small status-not-submitted"><?php echo ($task['status'] == 'Rejected') ? 'Rejected - Awaiting Resubmission' : $task['submission_status']; ?></span></h4>
                            <p class="form-text">Select one or more files and click submit.</p>
                            <form action="faculty_actions.php" method="post" enctype="multipart/form-data" class="upload-form">
                                <input type="hidden" name="action" value="upload_proof"><input type="hidden" name="task_id" value="<?php echo $task['id']; ?>"><div class="form-group"><input type="file" name="proof_files[]" required multiple></div>
                                <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Upload & Submit My Part</button>
                            </form>
                        </div>
                        <?php elseif ($task['submission_status'] == 'Submitted'): ?>
                            <div class="upload-section"><h4>Your Submission Status: <span class="status-badge-small status-submitted"><?php echo $task['submission_status']; ?></span></h4><p>You have submitted your proof(s). Waiting for review.</p></div>
                        <?php endif; ?>
                    </div>
                </div>
                <!-- END OF RESTORED BLOCK -->

            <?php endwhile; ?>
        <?php else: ?>
            <p style="text-align: center; font-size: 1.2rem; color: #666;">No tasks found matching your filter criteria.</p>
        <?php endif; ?>
    </div>
</main>

<script>
// All JavaScript from the previous version remains the same
document.addEventListener('DOMContentLoaded', function() {
    const body = document.body;
    const menuToggle = document.getElementById('menu-toggle');
    const sidebar = document.querySelector('.sidebar');
    const overlay = document.querySelector('.overlay');
    const openMenu = () => { body.classList.add('menu-open'); sidebar.classList.add('show'); overlay.classList.add('show'); };
    const closeMenu = () => { body.classList.remove('menu-open'); sidebar.classList.remove('show'); overlay.classList.remove('show'); };
    menuToggle.addEventListener('click', e => { e.stopPropagation(); sidebar.classList.contains('show') ? closeMenu() : openMenu(); });
    overlay.addEventListener('click', closeMenu);

    document.querySelectorAll('.submenu-parent').forEach(submenuParent => {
        submenuParent.addEventListener('click', function(e) {
            e.preventDefault();
            this.closest('.nav-item-has-submenu').classList.toggle('open');
            this.nextElementSibling.classList.toggle('open');
        });
    });

    const graphToggleBtn = document.getElementById('toggle-graph-view');
    const graphViewDashboard = document.getElementById('graphical-view-dashboard');
    graphToggleBtn.addEventListener('click', function(e) {
        e.preventDefault();
        const isVisible = graphViewDashboard.classList.toggle('visible');
        this.classList.toggle('active-view', isVisible);
        this.querySelector('.nav-text').innerHTML = isVisible 
            ? '<i class="fas fa-chart-bar"></i> Hide Graphical View' 
            : '<i class="fas fa-chart-bar"></i> Show Graphical View';
        if (isVisible) {
            window.scrollTo({ top: 0, behavior: 'smooth' });
            closeMenu();
        }
    });

    const pieChartCanvas = document.getElementById('taskPieChart');
    if (pieChartCanvas) {
        const ctx = pieChartCanvas.getContext('2d');
        const taskPieChart = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: <?php echo $pie_chart_labels; ?>,
                datasets: [{
                    label: 'Tasks',
                    data: <?php echo $pie_chart_data; ?>,
                    backgroundColor: ['rgba(255, 159, 64, 0.8)','rgba(75, 192, 192, 0.8)','rgba(255, 99, 132, 0.8)'],
                    borderColor: ['#fff'],
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { position: 'top' } }
            }
        });
    }
});
</script>

<?php require_once 'includes/footer.php'; ?>