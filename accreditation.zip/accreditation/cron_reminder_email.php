<?php
// cron_reminder_email.php
// This script is designed to be run automatically by the Windows Task Scheduler.

// Set your server's timezone to avoid date/time errors
date_default_timezone_set('Asia/Kolkata'); // <<<--- EDIT THIS to your server's timezone if different

// --- Include Required Files ---
// Use absolute paths for reliability in a command-line environment
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/vendor/autoload.php';
require_once __DIR__ . '/includes/mailer.php';

echo "--- Starting Reminder Script at " . date('Y-m-d H:i:s') . " ---\n";

// --- Configuration ---
// The URL to your dashboard. This MUST be a full, hardcoded URL.
$dashboard_url = "http://localhost/your_project/dashboard.php"; // <<<--- EDIT THIS to your actual dashboard URL

// --- Fetch All Criterion Leads ---
$sql = "SELECT u.name, u.email 
        FROM users u 
        JOIN roles r ON u.role_id = r.id 
        WHERE r.name = 'Criterion Lead' AND u.email IS NOT NULL AND u.email != ''";

$result = $mysqli->query($sql);

if (!$result) {
    die("Database query failed: " . $mysqli->error);
}

if ($result->num_rows > 0) {
    echo "Found " . $result->num_rows . " lead(s) to notify.\n";

    while ($lead = $result->fetch_assoc()) {
        $lead_name = htmlspecialchars($lead['name']);
        $lead_email = $lead['email'];

        echo "Preparing email for: {$lead_name} ({$lead_email})... ";

        // --- Compose Email ---
        $subject = 'Reminder: Please Check Your Accreditation Dashboard';
        $html_body = "
        <html>
        <body style='font-family: Arial, sans-serif; line-height: 1.6;'>
            <h2>Accreditation Portal Reminder</h2>
            <p>Dear {$lead_name},</p>
            <p>This is a friendly reminder to please check your dashboard for any pending tasks, submissions, or updates that require your attention.</p>
            <p>Staying up-to-date helps keep the accreditation process running smoothly for everyone.</p>
            <hr>
            <p style='margin-top: 20px;'>
                <a href='{$dashboard_url}' style='background-color: #0d6efd; color: white; padding: 12px 20px; text-decoration: none; border-radius: 5px;'>
                    Go to Your Dashboard
                </a>
            </p>
            <br>
            <p>Thank you for your hard work and dedication.</p>
            <p><em>The Accreditation Portal Team</em></p>
        </body>
        </html>";

        // --- Send Email using your mailer function ---
        if (send_email_notification($lead_email, $lead_name, $subject, $html_body)) {
            echo "Email sent successfully!\n";
        } else {
            echo "FAILED to send email.\n";
        }
    }
} else {
    echo "No Criterion Leads found to notify.\n";
}

$mysqli->close();
echo "--- Script Finished ---\n";

?>