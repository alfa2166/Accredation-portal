<?php
session_start();
require_once 'config/db.php';

// Define the role ID for 'Criterion Lead' for easy maintenance.
define('CRITERION_LEAD_ROLE_ID', 3);

// Security check: only admins can perform these actions
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'Admin') {
    $_SESSION['message'] = ['type' => 'error', 'text' => 'Access Denied. Your session may have expired. Please log in again.'];
    header("Location: index.php");
    exit();
}

function notify_hod_and_lead($mysqli, $message, $department_id = null, $detailed_changes = null) {
    $recipients = [];

    // Get HOD of the department
    if ($department_id) {
        $stmt = $mysqli->prepare("SELECT id FROM users WHERE role_id = 2 AND department_id = ?");
        if ($stmt) {
            $stmt->bind_param("i", $department_id);
            $stmt->execute();
            $result = $stmt->get_result();
            while ($row = $result->fetch_assoc()) {
                $recipients[] = $row['id'];
            }
            $stmt->close();
        }
    }

    // Get all Criterion Leads
    $stmt = $mysqli->prepare("SELECT id FROM users WHERE role_id = 3");
    if ($stmt) {
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $recipients[] = $row['id'];
        }
        $stmt->close();
    }

    // Insert notifications
    if (!empty($recipients)) {
        $recipients = array_unique($recipients);
        $stmt = $mysqli->prepare("INSERT INTO notifications (user_id, message, link) VALUES (?, ?, ?)");
        $link = 'hod_dashboard.php#user-management'; // Generic link
        
        // Create detailed message if changes are provided
        if ($detailed_changes && !empty($detailed_changes)) {
            $detailed_message = $message . "\n\nChanges made:\n";
            foreach ($detailed_changes as $field => $change) {
                $old_value = $change['old'] ?? 'Not set';
                $new_value = $change['new'] ?? 'Not set';
                $detailed_message .= "• {$field}: {$old_value} → {$new_value}\n";
            }
        } else {
            $detailed_message = $message;
        }
        
        foreach ($recipients as $user_id) {
            $stmt->bind_param("iss", $user_id, $detailed_message, $link);
            $stmt->execute();
        }
        $stmt->close();
    }
}

function get_user_details($mysqli, $user_id) {
    $stmt = $mysqli->prepare("
        SELECT u.*, 
               d.name as department_name,
               r.name as role_name,
               jd.name as job_description_name,
               c.name as criterion_name
        FROM users u
        LEFT JOIN departments d ON u.department_id = d.id
        LEFT JOIN roles r ON u.role_id = r.id
        LEFT JOIN job_descriptions jd ON u.job_description_id = jd.id
        LEFT JOIN criteria c ON u.criterion_id = c.id
        WHERE u.id = ?
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $result;
}

function compare_user_changes($old_data, $new_data) {
    $changes = [];
    $field_mappings = [
        'name' => 'Name',
        'email' => 'Email',
        'employee_id' => 'Employee ID',
        'role_id' => 'Role',
        'department_id' => 'Department',
        'job_description_id' => 'Job Description',
        'criterion_id' => 'Criterion'
    ];
    
    foreach ($field_mappings as $field => $display_name) {
        $old_value = $old_data[$field] ?? null;
        $new_value = $new_data[$field] ?? null;
        
        // Handle special cases for IDs that need to be converted to names
        if ($field === 'role_id' && $old_value !== $new_value) {
            $changes[$display_name] = [
                'old' => $old_data['role_name'] ?? 'Unknown',
                'new' => $new_data['role_name'] ?? 'Unknown'
            ];
        } elseif ($field === 'department_id' && $old_value !== $new_value) {
            $changes[$display_name] = [
                'old' => $old_data['department_name'] ?? 'Not assigned',
                'new' => $new_data['department_name'] ?? 'Not assigned'
            ];
        } elseif ($field === 'job_description_id' && $old_value !== $new_value) {
            $changes[$display_name] = [
                'old' => $old_data['job_description_name'] ?? 'Not assigned',
                'new' => $new_data['job_description_name'] ?? 'Not assigned'
            ];
        } elseif ($field === 'criterion_id' && $old_value !== $new_value) {
            $changes[$display_name] = [
                'old' => $old_data['criterion_name'] ?? 'Not assigned',
                'new' => $new_data['criterion_name'] ?? 'Not assigned'
            ];
        } elseif ($old_value !== $new_value) {
            $changes[$display_name] = [
                'old' => $old_value ?? 'Not set',
                'new' => $new_value ?? 'Not set'
            ];
        }
    }
    
    return $changes;
}

$action = $_POST['action'] ?? $_GET['action'] ?? null;
$admin_id = $_SESSION['user_id'];

if (isset($_POST['action'])) {

    // --- ACTION: REVIEW A PENDING FILE UPDATE (FROM APPROVAL HUB) ---
    if ($_POST['action'] == 'review_file_update') {
        $request_id = (int)($_POST['request_id'] ?? 0);
        $decision = $_POST['decision'] ?? '';
        $remarks = trim($_POST['remarks'] ?? '');

        if (empty($request_id) || !in_array($decision, ['Approve', 'Reject'])) {
            $_SESSION['message'] = ['type' => 'error', 'text' => 'Invalid action or request ID.'];
            header("Location: admin_dashboard.php#approval-hub");
            exit();
        }

        if ($decision === 'Reject' && empty($remarks)) {
            $_SESSION['message'] = ['type' => 'error', 'text' => 'Remarks are required to reject a request.'];
            header("Location: admin_dashboard.php#approval-hub");
            exit();
        }

        // Fetch the pending request details to ensure it's still pending
        $stmt_get = $mysqli->prepare("SELECT * FROM pending_updates WHERE id = ? AND status = 'Pending'");
        $stmt_get->bind_param("i", $request_id);
        $stmt_get->execute();
        $request = $stmt_get->get_result()->fetch_assoc();
        $stmt_get->close();

        if (!$request) {
            $_SESSION['message'] = ['type' => 'error', 'text' => 'Request not found or has already been processed.'];
            header("Location: admin_dashboard.php#approval-hub");
            exit();
        }

        $mysqli->begin_transaction();
        try {
            if ($decision === 'Approve') {
                $old_file_path = null;

                // Determine target table, directory, and how to get the old file path
                if ($request['update_type'] === 'criterion_template') {
                    $target_dir = 'uploads/criterion_templates/';
                    $stmt_old = $mysqli->prepare("SELECT file_path FROM criterion_templates WHERE criterion_id = ?");
                    $stmt_old->bind_param("i", $request['target_id']);
                } else { // 'metric_attachment'
                    $target_dir = 'uploads/metric_attachments/';
                    $stmt_old = $mysqli->prepare("SELECT file_path FROM metric_attachments WHERE metric_id = ?");
                    $stmt_old->bind_param("i", $request['target_id']);
                }

                // 1. Get the path of the current file for later deletion
                $stmt_old->execute();
                $old_file_path = $stmt_old->get_result()->fetch_assoc()['file_path'] ?? null;
                $stmt_old->close();

                // 2. Move the new file from the 'pending_updates' dir to its final destination
                if (!is_dir($target_dir)) mkdir($target_dir, 0755, true);
                $final_filename = basename($request['new_file_path']); // Use the already-unique filename
                $final_file_path = $target_dir . $final_filename;
                
                if (!rename($request['new_file_path'], $final_file_path)) {
                    throw new Exception("Server error: Could not move the approved file.");
                }

                // 3. Update the database record in the target table
                if ($request['update_type'] === 'criterion_template') {
                    $stmt_update = $mysqli->prepare("INSERT INTO criterion_templates (criterion_id, file_path, original_filename) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE file_path = VALUES(file_path), original_filename = VALUES(original_filename)");
                    $stmt_update->bind_param("iss", $request['target_id'], $final_file_path, $request['original_filename']);
                } else {
                    $stmt_update = $mysqli->prepare("INSERT INTO metric_attachments (metric_id, file_path, original_filename) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE file_path = VALUES(file_path), original_filename = VALUES(original_filename)");
                    $stmt_update->bind_param("iss", $request['target_id'], $final_file_path, $request['original_filename']);
                }
                $stmt_update->execute();
                $stmt_update->close();

                // 4. Clean up: Delete the old file from the server if it existed
                if ($old_file_path && file_exists($old_file_path)) {
                    @unlink($old_file_path);
                }
            } else { // Decision is 'Reject'
                // Clean up: Just delete the rejected file from the pending directory
                if (file_exists($request['new_file_path'])) {
                    @unlink($request['new_file_path']);
                }
            }

            // 5. Final Step: Update the status of the request itself
            $stmt_status = $mysqli->prepare("UPDATE pending_updates SET status = ?, remarks = ?, reviewed_at = NOW() WHERE id = ?");
            $stmt_status->bind_param("ssi", $decision, $remarks, $request_id);
            $stmt_status->execute();
            $stmt_status->close();

            $mysqli->commit();
            $_SESSION['message'] = ['type' => 'success', 'text' => "The request has been successfully {$decision}ed."];

        } catch (Exception $e) {
            $mysqli->rollback();
            // If an error occurred during approval, try to move the file back to pending
            if ($decision === 'Approve' && isset($final_file_path) && file_exists($final_file_path)) {
                @rename($final_file_path, $request['new_file_path']);
            }
            $_SESSION['message'] = ['type' => 'error', 'text' => 'A critical error occurred: ' . $e->getMessage()];
        }
        header("Location: admin_dashboard.php#approval-hub");
        exit();
    }


    // --- ACTION: UPLOAD/REPLACE A METRIC'S STANDARD DOCUMENT (ADMIN DIRECT UPLOAD) ---
    if ($_POST['action'] == 'upload_metric_attachment') {
        $metric_id = $_POST['metric_id'];
        $file = $_FILES['attachment_file'];

        if (empty($metric_id) || empty($file) || $file['error'] !== UPLOAD_ERR_OK) {
            $_SESSION['message'] = ['type' => 'error', 'text' => 'File upload failed. Please select a valid file.'];
            header("Location: admin_dashboard.php#metric-attachments");
            exit();
        }

        $target_dir = "uploads/metric_attachments/";
        if (!is_dir($target_dir)) { mkdir($target_dir, 0777, true); }
        
        $original_filename = basename($file["name"]);
        $file_extension = strtolower(pathinfo($original_filename, PATHINFO_EXTENSION));
        $allowed_types = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'jpg', 'jpeg', 'png'];
        $max_file_size = 5000000; // 5 MB

        if (!in_array($file_extension, $allowed_types)) {
            $_SESSION['message'] = ['type' => 'error', 'text' => "Invalid file type. Only " . implode(', ', $allowed_types) . " are allowed."];
        } elseif ($file["size"] > $max_file_size) {
            $_SESSION['message'] = ['type' => 'error', 'text' => "File is too large (Max 5MB)."];
        } else {
            $unique_filename = uniqid('metric_' . $metric_id . '_', true) . '.' . $file_extension;
            $target_file = $target_dir . $unique_filename;

            $mysqli->begin_transaction();
            try {
                $stmt_old = $mysqli->prepare("SELECT file_path FROM metric_attachments WHERE metric_id = ?");
                $stmt_old->bind_param("i", $metric_id);
                $stmt_old->execute();
                $old_file_path = $stmt_old->get_result()->fetch_assoc()['file_path'] ?? null;

                if (!move_uploaded_file($file["tmp_name"], $target_file)) {
                    throw new Exception("Server could not save the uploaded file.");
                }

                $stmt = $mysqli->prepare("INSERT INTO metric_attachments (metric_id, file_path, original_filename) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE file_path = VALUES(file_path), original_filename = VALUES(original_filename)");
                $stmt->bind_param("iss", $metric_id, $target_file, $original_filename);
                $stmt->execute();

                $mysqli->commit();
                
                if ($old_file_path && file_exists($old_file_path)) {
                    unlink($old_file_path);
                }
                
                $_SESSION['message'] = ['type' => 'success', 'text' => 'Metric attachment uploaded successfully.'];
            } catch (Exception $e) {
                $mysqli->rollback();
                if (file_exists($target_file)) { unlink($target_file); }
                $_SESSION['message'] = ['type' => 'error', 'text' => 'Database error: ' . $e->getMessage()];
            }
        }
        header("Location: admin_dashboard.php#metric-attachments");
        exit();
    }

    // --- ACTION: DELETE A METRIC'S STANDARD DOCUMENT ---
    if ($_POST['action'] == 'delete_metric_attachment') {
        $metric_id = $_POST['metric_id'];
        if (empty($metric_id)) {
            $_SESSION['message'] = ['type' => 'error', 'text' => 'Invalid metric specified.'];
        } else {
            $mysqli->begin_transaction();
            try {
                $stmt_old = $mysqli->prepare("SELECT file_path FROM metric_attachments WHERE metric_id = ?");
                $stmt_old->bind_param("i", $metric_id);
                $stmt_old->execute();
                $old_file_path = $stmt_old->get_result()->fetch_assoc()['file_path'] ?? null;

                $stmt_del = $mysqli->prepare("DELETE FROM metric_attachments WHERE metric_id = ?");
                $stmt_del->bind_param("i", $metric_id);
                $stmt_del->execute();
                $mysqli->commit();

                if ($old_file_path && file_exists($old_file_path)) {
                    unlink($old_file_path);
                }
                $_SESSION['message'] = ['type' => 'success', 'text' => 'Metric attachment deleted successfully.'];
            } catch (Exception $e) {
                $mysqli->rollback();
                $_SESSION['message'] = ['type' => 'error', 'text' => 'Database error: Could not delete attachment.'];
            }
        }
        header("Location: admin_dashboard.php#metric-attachments");
        exit();
    }

    // --- ACTION: ADD A NEW JOB DESCRIPTION ---
    if ($_POST['action'] == 'add_job_description') {
        $name = trim($_POST['name']);
        if (empty($name)) {
            $_SESSION['message'] = ['type' => 'error', 'text' => 'Job description name cannot be empty.'];
        } else {
            $stmt = $mysqli->prepare("INSERT INTO job_descriptions (name) VALUES (?)");
            $stmt->bind_param("s", $name);
            if ($stmt->execute()) {
                $_SESSION['message'] = ['type' => 'success', 'text' => 'Job description added successfully.'];
            } else {
                $_SESSION['message'] = ['type' => 'error', 'text' => 'Error: Could not add job description. It may already exist.'];
            }
        }
        header("Location: admin_dashboard.php#job-descriptions");
        exit();
    }

    // --- ACTION: EDIT A JOB DESCRIPTION ---
    if ($_POST['action'] == 'edit_job_description') {
        $id = $_POST['job_description_id'];
        $name = trim($_POST['name']);
        if (empty($name) || empty($id)) {
            $_SESSION['message'] = ['type' => 'error', 'text' => 'Invalid data provided.'];
        } else {
            $stmt = $mysqli->prepare("UPDATE job_descriptions SET name = ? WHERE id = ?");
            $stmt->bind_param("si", $name, $id);
            if ($stmt->execute()) {
                $_SESSION['message'] = ['type' => 'success', 'text' => 'Job description updated successfully.'];
            } else {
                $_SESSION['message'] = ['type' => 'error', 'text' => 'Error: Could not update job description. The name may already exist.'];
            }
        }
        header("Location: admin_dashboard.php#job-descriptions");
        exit();
    }

    // --- ACTION: DELETE A JOB DESCRIPTION ---
    if ($_POST['action'] == 'delete_job_description') {
        $id = $_POST['job_description_id'];
        $stmt_check = $mysqli->prepare("SELECT COUNT(*) FROM users WHERE job_description_id = ?");
        $stmt_check->bind_param("i", $id);
        $stmt_check->execute();
        $count = $stmt_check->get_result()->fetch_row()[0];
        $stmt_check->close();

        if ($count > 0) {
            $_SESSION['message'] = ['type' => 'error', 'text' => 'Cannot delete. This job description is currently assigned to ' . $count . ' user(s).'];
        } else {
            $stmt = $mysqli->prepare("DELETE FROM job_descriptions WHERE id = ?");
            $stmt->bind_param("i", $id);
            if ($stmt->execute()) {
                $_SESSION['message'] = ['type' => 'success', 'text' => 'Job description deleted successfully.'];
            } else {
                $_SESSION['message'] = ['type' => 'error', 'text' => 'Error: Could not delete the job description.'];
            }
        }
        header("Location: admin_dashboard.php#job-descriptions");
        exit();
    }

    // --- ACTION: ADD A NEW USER ---
    if ($_POST['action'] == 'add_user') {
        $name = trim($_POST['name']);
        $email = trim($_POST['email']);
        $employee_id = !empty(trim($_POST['employee_id'])) ? trim($_POST['employee_id']) : null;
        $password = $_POST['password'];
        $role_id = $_POST['role_id'];
        $department_id = !empty($_POST['department_id']) ? $_POST['department_id'] : null;
        $job_description_id = !empty($_POST['job_description_id']) ? $_POST['job_description_id'] : null;
        $criterion_id = ($role_id == CRITERION_LEAD_ROLE_ID && !empty($_POST['criterion_id'])) ? $_POST['criterion_id'] : null;

        if (empty($name) || empty($email) || empty($password) || empty($role_id)) {
            $_SESSION['message'] = ['type' => 'error', 'text' => 'Name, Email, Password, and Role are required fields.'];
        } elseif ($role_id == CRITERION_LEAD_ROLE_ID && empty($criterion_id)) {
            $_SESSION['message'] = ['type' => 'error', 'text' => 'You must select a Criterion for a Criterion Lead.'];
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $sql = "INSERT INTO users (name, email, employee_id, password, role_id, department_id, job_description_id, criterion_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $mysqli->prepare($sql);
            $stmt->bind_param("ssssiiii", $name, $email, $employee_id, $hashed_password, $role_id, $department_id, $job_description_id, $criterion_id);
            if ($stmt->execute()) {
                $_SESSION['message'] = ['type' => 'success', 'text' => 'User was added successfully!'];
                
                // Notify
                $message = "A new user, '{$name}', has been added to the system.";
                notify_hod_and_lead($mysqli, $message, $department_id);

            } else {
                $_SESSION['message'] = ['type' => 'error', 'text' => 'Error: Could not add user. Email or Employee ID may exist.'];
            }
            $stmt->close();
        }
        header("Location: admin_dashboard.php#user-management");
        exit();
    }

    // --- ACTION: EDIT AN EXISTING USER ---
    if ($_POST['action'] == 'edit_user') {
        $user_id = $_POST['user_id'];
        $name = trim($_POST['name']);
        $email = trim($_POST['email']);
        $employee_id = !empty(trim($_POST['employee_id'])) ? trim($_POST['employee_id']) : null;
        $role_id = $_POST['role_id'];
        $department_id = !empty($_POST['department_id']) ? $_POST['department_id'] : null;
        $job_description_id = !empty($_POST['job_description_id']) ? $_POST['job_description_id'] : null;
        $password = $_POST['password'];
        $criterion_id = ($role_id == CRITERION_LEAD_ROLE_ID && !empty($_POST['criterion_id'])) ? $_POST['criterion_id'] : null;

        if (empty($user_id) || empty($name) || empty($email) || empty($role_id)) {
            $_SESSION['message'] = ['type' => 'error', 'text' => 'User ID, Name, Email, and Role cannot be empty.'];
        } elseif ($role_id == CRITERION_LEAD_ROLE_ID && empty($criterion_id)) {
            $_SESSION['message'] = ['type' => 'error', 'text' => 'You must select a Criterion for a Criterion Lead.'];
        } else {
            // Get current user data for comparison
            $old_user_data = get_user_details($mysqli, $user_id);
            
            if (!empty($password)) {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $sql = "UPDATE users SET name=?, email=?, employee_id=?, password=?, role_id=?, department_id=?, job_description_id=?, criterion_id=? WHERE id=?";
                $stmt = $mysqli->prepare($sql);
                $stmt->bind_param("ssssiiiii", $name, $email, $employee_id, $hashed_password, $role_id, $department_id, $job_description_id, $criterion_id, $user_id);
            } else {
                $sql = "UPDATE users SET name=?, email=?, employee_id=?, role_id=?, department_id=?, job_description_id=?, criterion_id=? WHERE id=?";
                $stmt = $mysqli->prepare($sql);
                $stmt->bind_param("sssiiiii", $name, $email, $employee_id, $role_id, $department_id, $job_description_id, $criterion_id, $user_id);
            }
            
            if ($stmt->execute()) {
                $_SESSION['message'] = ['type' => 'success', 'text' => 'User details were updated successfully!'];
                
                // Prepare new user data for comparison
                $new_user_data = [
                    'name' => $name,
                    'email' => $email,
                    'employee_id' => $employee_id,
                    'role_id' => $role_id,
                    'department_id' => $department_id,
                    'job_description_id' => $job_description_id,
                    'criterion_id' => $criterion_id,
                    'role_name' => '', // Will be filled by get_user_details
                    'department_name' => '', // Will be filled by get_user_details
                    'job_description_name' => '', // Will be filled by get_user_details
                    'criterion_name' => '' // Will be filled by get_user_details
                ];
                
                // Get updated user data to get the proper names
                $updated_user_data = get_user_details($mysqli, $user_id);
                if ($updated_user_data) {
                    $new_user_data['role_name'] = $updated_user_data['role_name'];
                    $new_user_data['department_name'] = $updated_user_data['department_name'];
                    $new_user_data['job_description_name'] = $updated_user_data['job_description_name'];
                    $new_user_data['criterion_name'] = $updated_user_data['criterion_name'];
                }
                
                // Compare changes
                $changes = compare_user_changes($old_user_data, $new_user_data);
                
                // Add password change if password was updated
                if (!empty($password)) {
                    $changes['Password'] = [
                        'old' => '••••••••',
                        'new' => '•••••••• (Updated)'
                    ];
                }
                
                // Notify with detailed changes
                $message = "User details for '{$name}' have been updated.";
                notify_hod_and_lead($mysqli, $message, $department_id, $changes);

            } else {
                $_SESSION['message'] = ['type' => 'error', 'text' => 'Error: Could not update user. ' . $stmt->error];
            }
            $stmt->close();
        }
        header("Location: admin_dashboard.php#user-management");
        exit();
    }

    // --- ACTION: DELETE A USER ---
    if ($_POST['action'] == 'delete_user') {
        $user_id = $_POST['user_id'];
        if ($user_id == $_SESSION['user_id']) {
            $_SESSION['message'] = ['type' => 'error', 'text' => 'Operation failed: You cannot delete your own account.'];
        } else {
            // Get user info before deleting
            $stmt_info = $mysqli->prepare("SELECT name, department_id FROM users WHERE id = ?");
            $stmt_info->bind_param("i", $user_id);
            $stmt_info->execute();
            $user_info = $stmt_info->get_result()->fetch_assoc();
            $stmt_info->close();

            $sql = "DELETE FROM users WHERE id = ?";
            $stmt = $mysqli->prepare($sql);
            $stmt->bind_param("i", $user_id);
            if ($stmt->execute()) {
                $_SESSION['message'] = ['type' => 'success', 'text' => 'User was deleted successfully.'];
                
                // Notify
                if ($user_info) {
                    $message = "User '{$user_info['name']}' has been removed from the system.";
                    notify_hod_and_lead($mysqli, $message, $user_info['department_id']);
                }

            } else {
                $_SESSION['message'] = ['type' => 'error', 'text' => 'Error: Could not delete user. They may be linked to other records.'];
            }
            $stmt->close();
        }
        header("Location: admin_dashboard.php#user-management");
        exit();
    }

    // --- ACTIONS FOR CRITERIA ---
    if ($_POST['action'] == 'add_criterion') {
        $name = trim($_POST['name']);
        if (empty($name)) {
            $_SESSION['message'] = ['type' => 'error', 'text' => 'Criterion name cannot be empty.'];
        } else {
            $stmt = $mysqli->prepare("INSERT INTO criteria (name) VALUES (?)");
            $stmt->bind_param("s", $name);
            if ($stmt->execute()) { $_SESSION['message'] = ['type' => 'success', 'text' => 'Criterion added successfully.']; } 
            else { $_SESSION['message'] = ['type' => 'error', 'text' => 'Error: Could not add criterion. It may already exist.']; }
        }
        header("Location: admin_dashboard.php#criteria-metrics");
        exit();
    }
    if ($_POST['action'] == 'edit_criterion') {
        $id = $_POST['criterion_id']; $name = trim($_POST['name']);
        if (empty($name) || empty($id)) { $_SESSION['message'] = ['type' => 'error', 'text' => 'Invalid data provided.'];
        } else {
            $stmt = $mysqli->prepare("UPDATE criteria SET name = ? WHERE id = ?");
            $stmt->bind_param("si", $name, $id);
            if ($stmt->execute()) { $_SESSION['message'] = ['type' => 'success', 'text' => 'Criterion updated successfully.']; } 
            else { $_SESSION['message'] = ['type' => 'error', 'text' => 'Error: Could not update criterion. The name may already exist.']; }
        }
        header("Location: admin_dashboard.php#criteria-metrics");
        exit();
    }
    if ($_POST['action'] == 'delete_criterion') {
        $id = $_POST['criterion_id'];
        $stmt_check = $mysqli->prepare("SELECT COUNT(*) FROM metrics WHERE criterion_id = ?"); $stmt_check->bind_param("i", $id); $stmt_check->execute();
        $count = $stmt_check->get_result()->fetch_row()[0]; $stmt_check->close();
        if ($count > 0) { $_SESSION['message'] = ['type' => 'error', 'text' => 'Cannot delete. This criterion has ' . $count . ' metric(s) associated with it.'];
        } else {
            $stmt = $mysqli->prepare("DELETE FROM criteria WHERE id = ?"); $stmt->bind_param("i", $id);
            if ($stmt->execute()) { $_SESSION['message'] = ['type' => 'success', 'text' => 'Criterion deleted successfully.']; } 
            else { $_SESSION['message'] = ['type' => 'error', 'text' => 'Error: Could not delete the criterion.']; }
        }
        header("Location: admin_dashboard.php#criteria-metrics");
        exit();
    }

    // --- ACTIONS FOR METRICS ---
    if ($_POST['action'] == 'add_metric') {
        $name = trim($_POST['name']); $criterion_id = $_POST['criterion_id'];
        if (empty($name) || empty($criterion_id)) { $_SESSION['message'] = ['type' => 'error', 'text' => 'Metric name and criterion are required.'];
        } else {
            $stmt = $mysqli->prepare("INSERT INTO metrics (name, criterion_id) VALUES (?, ?)");
            $stmt->bind_param("si", $name, $criterion_id);
            if ($stmt->execute()) { $_SESSION['message'] = ['type' => 'success', 'text' => 'Metric added successfully.']; } 
            else { $_SESSION['message'] = ['type' => 'error', 'text' => 'Error: Could not add metric. It may already exist.']; }
        }
        header("Location: admin_dashboard.php#criteria-metrics");
        exit();
    }
    if ($_POST['action'] == 'edit_metric') {
        $id = $_POST['metric_id']; $name = trim($_POST['name']); $criterion_id = $_POST['criterion_id'];
        if (empty($name) || empty($id) || empty($criterion_id)) { $_SESSION['message'] = ['type' => 'error', 'text' => 'Invalid data provided.'];
        } else {
            $stmt = $mysqli->prepare("UPDATE metrics SET name = ?, criterion_id = ? WHERE id = ?");
            $stmt->bind_param("sii", $name, $criterion_id, $id);
            if ($stmt->execute()) { $_SESSION['message'] = ['type' => 'success', 'text' => 'Metric updated successfully.']; } 
            else { $_SESSION['message'] = ['type' => 'error', 'text' => 'Error: Could not update metric. The name may already exist.']; }
        }
        header("Location: admin_dashboard.php#criteria-metrics");
        exit();
    }
    if ($_POST['action'] == 'delete_metric') {
        $id = $_POST['metric_id'];
        $stmt_check = $mysqli->prepare("SELECT COUNT(*) FROM tasks WHERE metric_id = ?"); $stmt_check->bind_param("i", $id); $stmt_check->execute();
        $count = $stmt_check->get_result()->fetch_row()[0]; $stmt_check->close();
        if ($count > 0) { $_SESSION['message'] = ['type' => 'error', 'text' => 'Cannot delete. This metric is used in ' . $count . ' task(s).'];
        } else {
            $mysqli->begin_transaction();
            try {
                $stmt_file = $mysqli->prepare("SELECT file_path FROM metric_attachments WHERE metric_id = ?");
                $stmt_file->bind_param("i", $id); $stmt_file->execute();
                $file_path = $stmt_file->get_result()->fetch_assoc()['file_path'] ?? null;
                if ($file_path && file_exists($file_path)) { unlink($file_path); }
                $stmt_del_attach = $mysqli->prepare("DELETE FROM metric_attachments WHERE metric_id = ?"); $stmt_del_attach->bind_param("i", $id); $stmt_del_attach->execute();
                $stmt_del_metric = $mysqli->prepare("DELETE FROM metrics WHERE id = ?"); $stmt_del_metric->bind_param("i", $id); $stmt_del_metric->execute();
                $mysqli->commit();
                $_SESSION['message'] = ['type' => 'success', 'text' => 'Metric deleted successfully.'];
            } catch (Exception $e) { $mysqli->rollback(); $_SESSION['message'] = ['type' => 'error', 'text' => 'Database error: Could not delete the metric.']; }
        }
        header("Location: admin_dashboard.php#criteria-metrics");
        exit();
    }
    
    // --- ACTION: ADMIN REVIEWS A TASK (APPROVE/REJECT) ---
    if ($_POST['action'] == 'review_task_admin') {
        $task_id = $_POST['task_id']; $decision = $_POST['decision']; $remarks = trim($_POST['remarks'] ?? '');
        if (empty($task_id) || !in_array($decision, ['Approve', 'Reject'])) { $_SESSION['message'] = ['type' => 'error', 'text' => 'Invalid action.'];
        } elseif ($decision == 'Reject' && empty($remarks)) { $_SESSION['message'] = ['type' => 'error', 'text' => 'Remarks are required when rejecting a task.'];
        } else {
            $new_status = ($decision == 'Approve') ? 'Approved' : 'Rejected';
            $sql = "UPDATE tasks SET status = ?, remarks = ? WHERE id = ? AND status = 'Submitted'";
            $stmt = $mysqli->prepare($sql); $stmt->bind_param("ssi", $new_status, $remarks, $task_id);
            if ($stmt->execute() && $stmt->affected_rows > 0) { $_SESSION['message'] = ['type' => 'success', 'text' => "Task has been {$new_status}."];
            } else { $_SESSION['message'] = ['type' => 'error', 'text' => 'Error: Could not update the task. It may no longer be in a submitted state.']; }
            $stmt->close();
        }
        header("Location: admin_dashboard.php#task-hub");
        exit();
    }
}

// Fallback redirect
header("Location: admin_dashboard.php");
exit();
?>