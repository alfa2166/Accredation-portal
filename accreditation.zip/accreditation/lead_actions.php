<?php
session_start();
require_once 'config/db.php';

// ===================================================================
//
//               --- MODIFICATION START ---
//
// 1. Include the Composer autoloader for PHPMailer.
// 2. Include our custom mailer function.
//
// NOTE: Adjust the paths if your files are in different directories.
// For example, if vendor is in the parent directory: '../vendor/autoload.php'
//
require_once __DIR__ . '/vendor/autoload.php';
require_once __DIR__ . '/includes/mailer.php'; // Assuming you created an 'includes' folder
//
//                --- MODIFICATION END ---
//
// ===================================================================


// --- SECURITY & SESSION CHECK ---
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'Criterion Lead' || !isset($_SESSION['user_criterion_id'])) {
    $_SESSION['message'] = ['type' => 'error', 'text' => 'Access Denied. You do not have permission to perform this action.'];
    header("Location: dashboard.php");
    die("Access Denied.");
}

$lead_id = $_SESSION['user_id'];
$criterion_id_in_charge = $_SESSION['user_criterion_id'];

if (!isset($_POST['action'])) {
    header("Location: lead_dashboard.php");
    exit();
}

$action = $_POST['action'];
// --- ACTION: ASSIGN MULTIPLE METRICS ---
if ($action === 'assign_metrics') {
    $metric_ids = $_POST['metric_ids'] ?? [];
    $faculty_ids = $_POST['faculty_ids'] ?? [];
    $due_date = $_POST['due_date'];

    if (empty($metric_ids) || empty($faculty_ids) || empty($due_date)) {
        $_SESSION['message'] = ['type' => 'error', 'text' => 'At least one Metric, one Faculty, and a Due Date are required.'];
        header("Location: lead_dashboard.php"); exit();
    }
    
    // Database and file operations remain the same
    $destination_dir = 'uploads/task_working_files/';
    if (!is_dir($destination_dir)) { mkdir($destination_dir, 0755, true); }
    
    $template_stmt = $mysqli->prepare("SELECT file_path FROM criterion_templates WHERE criterion_id = ?");
    $template_stmt->bind_param("i", $criterion_id_in_charge);
    $template_stmt->execute();
    $template_source_path = $template_stmt->get_result()->fetch_assoc()['file_path'] ?? null;
    $template_stmt->close();

    $mysqli->begin_transaction();
    try {
        $stmt_task = $mysqli->prepare("INSERT INTO tasks (metric_id, assigned_by_user_id, due_date) VALUES (?, ?, ?)");
        $stmt_assignee = $mysqli->prepare("INSERT INTO task_assignees (task_id, user_id) VALUES (?, ?)");
        $stmt_update_task = $mysqli->prepare("UPDATE tasks SET working_file_path = ? WHERE id = ?");

        foreach ($metric_ids as $metric_id) {
            $stmt_task->bind_param("iis", $metric_id, $lead_id, $due_date);
            $stmt_task->execute();
            $task_id = $mysqli->insert_id;
            foreach ($faculty_ids as $faculty_id) {
                $stmt_assignee->bind_param("ii", $task_id, $faculty_id);
                $stmt_assignee->execute();
            }
            if ($template_source_path && file_exists($template_source_path)) {
                $unique_filename = "task_{$task_id}_" . uniqid() . ".docx";
                $destination_file_path = $destination_dir . $unique_filename;
                if (copy($template_source_path, $destination_file_path)) {
                    $stmt_update_task->bind_param("si", $destination_file_path, $task_id);
                    $stmt_update_task->execute();
                }
            }
        }
        $mysqli->commit();

        // ===================================================================
        //
        //               --- MODIFICATION START: NEW EMAIL LOGIC ---
        //
        // This block now uses the reliable PHPMailer function `send_email_notification`.
        //
        // ===================================================================
        try {
            // 1. Get Metric Names (unchanged)
            $metric_ids_for_query = implode(',', array_map('intval', $metric_ids));
            $metric_name_res = $mysqli->query("SELECT name FROM metrics WHERE id IN ($metric_ids_for_query)");
            $metric_names_list = [];
            while ($row = $metric_name_res->fetch_assoc()) {
                $metric_names_list[] = $row['name'];
            }
            $metric_names_str = implode(', ', $metric_names_list);

            // 2. Get Faculty Emails and Names (unchanged)
            $faculty_ids_for_query = implode(',', array_map('intval', $faculty_ids));
            $faculty_res = $mysqli->query("SELECT name, email FROM users WHERE id IN ($faculty_ids_for_query)");
            $faculty_details = [];
            while ($row = $faculty_res->fetch_assoc()) {
                if (!empty($row['email'])) {
                   $faculty_details[] = $row;
                }
            }

            // 3. Get Assigner's Name and other details (unchanged)
            $assigner_name = $_SESSION['user_name'] ?? 'The Criterion Lead';
            $due_date_formatted = date("F j, Y", strtotime($due_date));
            $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https" : "http";
            $dashboard_url = $protocol . "://" . $_SERVER['HTTP_HOST'] . rtrim(dirname($_SERVER['PHP_SELF']), '/\\') . "/dashboard.php";

            // 4. Compose and Send Emails using our new function
            $emails_sent_count = 0;
            $total_faculty = count($faculty_details);

            foreach ($faculty_details as $faculty) {
                $faculty_name = htmlspecialchars($faculty['name']);
                
                // Prepare subject and body for the function
                $subject = 'New Task Assigned: ' . $metric_names_str;
                $html_body = "
                <html>
                <body style='font-family: Arial, sans-serif; line-height: 1.6;'>
                    <h2>New Task Assignment on Accreditation Portal</h2>
                    <p>Dear {$faculty_name},</p>
                    <p>A new task has been assigned to you by <strong>" . htmlspecialchars($assigner_name) . "</strong>.</p>
                    <hr>
                    <p><strong>Assigned Task(s):</strong> " . htmlspecialchars($metric_names_str) . "</p>
                    <p><strong>Due Date:</strong> {$due_date_formatted}</p>
                    <hr>
                    <p>Please log in to the portal to view details, download any required formats, and upload your documents.</p>
                    <p style='margin-top: 20px;'><a href='{$dashboard_url}' style='background-color: #0d6efd; color: white; padding: 10px 15px; text-decoration: none; border-radius: 5px;'>Go to Portal</a></p>
                    <br>
                    <p>Thank you,<br><em>The Accreditation Portal Team</em></p>
                </body>
                </html>";

                // Call the reliable PHPMailer function and count successes
                if (send_email_notification($faculty['email'], $faculty_name, $subject, $html_body)) {
                    $emails_sent_count++;
                }
            }
            
                    // Set a more informative success message
        $_SESSION['message'] = ['type' => 'success', 'text' => "Task(s) assigned successfully. Sent {$emails_sent_count} of {$total_faculty} email notifications."];
        
        // Create detailed notification for the lead
        $message = "You have assigned new tasks to faculty members.";
        $detailed_message = $message . "\n\nAssignment Details:\n";
        $detailed_message .= "• Metrics: " . htmlspecialchars($metric_names_str) . "\n";
        $detailed_message .= "• Faculty Members: " . count($faculty_details) . " assigned\n";
        $detailed_message .= "• Due Date: {$due_date_formatted}\n";
        $detailed_message .= "• Emails Sent: {$emails_sent_count} of {$total_faculty}\n";
        
        // Insert notification for the lead
        $stmt_notify = $mysqli->prepare("INSERT INTO notifications (user_id, message, link) VALUES (?, ?, ?)");
        $link = 'lead_dashboard.php#manage-tasks';
        $stmt_notify->bind_param("iss", $_SESSION['user_id'], $detailed_message, $link);
        $stmt_notify->execute();
        $stmt_notify->close();

        } catch (Exception $e) {
            // This catches errors during email PREPARATION (e.g., database query failed)
            error_log("Email notification preparation failed: " . $e->getMessage());
            $_SESSION['message'] = ['type' => 'success', 'text' => 'Task(s) assigned successfully, but failed to send email notifications due to a system error.'];
        }
        // ===================================================================
        //
        //               --- MODIFICATION END ---
        //
        // ===================================================================
        
    } catch (Exception $e) {
        $mysqli->rollback();
        error_log("Task assignment database error: " . $e->getMessage());
        $_SESSION['message'] = ['type' => 'error', 'text' => 'A database error occurred during assignment.'];
    }
    header("Location: lead_dashboard.php#assign-tasks");
    exit();
}


// --- All other actions remain unchanged ---

// --- ACTION: REVIEW A TASK ---
if ($action === 'review_task') {
    $task_id = (int)($_POST['task_id'] ?? 0);
    $decision = $_POST['review_decision'] ?? '';
    $remarks = trim($_POST['remarks'] ?? '');

    if ($task_id === 0 || empty($decision)) {
        $_SESSION['message'] = ['type' => 'error', 'text' => 'Invalid Task ID or decision.'];
        header("Location: lead_dashboard.php#tasks"); exit();
    }

    $mysqli->begin_transaction();
    try {
        // Get task details for notification
        $stmt_task = $mysqli->prepare("
            SELECT t.*, m.name as metric_name, 
                   GROUP_CONCAT(u.name SEPARATOR ', ') as faculty_names
            FROM tasks t 
            JOIN metrics m ON t.metric_id = m.id 
            JOIN task_assignees ta ON t.id = ta.task_id 
            JOIN users u ON ta.user_id = u.id 
            WHERE t.id = ?
            GROUP BY t.id
        ");
        $stmt_task->bind_param("i", $task_id);
        $stmt_task->execute();
        $task_details = $stmt_task->get_result()->fetch_assoc();
        $stmt_task->close();
        
        if ($decision === 'Approve') {
            $stmt = $mysqli->prepare("UPDATE tasks SET status = 'Approved', remarks = ? WHERE id = ?");
            $stmt->bind_param("si", $remarks, $task_id);
            $stmt->execute();
            $_SESSION['message'] = ['type' => 'success', 'text' => 'Task has been approved.'];
            
            // Create detailed notification
            $message = "Task has been approved.";
            $detailed_message = $message . "\n\nTask Details:\n";
            $detailed_message .= "• Metric: " . ($task_details['metric_name'] ?? 'Unknown') . "\n";
            $detailed_message .= "• Faculty: " . ($task_details['faculty_names'] ?? 'Unknown') . "\n";
            if (!empty($remarks)) {
                $detailed_message .= "• Remarks: {$remarks}\n";
            }
            
            $stmt_notify = $mysqli->prepare("INSERT INTO notifications (user_id, message, link) VALUES (?, ?, ?)");
            $link = 'lead_dashboard.php#manage-tasks';
            $stmt_notify->bind_param("iss", $_SESSION['user_id'], $detailed_message, $link);
            $stmt_notify->execute();
            $stmt_notify->close();
            
        } elseif ($decision === 'Reject') {
            if (empty($remarks)) {
                $_SESSION['message'] = ['type' => 'error', 'text' => 'Remarks are required when rejecting a task.'];
                header("Location: lead_dashboard.php#tasks"); exit();
            }
            $stmt = $mysqli->prepare("UPDATE tasks SET status = 'Rejected', remarks = ? WHERE id = ?");
            $stmt->bind_param("si", $remarks, $task_id);
            $stmt->execute();
            $_SESSION['message'] = ['type' => 'info', 'text' => 'Task has been rejected and feedback was provided.'];
            
            // Create detailed notification
            $message = "Task has been rejected.";
            $detailed_message = $message . "\n\nTask Details:\n";
            $detailed_message .= "• Metric: " . ($task_details['metric_name'] ?? 'Unknown') . "\n";
            $detailed_message .= "• Faculty: " . ($task_details['faculty_names'] ?? 'Unknown') . "\n";
            $detailed_message .= "• Remarks: {$remarks}\n";
            
            $stmt_notify = $mysqli->prepare("INSERT INTO notifications (user_id, message, link) VALUES (?, ?, ?)");
            $link = 'lead_dashboard.php#manage-tasks';
            $stmt_notify->bind_param("iss", $_SESSION['user_id'], $detailed_message, $link);
            $stmt_notify->execute();
            $stmt_notify->close();
            
        } elseif ($decision === 'Reassign') {
            $reassign_ids = $_POST['reassign_ids'] ?? [];
            $new_due_date = $_POST['reassign_due_date'] ?? '';

            if (empty($reassign_ids)) {
                 $_SESSION['message'] = ['type' => 'error', 'text' => 'You must select at least one faculty member to add to the task.'];
                 header("Location: lead_dashboard.php#tasks"); exit();
            }
            
            // Get names of newly assigned faculty
            $new_faculty_names = [];
            $stmt_new_faculty = $mysqli->prepare("SELECT name FROM users WHERE id IN (" . implode(',', array_fill(0, count($reassign_ids), '?')) . ")");
            $stmt_new_faculty->bind_param(str_repeat('i', count($reassign_ids)), ...$reassign_ids);
            $stmt_new_faculty->execute();
            $new_faculty_result = $stmt_new_faculty->get_result();
            while ($row = $new_faculty_result->fetch_assoc()) {
                $new_faculty_names[] = $row['name'];
            }
            $stmt_new_faculty->close();
            
            $stmt_add = $mysqli->prepare("INSERT IGNORE INTO task_assignees (task_id, user_id) VALUES (?, ?)");
            foreach ($reassign_ids as $user_id) {
                $current_user_id = (int)$user_id;
                $stmt_add->bind_param("ii", $task_id, $current_user_id);
                $stmt_add->execute();
            }
            $stmt_add->close();

            if (!empty($new_due_date)) {
                $stmt_update = $mysqli->prepare("UPDATE tasks SET status = 'In Progress', remarks = ?, due_date = ? WHERE id = ?");
                $stmt_update->bind_param("ssi", $remarks, $new_due_date, $task_id);
            } else {
                $stmt_update = $mysqli->prepare("UPDATE tasks SET status = 'In Progress', remarks = ? WHERE id = ?");
                $stmt_update->bind_param("si", $remarks, $task_id);
            }
            $stmt_update->execute();
            $stmt_update->close();
            
            $_SESSION['message'] = ['type' => 'success', 'text' => 'Task has been updated and reassigned.'];
            
            // Create detailed notification
            $message = "Task has been reassigned.";
            $detailed_message = $message . "\n\nTask Details:\n";
            $detailed_message .= "• Metric: " . ($task_details['metric_name'] ?? 'Unknown') . "\n";
            $detailed_message .= "• Original Faculty: " . ($task_details['faculty_names'] ?? 'Unknown') . "\n";
            $detailed_message .= "• New Faculty Added: " . implode(', ', $new_faculty_names) . "\n";
            if (!empty($new_due_date)) {
                $detailed_message .= "• New Due Date: " . date("F j, Y", strtotime($new_due_date)) . "\n";
            }
            if (!empty($remarks)) {
                $detailed_message .= "• Remarks: {$remarks}\n";
            }
            
            $stmt_notify = $mysqli->prepare("INSERT INTO notifications (user_id, message, link) VALUES (?, ?, ?)");
            $link = 'lead_dashboard.php#manage-tasks';
            $stmt_notify->bind_param("iss", $_SESSION['user_id'], $detailed_message, $link);
            $stmt_notify->execute();
            $stmt_notify->close();
        }
        $mysqli->commit();
    } catch (Exception $e) {
        $mysqli->rollback();
        $_SESSION['message'] = ['type' => 'error', 'text' => 'A database error occurred. Operation failed.'];
    }
    header("Location: lead_dashboard.php#tasks");
    exit();
}

// --- ACTION: DELETE A TASK ---
if ($action === 'delete_task') {
    $task_id = (int)($_POST['task_id'] ?? 0);
    if ($task_id > 0) {
        $mysqli->begin_transaction();
        try {
            $files_to_delete = [];
            $stmt_workfile = $mysqli->prepare("SELECT working_file_path FROM tasks WHERE id = ?");
            $stmt_workfile->bind_param("i", $task_id);
            $stmt_workfile->execute();
            $workfile_result = $stmt_workfile->get_result()->fetch_assoc();
            if ($workfile_result && !empty($workfile_result['working_file_path'])) {
                $files_to_delete[] = $workfile_result['working_file_path'];
            }
            $stmt_workfile->close();

            $stmt_proofs = $mysqli->prepare("SELECT p.file_path FROM proofs p JOIN task_assignees ta ON p.task_assignee_id = ta.id WHERE ta.task_id = ?");
            $stmt_proofs->bind_param("i", $task_id);
            $stmt_proofs->execute();
            $proofs_res = $stmt_proofs->get_result();
            while ($proof = $proofs_res->fetch_assoc()) {
                if (!empty($proof['file_path'])) {
                    $files_to_delete[] = $proof['file_path'];
                }
            }
            $stmt_proofs->close();
            
            $stmt_del_assignees = $mysqli->prepare("DELETE FROM task_assignees WHERE task_id = ?");
            $stmt_del_assignees->bind_param("i", $task_id);
            $stmt_del_assignees->execute();
            $stmt_del_assignees->close();
            
            $stmt_del_task = $mysqli->prepare("DELETE FROM tasks WHERE id = ?");
            $stmt_del_task->bind_param("i", $task_id);
            $stmt_del_task->execute();
            $stmt_del_task->close();
            
            $mysqli->commit();
            foreach ($files_to_delete as $file_path) {
                if (file_exists($file_path)) {
                    @unlink($file_path);
                }
            }
            $_SESSION['message'] = ['type' => 'success', 'text' => 'Task and all associated files deleted successfully.'];
        } catch(Exception $e) {
            $mysqli->rollback();
            $_SESSION['message'] = ['type' => 'error', 'text' => 'Error deleting the task due to a database issue.'];
        }
    } else {
        $_SESSION['message'] = ['type' => 'error', 'text' => 'Invalid task ID provided for deletion.'];
    }
    header("Location: lead_dashboard.php#tasks");
    exit();
}

// --- ACTION: UPLOAD/REPLACE METRIC ATTACHMENT ---
if ($action === 'upload_metric_attachment') {
    $metric_id = (int)($_POST['metric_id'] ?? 0);
    if ($metric_id > 0 && isset($_FILES['attachment_file']) && $_FILES['attachment_file']['error'] == 0) {
        
        $upload_dir = 'uploads/pending_updates/';
        if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);
        
        $original_filename = basename($_FILES['attachment_file']['name']);
        $safe_filename = "pending_{$lead_id}_metric_{$metric_id}_" . uniqid() . "_" . preg_replace('/[^A-Za-z0-9\._-]/', '', $original_filename);
        $file_path = $upload_dir . $safe_filename;
        
        if (move_uploaded_file($_FILES['attachment_file']['tmp_name'], $file_path)) {
            $request_reason = trim($_POST['request_reason'] ?? '');
            $stmt = $mysqli->prepare("INSERT INTO pending_updates (update_type, target_id, requested_by_user_id, new_file_path, original_filename, remarks) VALUES ('metric_attachment', ?, ?, ?, ?, ?)");
            $stmt->bind_param("iisss", $metric_id, $lead_id, $file_path, $original_filename, $request_reason);
            
            if ($stmt->execute()) {
                $_SESSION['message'] = ['type' => 'success', 'text' => 'Attachment update request submitted successfully for admin approval.'];
            } else {
                unlink($file_path); // Clean up the uploaded file on DB error
                $_SESSION['message'] = ['type' => 'error', 'text' => 'Database error while submitting request.'];
            }
            $stmt->close();
        } else {
            $_SESSION['message'] = ['type' => 'error', 'text' => 'Failed to save the uploaded file for review.'];
        }
    } else {
        $_SESSION['message'] = ['type' => 'error', 'text' => 'Invalid metric or file upload error.'];
    }
    header("Location: lead_dashboard.php#manage-documents");
    exit();
}

// --- ACTION: DELETE METRIC ATTACHMENT ---
if ($action === 'delete_metric_attachment') {
    $metric_id = (int)($_POST['metric_id'] ?? 0);
    if ($metric_id > 0) {
        $stmt_get = $mysqli->prepare("SELECT file_path FROM metric_attachments WHERE metric_id = ?");
        $stmt_get->bind_param("i", $metric_id);
        $stmt_get->execute();
        $file_to_delete = $stmt_get->get_result()->fetch_assoc();
        
        $stmt_del = $mysqli->prepare("DELETE FROM metric_attachments WHERE metric_id = ?");
        $stmt_del->bind_param("i", $metric_id);
        if ($stmt_del->execute()) {
            if ($file_to_delete && file_exists($file_to_delete['file_path'])) {
                unlink($file_to_delete['file_path']);
            }
            $_SESSION['message'] = ['type' => 'success', 'text' => 'Attachment deleted successfully.'];
        } else {
            $_SESSION['message'] = ['type' => 'error', 'text' => 'Error deleting attachment record.'];
        }
    } else {
         $_SESSION['message'] = ['type' => 'error', 'text' => 'Invalid Metric ID provided.'];
    }
    header("Location: lead_dashboard.php#manage-documents");
    exit();
}

// --- ACTION: UPLOAD/REPLACE CRITERION TEMPLATE ---
// MODIFIED: This now creates a pending request for admin approval.
if ($action === 'upload_criterion_template') {
    if (isset($_FILES['template_file']) && $_FILES['template_file']['error'] == 0) {
        if (pathinfo($_FILES['template_file']['name'], PATHINFO_EXTENSION) !== 'docx') {
             $_SESSION['message'] = ['type' => 'error', 'text' => 'Invalid file type. Only .docx files are allowed.'];
        } else {
            $upload_dir = 'uploads/pending_updates/';
            if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);

            $original_filename = basename($_FILES['template_file']['name']);
            $safe_filename = "pending_{$lead_id}_criterion_{$criterion_id_in_charge}_" . time() . ".docx";
            $file_path = $upload_dir . $safe_filename;
            
            if (move_uploaded_file($_FILES['template_file']['tmp_name'], $file_path)) {
                $request_reason = trim($_POST['request_reason'] ?? '');
                $stmt = $mysqli->prepare("INSERT INTO pending_updates (update_type, target_id, requested_by_user_id, new_file_path, original_filename, remarks) VALUES ('criterion_template', ?, ?, ?, ?, ?)");
                $stmt->bind_param("iisss", $criterion_id_in_charge, $lead_id, $file_path, $original_filename, $request_reason);
                if ($stmt->execute()) {
                    $_SESSION['message'] = ['type' => 'success', 'text' => 'Criterion format update request submitted successfully for admin approval.'];
                } else {
                    unlink($file_path); // Clean up
                    $_SESSION['message'] = ['type' => 'error', 'text' => 'Database error while submitting request.'];
                }
            } else {
                $_SESSION['message'] = ['type' => 'error', 'text' => 'Failed to save format file for review.'];
            }
        }
    } else {
        $_SESSION['message'] = ['type' => 'error', 'text' => 'File upload error. Please try again.'];
    }
    header("Location: lead_dashboard.php#manage-format");
    exit();
}

if ($action === 'mark_notification_read' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $notification_id = $_POST['notification_id'];
    if (!empty($notification_id)) {
        $stmt = $mysqli->prepare("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?");
        $stmt->bind_param("ii", $notification_id, $_SESSION['user_id']);
        $stmt->execute();
        $stmt->close();
    }
    // Respond with a success status
    http_response_code(200);
    exit();
}

// --- ACTION: DELETE CRITERION TEMPLATE ---
if ($action === 'delete_criterion_template') {
    $stmt_get = $mysqli->prepare("SELECT file_path FROM criterion_templates WHERE criterion_id = ?");
    $stmt_get->bind_param("i", $criterion_id_in_charge);
    $stmt_get->execute();
    $file_to_delete = $stmt_get->get_result()->fetch_assoc();
    
    $stmt_del = $mysqli->prepare("DELETE FROM criterion_templates WHERE criterion_id = ?");
    $stmt_del->bind_param("i", $criterion_id_in_charge);
    if ($stmt_del->execute()) {
        if ($file_to_delete && file_exists($file_to_delete['file_path'])) {
            unlink($file_to_delete['file_path']);
        }
        $_SESSION['message'] = ['type' => 'success', 'text' => 'Criterion format deleted successfully.'];
    } else {
        $_SESSION['message'] = ['type' => 'error', 'text' => 'Error deleting criterion format.'];
    }
    $stmt_del->close();
    header("Location: lead_dashboard.php#manage-format");
    exit();
}


// ===================================================================
//
//                  --- NEW ACTION HANDLER START ---
//
// ===================================================================

// --- ACTION: ADD A NEW METRIC ---
if ($action === 'add_metric') {
    // 1. Get and validate input
    $metric_name = trim($_POST['metric_name'] ?? '');

    if (empty($metric_name)) {
        $_SESSION['message'] = ['type' => 'error', 'text' => 'Metric name cannot be empty.'];
        header("Location: lead_dashboard.php#manage-documents");
        exit();
    }
    
    // 2. Check if a metric with the same name already exists for this criterion
    $stmt_check = $mysqli->prepare("SELECT id FROM metrics WHERE name = ? AND criterion_id = ?");
    $stmt_check->bind_param("si", $metric_name, $criterion_id_in_charge);
    $stmt_check->execute();
    $stmt_check->store_result();
    
    if ($stmt_check->num_rows > 0) {
        $_SESSION['message'] = ['type' => 'error', 'text' => 'A metric with this name already exists in your criterion.'];
        $stmt_check->close();
        header("Location: lead_dashboard.php#manage-documents");
        exit();
    }
    $stmt_check->close();

    // 3. Prepare and execute the INSERT statement
    $stmt_insert = $mysqli->prepare("INSERT INTO metrics (name, criterion_id) VALUES (?, ?)");
    $stmt_insert->bind_param("si", $metric_name, $criterion_id_in_charge);

    if ($stmt_insert->execute()) {
        $_SESSION['message'] = ['type' => 'success', 'text' => 'New metric added successfully.'];
    } else {
        error_log("Metric creation failed: " . $stmt_insert->error);
        $_SESSION['message'] = ['type' => 'error', 'text' => 'Failed to add the new metric due to a database error.'];
    }
    $stmt_insert->close();

    // 4. Redirect back to the metric management page
    header("Location: lead_dashboard.php#manage-documents");
    exit();
}
// ===================================================================
//
//                   --- NEW ACTION HANDLER END ---
//
// ===================================================================


// Fallback redirect if no action matched
header("Location: lead_dashboard.php");
exit();
?>