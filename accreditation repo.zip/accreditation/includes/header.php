<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo $page_title ?? 'Accreditation Portal'; ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="navbar">
        <div class="logo">Accreditation Portal</div>
        <div class="user-info">
            Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?>!
            <a href="logout.php" class="btn btn-logout">Logout</a>
        </div>
    </div>
    <div class="container">