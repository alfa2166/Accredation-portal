<?php
// This file centralizes our email sending logic using PHPMailer.

// Import PHPMailer classes into the global namespace
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Load Composer's autoloader - this path assumes mailer.php is in an 'includes' folder
require_once __DIR__ . '/../vendor/autoload.php';

/**
 * Sends an email notification using PHPMailer with pre-configured SMTP settings.
 *
 * @param string $to_email The recipient's email address.
 * @param string $to_name The recipient's name.
 * @param string $subject The subject of the email.
 * @param string $html_body The HTML content of the email.
 * @return bool True on success, false on failure.
 */
function send_email_notification($to_email, $to_name, $subject, $html_body) {
    
    $mail = new PHPMailer(true);
    // Force IPv4 to avoid IPv6 connection issues on Windows/XAMPP
    $mail->SMTPOptions = [
        'socket' => [
            'bindto' => '0.0.0.0:0'
        ]
    ];

    try {
        // ===================================================================
        //
        //               --- SERVER CONFIGURATION ---
        //
        //     THIS IS THE MOST LIKELY PLACE FOR ERRORS.
        //     CONFIGURE THIS SECTION CAREFULLY.
        //
        // ===================================================================

        // --- TROUBLESHOOTING ---
        // To see detailed error messages, change DEBUG_OFF to DEBUG_SERVER
        // This will print the full conversation with the mail server.
        $mail->SMTPDebug = SMTP::DEBUG_SERVER; // Enable verbose SMTP debugging

        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';             // Use your SMTP server, e.g., smtp.gmail.com
        $mail->SMTPAuth   = true;                         // Enable SMTP authentication
        
        // --- YOUR CREDENTIALS ---
        $mail->Username   = 'subashnagarajanbaby@gmail.com';       // ** YOUR FULL GMAIL ADDRESS **
        $mail->Password   = 'atfwtbpwtyavrxzo';        // ** YOUR 16-CHARACTER GMAIL APP PASSWORD **
        
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;  // Use 'tls' for port 587
        $mail->Port       = 587;                          // Use 587 for TLS

        // --- RECIPIENTS ---
        // The 'From' email MUST match your Username email for many providers
        $mail->setFrom('subashnagarajanbaby@gmail.com', 'Accreditation Portal');
        $mail->addAddress($to_email, $to_name);
        $mail->addReplyTo('no-reply@yourdomain.com', 'No Reply');

        // --- CONTENT ---
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $html_body;
        $mail->AltBody = strip_tags($html_body); 

        $mail->send();
        return true;

    } catch (Exception $e) {
        // This error log is crucial. Check your server's error log file (e.g., php_error_log in XAMPP)
        error_log("PHPMailer Error: Failed to send email to {$to_email}. Reason: {$mail->ErrorInfo}");
        return false;
    }
}