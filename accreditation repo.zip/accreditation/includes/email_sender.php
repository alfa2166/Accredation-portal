<?php
// Include PHPMailer classes
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Require Composer's autoloader
require_once __DIR__ . '/../vendor/autoload.php';

function send_task_notification_email($recipient_email, $recipient_name, $task_name, $due_date, $assigned_by_name) {
    
    $mail = new PHPMailer(true);

    try {
        // --- Server settings (using Gmail SMTP) ---
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'subashnagarajanbaby@gmail.com'; // Your full Gmail address
        $mail->Password   = 'atfwtbpwtyavrxzo';   // The 16-character App Password you generated
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port       = 465;

        // --- Recipients ---
        $mail->setFrom('your-email@gmail.com', 'Accreditation Portal');
        $mail->addAddress($recipient_email, $recipient_name);
        $mail->addReplyTo('no-reply@college.ac.in', 'No Reply');

        // --- Content ---
        $mail->isHTML(true);
        $mail->Subject = 'New Task Assigned: ' . $task_name;
        
        $mail->Body    = "
            <html>
            <head><style>body{font-family: Arial, sans-serif;}</style></head>
            <body>
                <h2>New Task Assigned on Accreditation Portal</h2>
                <p>Hello " . htmlspecialchars($recipient_name) . ",</p>
                <p>A new task has been assigned to you by <strong>" . htmlspecialchars($assigned_by_name) . "</strong>.</p>
                <p><strong>Task:</strong> " . htmlspecialchars($task_name) . "</p>
                <p><strong>Due Date:</strong> " . date("F d, Y", strtotime($due_date)) . "</p>
                <p>Please log in to the portal to view the details and upload the required documents.</p>
                <br>
                <p>Thank you,</p>
                <p><em>The Accreditation Portal Team</em></p>
            </body>
            </html>
        ";
        
        $mail->AltBody = "Hello " . $recipient_name . ",\nA new task has been assigned to you: '" . $task_name . "'.\nDue Date: " . $due_date . ".\nPlease log in to the portal for details.";

        $mail->send();
        return true; // Email sent successfully

    } catch (Exception $e) {
        // You can log this error for debugging instead of showing it to the user
        // error_log("PHPMailer Error: {$mail->ErrorInfo}");
        return false; // Email failed to send
    }
}
?>