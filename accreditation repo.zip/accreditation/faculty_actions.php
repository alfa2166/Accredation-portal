<?php
session_start();
require_once 'config/db.php';

// Security check: only Faculty can perform these actions
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'Faculty') {
    die("Access Denied.");
}

$user_id = $_SESSION['user_id'];

if (isset($_POST['action']) && $_POST['action'] == 'upload_proof') {

    $task_id = $_POST['task_id'];
    $files = $_FILES['proof_files']; // Note the plural 'proof_files'

    // Check if any files were actually selected for upload
    if (empty($files['name'][0])) {
        $_SESSION['message'] = ['type' => 'error', 'text' => 'Please select at least one file to upload.'];
        header("Location: faculty_dashboard.php");
        exit();
    }

    $target_dir = "uploads/";
    $allowed_types = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'jpg', 'jpeg', 'png'];
    $max_file_size = 5000000; // 5 MB
    $uploaded_file_paths = [];
    $error_messages = [];
    
    $file_count = count($files['name']);

    // Get the task_assignee_id for this user and this task once, before the loop
    $stmt_get_id = $mysqli->prepare("SELECT id FROM task_assignees WHERE task_id = ? AND user_id = ?");
    $stmt_get_id->bind_param("ii", $task_id, $user_id);
    $stmt_get_id->execute();
    $result_id = $stmt_get_id->get_result();
    if ($result_id->num_rows === 0) {
        $_SESSION['message'] = ['type' => 'error', 'text' => 'Error: You are not assigned to this task.'];
        header("Location: faculty_dashboard.php");
        exit();
    }
    $task_assignee_id = $result_id->fetch_assoc()['id'];

    // --- Loop through each uploaded file ---
    for ($i = 0; $i < $file_count; $i++) {
        // Skip if there's no file (e.g., an empty file input)
        if ($files["error"][$i] == UPLOAD_ERR_NO_FILE) {
            continue;
        }

        $original_filename = basename($files["name"][$i]);
        $file_extension = strtolower(pathinfo($original_filename, PATHINFO_EXTENSION));
        
        // --- Validation for each file ---
        if ($files["error"][$i] !== UPLOAD_ERR_OK) {
            $error_messages[] = "Error with file '{$original_filename}': Upload error code " . $files["error"][$i];
            continue; // Skip to the next file
        }
        if (!in_array($file_extension, $allowed_types)) {
            $error_messages[] = "Invalid file type for '{$original_filename}'.";
            continue;
        }
        if ($files["size"][$i] > $max_file_size) {
            $error_messages[] = "File '{$original_filename}' is too large (Max 5MB).";
            continue;
        }

        // --- Process a valid file ---
        $unique_filename = uniqid('proof_' . $task_id . '_', true) . '.' . $file_extension;
        $target_file = $target_dir . $unique_filename;

        if (move_uploaded_file($files["tmp_name"][$i], $target_file)) {
            $uploaded_file_paths[] = [
                'path' => $target_file,
                'original_name' => $original_filename
            ];
        } else {
            $error_messages[] = "Server could not save the file '{$original_filename}'.";
        }
    }

    // --- Database Insertion ---
    if (!empty($uploaded_file_paths)) {
        $mysqli->begin_transaction();
        try {
            $sql_proof = "INSERT INTO proofs (task_assignee_id, file_path, original_filename) VALUES (?, ?, ?)";
            $stmt_proof = $mysqli->prepare($sql_proof);
            
            foreach ($uploaded_file_paths as $file_info) {
                $stmt_proof->bind_param("iss", $task_assignee_id, $file_info['path'], $file_info['original_name']);
                $stmt_proof->execute();
            }

            $sql_user_status = "UPDATE task_assignees SET submission_status = 'Submitted' WHERE id = ?";
            $stmt_user_status = $mysqli->prepare($sql_user_status);
            $stmt_user_status->bind_param("i", $task_assignee_id);
            $stmt_user_status->execute();
            
            $stmt_check_all = $mysqli->prepare("SELECT COUNT(*) as pending_count FROM task_assignees WHERE task_id = ? AND submission_status = 'Not Submitted'");
            $stmt_check_all->bind_param("i", $task_id);
            $stmt_check_all->execute();
            $pending_count = $stmt_check_all->get_result()->fetch_assoc()['pending_count'];
            
            $new_task_status = ($pending_count == 0) ? 'Submitted' : 'In Progress';
            
            $sql_task_status = "UPDATE tasks SET status = ? WHERE id = ?";
            $stmt_task_status = $mysqli->prepare($sql_task_status);
            $stmt_task_status->bind_param("si", $new_task_status, $task_id);
            $stmt_task_status->execute();

            $mysqli->commit();
            
            $success_message = count($uploaded_file_paths) . " file(s) uploaded and submitted successfully!";
            if (!empty($error_messages)) {
                $_SESSION['message'] = ['type' => 'info', 'text' => $success_message . " Some files had errors and were skipped: " . implode(', ', $error_messages)];
            } else {
                $_SESSION['message'] = ['type' => 'success', 'text' => $success_message];
            }

        } catch (Exception $e) {
            $mysqli->rollback();
            foreach ($uploaded_file_paths as $file_info) {
                if (file_exists($file_info['path'])) {
                    unlink($file_info['path']);
                }
            }
            $_SESSION['message'] = ['type' => 'error', 'text' => 'A database error occurred. Could not save proofs.'];
        }
    } elseif (!empty($error_messages)) {
        $_SESSION['message'] = ['type' => 'error', 'text' => "File upload failed: " . implode(', ', $error_messages)];
    }

    header("Location: faculty_dashboard.php");
    exit();
}
?>