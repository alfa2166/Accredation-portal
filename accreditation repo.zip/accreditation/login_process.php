<?php
session_start();
require_once 'config/db.php';

// Check if form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password']; // The plain text password from the login form

    if (empty($email) || empty($password)) {
        $_SESSION['error_message'] = "Email and password are required.";
        header("Location: login.php");
        exit();
    }

    // This query is already correct from our previous fix
    $sql = "SELECT u.id, u.name, u.email, u.password, 
                   r.name as role_name, 
                   u.department_id, 
                   u.criterion_id 
            FROM users u 
            JOIN roles r ON u.role_id = r.id 
            WHERE u.email = ?";
            
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        
        // --- FIX: USE password_verify() FOR SECURE LOGIN ---
        // This compares the plain text password from the form ($password)
        // with the hashed password from the database ($user['password']).
        if (password_verify($password, $user['password'])) {

            // Regenerate session ID for security
            session_regenerate_id(true);

            // Set session variables (this part is already correct)
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['user_role'] = $user['role_name'];
            $_SESSION['user_department_id'] = $user['department_id'];
            $_SESSION['user_criterion_id'] = $user['criterion_id'];

            // Redirect based on role
            switch ($user['role_name']) {
                case 'Admin':
                    header("Location: admin_dashboard.php");
                    break;
                case 'HOD':
                    header("Location: hod_dashboard.php");
                    break;
                case 'Criterion Lead':
                    header("Location: lead_dashboard.php");
                    break;
                case 'Faculty':
                    header("Location: faculty_dashboard.php");
                    break;
                default:
                    $_SESSION['error_message'] = "Unknown user role.";
                    header("Location: login.php");
                    break;
            }
            exit();

        } else {
            // Invalid password
            $_SESSION['error_message'] = "Invalid email or password.";
            header("Location: login.php");
            exit();
        }
    } else {
        // No user found with that email
        $_SESSION['error_message'] = "Invalid email or password.";
        header("Location: login.php");
        exit();
    }

    $stmt->close();
    $mysqli->close();
} else {
    header("Location: login.php");
    exit();
}
?>