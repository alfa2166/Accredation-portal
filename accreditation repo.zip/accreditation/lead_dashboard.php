<?php
require_once 'includes/auth_check.php';
require_once 'config/db.php';

if ($_SESSION['user_role'] !== 'Criterion Lead' || !isset($_SESSION['user_criterion_id'])) {
    die("Access Denied.");
}

$page_title = 'Criterion Lead Dashboard';
require_once 'includes/header.php';

$lead_id = $_SESSION['user_id'];
$criterion_id_in_charge = $_SESSION['user_criterion_id'];

// --- MODIFICATION: Added array of possible job descriptions ---
$job_descriptions = [
    "Class Counselor", "Test co-ordinator", "Internship co-ordinator", "R&D co-ordinator",
    "Bos co-ordinator", "NPTEL - co-ordinator", "MOU - co-ordinator", "Continuing Education Co-ordinator",
    "Consultancy Co-ordinator", "Publication - co-ordinator", "Patent Incharge", "NBA - co-ordinator (Dept)",
    "ISO - Incharge (Dept)", "NAAC co-ordinator", "NIRF Incharge", "Placement co-ordinator",
    "Club co-ordinator", "Seminar/Workshop/Guest Lecture Organized", "Alumni - co-ordinator",
    "Student/Staff Achievement", "Higher Studies"
];

// === DATA FETCHING ===
$criterion_name = "Criterion " . $criterion_id_in_charge;
$stmt_crit_name = $mysqli->prepare("SELECT name FROM criteria WHERE id = ?");
if($stmt_crit_name){$stmt_crit_name->bind_param("i", $criterion_id_in_charge);$stmt_crit_name->execute();$crit_name_res = $stmt_crit_name->get_result();if ($crit_name_res->num_rows > 0) {$criterion_name = $crit_name_res->fetch_assoc()['name'];}$stmt_crit_name->close();}

$all_metrics_in_criterion = [];
$stmt_all_metrics = $mysqli->prepare("SELECT m.id, m.name, (SELECT GROUP_CONCAT(DISTINCT u.department_id) FROM tasks t JOIN task_assignees ta ON t.id = ta.task_id JOIN users u ON ta.user_id = u.id WHERE t.metric_id = m.id AND u.department_id IS NOT NULL) as assigned_dept_ids FROM metrics m WHERE m.criterion_id = ? ORDER BY m.name ASC");
if($stmt_all_metrics){$stmt_all_metrics->bind_param("i", $criterion_id_in_charge);$stmt_all_metrics->execute();$result = $stmt_all_metrics->get_result();while($row = $result->fetch_assoc()){$row['assigned_dept_ids'] = $row['assigned_dept_ids'] ? array_map('intval', explode(',', $row['assigned_dept_ids'])) : [];$all_metrics_in_criterion[] = $row;}$stmt_all_metrics->close();}

$tasks_result = null;
$stmt_tasks = $mysqli->prepare("SELECT t.*, m.name as metric_name, m.id as metric_id, (SELECT GROUP_CONCAT(u.name SEPARATOR ', ') FROM task_assignees ta JOIN users u ON ta.user_id = u.id WHERE ta.task_id = t.id) as faculty_names, (SELECT GROUP_CONCAT(DISTINCT u.department_id) FROM task_assignees ta JOIN users u ON ta.user_id = u.id WHERE ta.task_id = t.id AND u.department_id IS NOT NULL) as task_department_ids FROM tasks t JOIN metrics m ON t.metric_id = m.id WHERE m.criterion_id = ? ORDER BY m.name ASC, FIELD(t.status, 'Submitted', 'Rejected', 'Pending', 'In Progress', 'Approved'), t.due_date ASC");
if($stmt_tasks){$stmt_tasks->bind_param("i", $criterion_id_in_charge);$stmt_tasks->execute();$tasks_result = $stmt_tasks->get_result();$stmt_tasks->close();}

$grouped_tasks = [];
if ($tasks_result && $tasks_result->num_rows > 0) {
    $tasks_result->data_seek(0);
    while($task = $tasks_result->fetch_assoc()) {
        $grouped_tasks[$task['metric_name']][] = $task;
    }
}

/// ===================================================================
//
//               --- FIX START ---
//
// 1. The users query is corrected to use a LEFT JOIN to fetch the job description name.
// 2. The job descriptions array is now fetched dynamically from the database.
//
// ===================================================================

$all_users_for_filter = [];
$departments_array = [];
$roles_array = [];
$job_descriptions_array = []; // Use this for the dropdown

// --- CORRECTED QUERY ---
// This now correctly joins the users table with the job_descriptions table
// to get the job description name, which is aliased as `job_description`.
$users_query_result = $mysqli->query("
    SELECT 
        u.id, 
        u.name, 
        u.role_id, 
        u.department_id, 
        jd.name AS job_description 
    FROM users u
    LEFT JOIN job_descriptions jd ON u.job_description_id = jd.id
    ORDER BY u.name
");

if ($users_query_result) {
    $all_users_for_filter = $users_query_result->fetch_all(MYSQLI_ASSOC);
} else {
    // This fallback is good practice but the primary query should now work.
    error_log("Failed to fetch users with job descriptions: " . $mysqli->error);
}

// Fetch departments (no change needed here)
$depts_query_result = $mysqli->query("SELECT id, name FROM departments ORDER BY name");
if ($depts_query_result) {
    $departments_array = $depts_query_result->fetch_all(MYSQLI_ASSOC);
}

// Fetch roles (no change needed here)
$roles_query_result = $mysqli->query("SELECT id, name FROM roles ORDER BY name");
if ($roles_query_result) {
    $roles_array = $roles_query_result->fetch_all(MYSQLI_ASSOC);
}

// --- NEW DYNAMIC QUERY FOR JOB DESCRIPTIONS ---
// Fetch job descriptions dynamically from the database instead of hardcoding them.
$jobs_query_result = $mysqli->query("SELECT id, name FROM job_descriptions ORDER BY name");
if ($jobs_query_result) {
    $job_descriptions_array = $jobs_query_result->fetch_all(MYSQLI_ASSOC);
}

// --- FETCH PENDING REQUESTS FOR THIS LEAD ---
$pending_requests = [];
$pending_query = "
    SELECT 
        pu.*, 
        CASE 
            WHEN pu.update_type = 'criterion_template' THEN c.name 
            ELSE m.name 
        END as target_name
    FROM pending_updates pu
    LEFT JOIN criteria c ON pu.target_id = c.id AND pu.update_type = 'criterion_template'
    LEFT JOIN metrics m ON pu.target_id = m.id AND pu.update_type = 'metric_attachment'
    WHERE pu.requested_by_user_id = ?
    ORDER BY pu.requested_at DESC
";
$stmt_pending = $mysqli->prepare($pending_query);
if ($stmt_pending) {
    $stmt_pending->bind_param("i", $lead_id);
    $stmt_pending->execute();
    $pending_result = $stmt_pending->get_result();
    while ($row = $pending_result->fetch_assoc()) {
        $pending_requests[] = $row;
    }
    $stmt_pending->close();
}

// --- FETCH APPROVAL STATISTICS FOR THE LEAD ---
$approval_stats = ['Pending' => 0, 'Approved' => 0, 'Rejected' => 0];
$stats_query = "
    SELECT status, COUNT(*) as count 
    FROM pending_updates 
    WHERE requested_by_user_id = ? 
    GROUP BY status
";
$stmt_stats = $mysqli->prepare($stats_query);
if ($stmt_stats) {
    $stmt_stats->bind_param("i", $lead_id);
    $stmt_stats->execute();
    $stats_result = $stmt_stats->get_result();
    while ($row = $stats_result->fetch_assoc()) {
        if (isset($approval_stats[$row['status']])) {
            $approval_stats[$row['status']] = $row['count'];
        }
    }
    $stmt_stats->close();
}

// Fetch unread notifications for the Lead
$notifications_result = $mysqli->prepare("SELECT * FROM notifications WHERE user_id = ? AND is_read = 0 ORDER BY created_at DESC");
$notifications_result->bind_param("i", $lead_id);
$notifications_result->execute();
$notifications = $notifications_result->get_result()->fetch_all(MYSQLI_ASSOC);
$unread_count = count($notifications);

// --- MODIFIED: Fetch all document update requests for the lead ---
$all_requests = [];
$requests_query = "
    SELECT 
        pu.*, 
        CASE 
            WHEN pu.update_type = 'criterion_template' THEN c.name 
            ELSE m.name 
        END as target_name,
        CASE
            WHEN pu.update_type = 'criterion_template' THEN 'Criterion Template'
            ELSE 'Metric Attachment'
        END as request_type
    FROM pending_updates pu
    LEFT JOIN criteria c ON pu.target_id = c.id AND pu.update_type = 'criterion_template'
    LEFT JOIN metrics m ON pu.target_id = m.id AND pu.update_type = 'metric_attachment'
    WHERE pu.requested_by_user_id = ?
    ORDER BY pu.requested_at DESC
";

$stmt_requests = $mysqli->prepare($requests_query);
if ($stmt_requests) {
    $stmt_requests->bind_param("i", $lead_id);
    $stmt_requests->execute();
    $requests_result = $stmt_requests->get_result();
    while ($row = $requests_result->fetch_assoc()) {
        $all_requests[] = $row;
    }
    $stmt_requests->close();
}

// ===================================================================
//
//               --- FIX END ---
//
// ===================================================================

$metrics_attachments_result = null;
$stmt_attachments = $mysqli->prepare("SELECT m.id AS metric_id, m.name AS metric_name, ma.file_path, ma.original_filename FROM metrics m LEFT JOIN metric_attachments ma ON m.id = ma.metric_id WHERE m.criterion_id = ? ORDER BY m.name");
if($stmt_attachments){$stmt_attachments->bind_param("i", $criterion_id_in_charge);$stmt_attachments->execute();$metrics_attachments_result = $stmt_attachments->get_result();$stmt_attachments->close();}

$criterion_template = null;
$stmt_template = $mysqli->prepare("SELECT * FROM criterion_templates WHERE criterion_id = ?");
if ($stmt_template) {
    $stmt_template->bind_param("i", $criterion_id_in_charge);
    $stmt_template->execute();
    $criterion_template = $stmt_template->get_result()->fetch_assoc();
    $stmt_template->close();
}
?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<style>
    /* === HAMBURGER MENU & OVERLAY STYLES === */
    .page-header { display: flex; align-items: center; gap: 20px; margin-bottom: 1rem; }
    .hamburger-menu { 
        background: #f8f9fa; 
        border: 1px solid #dee2e6; 
        color: #343a40; 
        font-size: 1.5rem; 
        width: 45px; 
        height: 45px; 
        border-radius: 8px; 
        cursor: pointer; 
        display: flex; 
        align-items: center; 
        justify-content: center; 
        transition: all 0.2s ease;
        z-index: 1001;
    }
    
    .hamburger-menu:hover { 
        background-color: #e9ecef; 
        transform: scale(1.05);
    }
    
    .hamburger-menu:active {
        transform: scale(0.95);
    }
    #menu-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.6); z-index: 999; opacity: 0; visibility: hidden; transition: opacity 0.3s ease, visibility 0s 0.3s; }
    #menu-overlay.is-visible { opacity: 1; visibility: visible; transition: opacity 0.3s ease; }

    .dashboard-sidebar.is-open ~ .dashboard-container .hamburger-menu {
        visibility: hidden;
        opacity: 0;
        transition: visibility 0s 0.2s, opacity 0.2s ease;
    }

    /* === REVISED SIDEBAR STYLES (for slide-in menu) === */
    .dashboard-sidebar {
        position: fixed; 
        top: 0; 
        left: 0; 
        height: 100vh; 
        width: 280px;
        background-color: #f8f9fa; 
        padding: 0; 
        z-index: 1000;
        transform: translateX(-100%); 
        transition: transform 0.3s ease-in-out;
        display: flex; 
        flex-direction: column;
        box-shadow: none;
    }
    
    .dashboard-sidebar.is-open { 
        transform: translateX(0); 
        box-shadow: 3px 0 15px rgba(0,0,0,0.1); 
    }
    .sidebar-header { display: flex; justify-content: space-between; align-items: center; padding: 15px 20px; border-bottom: 1px solid #ddd; background-color: #fff; }
    .sidebar-header h3 { margin: 0; font-size: 1.2rem; }
    .close-btn { background: none; border: none; font-size: 2rem; cursor: pointer; color: #6c757d; line-height: 1; padding: 0 5px; }
    .sidebar-nav { flex-grow: 1; overflow-y: auto; padding: 15px; }
    .sidebar-nav ul { list-style: none; padding: 0; margin: 0; }
    .sidebar-nav .nav-link { display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 12px 15px; text-decoration: none; color: #343a40; border-radius: 6px; margin-bottom: 5px; font-weight: 500; transition: background-color 0.2s ease, color 0.2s ease; }
    .sidebar-nav .nav-link:hover { background-color: #e9ecef; }
    .sidebar-nav .nav-link.active { background-color: #0d6efd; color: white; }
    .sidebar-nav .nav-link .link-text { display: flex; align-items: center; gap: 12px; }
    .sidebar-nav .nav-link .fa-fw { width: 20px; }
    .submenu-arrow { font-size: 0.8em; transition: transform 0.3s ease; }
    .nav-item-has-submenu .nav-link.active .submenu-arrow { transform: rotate(180deg); }
    .sidebar-nav .submenu { list-style: none; padding-left: 20px; max-height: 0; overflow: hidden; transition: max-height 0.3s ease-out; }
    .sidebar-nav .submenu.open { max-height: 1000px; }
    .sidebar-nav .submenu .nav-link { font-size: 0.9em; padding: 10px 15px 10px 25px; }
    .sidebar-nav .submenu .nav-link.active { background-color: #0a58ca; }
    .sidebar-nav .nav-link.submenu-parent.active { background-color: #0d6efd; color: white; }

    /* === GENERAL LAYOUT & OTHER STYLES === */
    .dashboard-container { /* No longer a flex container */ }
    .dashboard-content { /* No longer a flex item */ }
    .content-section { display: none; }
    .content-section.active { display: block; animation: fadeIn 0.5s; }
    @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }

    .metric-group-header { background-color: #e9ecef; padding: 10px 15px; border-radius: 6px; margin-top: 20px; margin-bottom: 10px; font-size: 1.1rem; font-weight: 600; border-left: 4px solid #0d6efd; }
    .metric-group:first-child .metric-group-header { margin-top: 0; }
    .checkbox-list { max-height: 220px; overflow-y: auto; border: 1px solid #ccc; padding: 10px; border-radius: 4px; background: #fdfdff; }
    .faculty-filters { background-color: #f1f1f1; padding: 15px; border-radius: 8px; margin-bottom: 10px; display: flex; flex-wrap: wrap; gap: 20px; align-items: flex-end; }
    .item-actions { display: flex; align-items: center; gap: 10px; }
    .delete-form { margin-left: auto; }
    .btn-danger { background-color: #dc3545; color: white; border: none; padding: 8px 12px; border-radius: 4px; cursor: pointer; }
    .attachment-form { display: flex; align-items: center; gap: 10px; }
    .assignment-item-hod { display: grid; background: #fff; border: 1px solid #ddd; border-radius: 8px; margin-bottom: 15px; grid-template-columns: 1fr auto auto; grid-template-areas: "info status actions" "docs docs docs"; grid-template-rows: auto 1fr; }
    .item-main-info, .item-status, .item-actions, .item-proofs { padding: 15px; }
    .item-main-info { grid-area: info; } .item-status { grid-area: status; } .item-actions { grid-area: actions; } .item-proofs { grid-area: docs; border-top: 1px solid #eee; }
    .format-management-box { background-color: #fffaf0; border: 1px solid #ffeeba; padding: 20px; border-radius: 8px; }
    
    /* Status Badge Styles */
    .status-badge {
        padding: 5px 10px;
        border-radius: 4px;
        font-size: 0.9em;
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    
    .status-pending {
        background-color: #fff3cd;
        color: #856404;
        border: 1px solid #ffeaa7;
    }
    
    .status-approved {
        background-color: #d4edda;
        color: #155724;
        border: 1px solid #c3e6cb;
    }
    
    .status-rejected {
        background-color: #f8d7da;
        color: #721c24;
        border: 1px solid #f5c6cb;
    }
    
    /* Row Status Styles */
    .pending-row {
        background-color: #fff3cd !important;
    }
    
    .approved-row {
        background-color: #d4edda !important;
    }
    
    .rejected-row {
        background-color: #f8d7da !important;
    }
    
    .data-table .pending-row:hover {
        background-color: #ffeaa7 !important;
    }
    
    .data-table .approved-row:hover {
        background-color: #c3e6cb !important;
    }
    
    .data-table .rejected-row:hover {
        background-color: #f5c6cb !important;
    }
    
    /* Button Action Styles */
    .btn-action {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        padding: 5px 10px;
        border-radius: 4px;
        text-decoration: none;
        transition: all 0.2s ease;
    }
    
    .btn-action:hover {
        transform: translateY(-1px);
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    
    .btn-download {
        background: #e3f2fd;
        border: 1px solid #2196f3;
        color: #1976d2;
    }
    
    .btn-download:hover {
        background: #bbdefb;
        color: #1565c0;
    }
    
    /* Badge Styles */
    .badge {
        display: inline-block;
        padding: 0.35em 0.65em;
        font-size: 0.75em;
        font-weight: 700;
        line-height: 1;
        text-align: center;
        white-space: nowrap;
        vertical-align: baseline;
        border-radius: 0.375rem;
    }
    
    .bg-primary {
        background-color: #0d6efd !important;
        color: white;
    }
    
    .bg-info {
        background-color: #0dcaf0 !important;
        color: white;
    }
    
    /* Modal Styles */
    .modal {
        display: none;
        position: fixed;
        z-index: 1000;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        overflow: auto;
        background-color: rgba(0,0,0,0.4);
    }
    
    .modal-content {
        background-color: #fefefe;
        margin: 5% auto;
        padding: 20px;
        border: 1px solid #888;
        width: 80%;
        max-width: 600px;
        border-radius: 8px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }
    
    .modal-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
        padding-bottom: 15px;
        border-bottom: 1px solid #dee2e6;
    }
    
    .modal-header h3 {
        margin: 0;
        color: #2c3e50;
    }
    
    .close {
        color: #aaa;
        font-size: 28px;
        font-weight: bold;
        cursor: pointer;
        transition: color 0.2s ease;
    }
    
    .close:hover {
        color: #000;
    }
    
    .modal-actions {
        display: flex;
        gap: 10px;
        justify-content: flex-end;
        margin-top: 20px;
        padding-top: 15px;
        border-top: 1px solid #dee2e6;
    }
    
    /* Button Styles */
    .btn {
        display: inline-block;
        padding: 8px 16px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        text-decoration: none;
        font-size: 14px;
        font-weight: 500;
        transition: all 0.2s ease;
    }
    
    .btn-primary {
        background-color: #007bff;
        color: white;
    }
    
    .btn-primary:hover {
        background-color: #0056b3;
    }
    
    .btn-secondary {
        background-color: #6c757d;
        color: white;
    }
    
    .btn-secondary:hover {
        background-color: #545b62;
    }
    
    .btn-sm {
        padding: 5px 10px;
        font-size: 12px;
    }

    /* Header Action Styles */
    .header-actions {
        display: flex;
        align-items: center;
        gap: 20px;
        margin-left: auto;
    }

    .notification-container {
        position: relative;
    }

    .notification-bell {
        background: #f8f9fa;
        border: 1px solid #dee2e6;
        color: #343a40;
        font-size: 1.5rem;
        width: 45px;
        height: 45px;
        border-radius: 8px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.2s ease;
        z-index: 1001;
    }

    .notification-bell:hover {
        background-color: #e9ecef;
        transform: scale(1.05);
    }

    .notification-bell:active {
        transform: scale(0.95);
    }

    .notification-count {
        position: absolute;
        top: -5px;
        right: -5px;
        background-color: #dc3545;
        color: white;
        font-size: 0.75em;
        font-weight: bold;
        border-radius: 50%;
        width: 20px;
        height: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
        border: 2px solid white;
    }

    .notification-dropdown {
        position: absolute;
        top: 100%; /* Position below the bell */
        right: 0;
        background-color: #fff;
        border: 1px solid #dee2e6;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        width: 400px; /* Adjust width as needed */
        max-height: 300px; /* Limit height */
        overflow-y: auto;
        z-index: 1002;
        display: none; /* Hidden by default */
    }

    .notification-dropdown.is-visible {
        display: block;
    }

    .notification-item {
        padding: 10px 15px;
        border-bottom: 1px solid #eee;
        font-size: 0.9em;
        color: #343a40;
        white-space: pre-line;
        line-height: 1.4;
    }

    .notification-item:last-child {
        border-bottom: none;
    }

    .notification-item a {
        color: #0d6efd;
        text-decoration: none;
        display: block;
        padding: 5px 0;
    }

    .notification-item a:hover {
        text-decoration: underline;
    }
</style>

<!-- Hamburger Menu Overlay -->
<div id="menu-overlay"></div>

<!-- ==== SIDEBAR NAVIGATION (now hidden by default) ==== -->
<nav class="dashboard-sidebar">
    <div class="sidebar-header">
        <h3>Menu</h3>
        <button id="close-sidebar-btn" class="close-btn" aria-label="Close menu">×</button>
    </div>
    <div class="sidebar-nav">
        <ul>
            <li><a href="#" class="nav-link active" data-target="#assign-tasks"><span class="link-text"><i class="fas fa-fw fa-tasks"></i> Assign New Tasks</span></a></li>
            <li class="nav-item-has-submenu">
                <a href="#" class="nav-link submenu-parent" data-target="#manage-tasks" id="submenu-toggle">
                    <span class="link-text"><i class="fas fa-fw fa-list-check"></i> Current Tasks</span>
                    <i class="fas fa-chevron-down submenu-arrow"></i>
                </a>
                <ul class="submenu" id="tasks-submenu">
                    <li><a href="#" class="nav-link" data-target="#manage-tasks" data-metric-id="all">All Criterion Tasks</a></li>
                    <?php if (!empty($all_metrics_in_criterion)): ?>
                        <?php foreach($all_metrics_in_criterion as $metric): ?>
                            <li><a href="#" class="nav-link" data-target="#manage-tasks" data-metric-id="<?php echo $metric['id']; ?>"><?php echo htmlspecialchars($metric['name']); ?></a></li>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </ul>
            </li>
            <li><a href="#" class="nav-link" data-target="#manage-documents"><span class="link-text"><i class="fas fa-fw fa-paperclip"></i> Manage Metric Documents</span></a></li>
            <li><a href="#" class="nav-link" data-target="#manage-format"><span class="link-text"><i class="fas fa-fw fa-file-word"></i> Manage Task Format</span></a></li>
        </ul>
    </div>
</nav>

<div class="dashboard-container">
    <header class="page-header">
        <button id="hamburger-btn" class="hamburger-menu" aria-label="Open menu" title="Open Menu">
            <i class="fas fa-bars"></i>
        </button>
        <div>
            <h1><i class="fas fa-bullseye"></i> Criterion Lead Dashboard</h1>
            <p>You are responsible for managing all metrics under <strong><?php echo htmlspecialchars($criterion_name); ?></strong>.</p>
        </div>
        <div class="header-actions">
            <div class="notification-container">
                <button id="notification-bell" class="notification-bell">
                    <i class="fas fa-bell"></i>
                    <?php if ($unread_count > 0): ?>
                        <span class="notification-count"><?php echo $unread_count; ?></span>
                    <?php endif; ?>
                </button>
                <div id="notification-dropdown" class="notification-dropdown">
                    <?php if (!empty($notifications)): ?>
                        <?php foreach ($notifications as $notification): ?>
                            <div class="notification-item">
                                <a href="<?php echo htmlspecialchars($notification['link']); ?>" data-id="<?php echo $notification['id']; ?>">
                                    <?php echo htmlspecialchars($notification['message']); ?>
                                </a>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="notification-item">No new notifications</div>
                    <?php endif; ?>
                </div>
            </div>
            <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
    </header>

    <?php if (isset($_SESSION['message'])): ?>
    <div class="message <?php echo $_SESSION['message']['type']; ?>"><?php echo htmlspecialchars($_SESSION['message']['text']); unset($_SESSION['message']); ?></div>
    <?php endif; ?>

    <!-- ==== MAIN CONTENT AREA ==== -->
    <main class="dashboard-content">
        <!-- Section 1: Assign New Tasks -->
        <div id="assign-tasks" class="content-section active">
            <div class="dashboard-section">
                <h2><i class="fas fa-tasks"></i> Assign New Tasks</h2>
                <form action="lead_actions.php" method="POST" class="user-form">
                    <input type="hidden" name="action" value="assign_metrics">
                    <div class="form-column">
                        <div class="form-group">
                            <label>1. Select Metrics</label>
                            <div class="checkbox-list" id="metric-checkbox-list"><?php if (!empty($all_metrics_in_criterion)): foreach($all_metrics_in_criterion as $metric): ?><label data-metric-id="<?php echo $metric['id']; ?>" data-assigned-depts='<?php echo json_encode($metric['assigned_dept_ids']); ?>'><input type="checkbox" name="metric_ids[]" value="<?php echo $metric['id']; ?>"> <?php echo htmlspecialchars($metric['name']); ?></label><?php endforeach; else: ?><p>No metrics found.</p><?php endif; ?></div>
                        </div>
                        <div class="form-group">
                            <label>2. Select Team</label>
                            <div class="faculty-filters">
                                <div class="form-group"><label for="filter_dept">Filter by Department</label><select id="filter_dept" class="form-control"><option value="all">All</option><?php foreach($departments_array as $dept): ?><option value="<?php echo $dept['id']; ?>"><?php echo htmlspecialchars($dept['name']); ?></option><?php endforeach; ?></select></div>
                                <div class="form-group"><label for="filter_role">Filter by Role</label><select id="filter_role" class="form-control"><option value="all">All</option><?php foreach($roles_array as $role): ?><option value="<?php echo $role['id']; ?>"><?php echo htmlspecialchars($role['name']); ?></option><?php endforeach; ?></select></div>
<div class="form-group">
    <label for="filter_job">Filter by Job</label>
    <select id="filter_job" class="form-control">
        <option value="all">All</option>
        <?php foreach($job_descriptions_array as $job): ?>
            <option value="<?php echo htmlspecialchars($job['name']); ?>"><?php echo htmlspecialchars($job['name']); ?></option>
        <?php endforeach; ?>
    </select>
</div>                            </div>
                            <div class="checkbox-list" id="faculty-checkbox-list"></div>
                        </div>
                        <div class="form-group">
                            <label for="due_date">3. Set Due Date</label>
                            <input type="date" name="due_date" id="due_date" required>
                        </div>
                    </div>
                    <div class="form-actions"><button type="submit" class="btn btn-primary"><i class="fas fa-check"></i> Assign Selected Tasks</button></div>
                </form>
            </div>
        </div>

        <!-- Section 2: Manage Assigned Tasks -->
        <div id="manage-tasks" class="content-section">
            <div class="dashboard-section">
                <h2><i class="fas fa-list-check"></i> Current Criterion Tasks</h2>
                <div class="assignments-list-hod" id="task-list-container">
                    <?php if (!empty($grouped_tasks)): ?>
                        <?php foreach ($grouped_tasks as $metric_name => $tasks): ?>
                            <?php $metric_id_for_group = !empty($tasks) ? $tasks[0]['metric_id'] : ''; ?>
                            <div class="metric-group" data-metric-id="<?php echo $metric_id_for_group; ?>">
                                <h3 class="metric-group-header"><?php echo htmlspecialchars($metric_name); ?></h3>
                                <?php foreach ($tasks as $task): ?>
                                    <div class="assignment-item-hod status-<?php echo strtolower(str_replace(' ', '-', $task['status'])); ?>">
                                        <div class="item-main-info"><strong>Task for <?php echo htmlspecialchars($task['faculty_names']); ?></strong><br><small>Due: <?php echo date("d M, Y", strtotime($task['due_date'])); ?></small></div>
                                        <div class="item-status"><span class="status-badge"><?php echo htmlspecialchars($task['status']); ?></span></div>
                                        <div class="item-proofs"><strong style="margin-right:10px;">Proofs:</strong><?php $proof_stmt = $mysqli->prepare("SELECT p.file_path, p.original_filename FROM proofs p JOIN task_assignees ta ON p.task_assignee_id = ta.id WHERE ta.task_id = ?"); if($proof_stmt){ $proof_stmt->bind_param("i", $task['id']); $proof_stmt->execute(); $proofs = $proof_stmt->get_result(); if ($proofs->num_rows > 0) { while($proof = $proofs->fetch_assoc()) { echo '<a href="' . htmlspecialchars($proof['file_path']) . '" class="btn-action btn-download" target="_blank" title="Download"><i class="fas fa-download"></i> ' . htmlspecialchars($proof['original_filename']) . '</a>'; } } else { echo '<span class="no-proof">No Proofs Uploaded</span>'; } $proof_stmt->close(); } ?></div>
                                        <div class="item-actions">
                                            <?php if (in_array($task['status'], ['Submitted', 'In Progress', 'Rejected'])): ?>
                                            <form action="lead_actions.php" method="POST" class="review-form"><input type="hidden" name="action" value="review_task"><input type="hidden" name="task_id" value="<?php echo $task['id']; ?>"><div class="review-controls"><select name="review_decision" class="review-decision-dd" required><option value="" selected>-- Action --</option><option value="Approve">Approve</option><option value="Reject">Reject</option><option value="Reassign">Add/Reassign</option></select><div class="dynamic-control remarks-field" style="display:none;"><textarea name="remarks" placeholder="Add remarks..."></textarea></div><div class="dynamic-control reassign-field" style="display:none;"><label style="font-size: 0.8em;">Add to Task:</label><select name="reassign_ids[]" multiple size="3"><?php foreach($all_users_for_filter as $user): ?><option value="<?php echo $user['id']; ?>"><?php echo htmlspecialchars($user['name']); ?></option><?php endforeach; ?></select><label style="font-size: 0.8em; margin-top: 8px;">New Due Date (Optional):</label><input type="date" name="reassign_due_date" class="form-control-sm"></div><button type="submit" class="btn-submit-review">Submit</button></div></form>
                                            <?php endif; ?>
                                            <form action="lead_actions.php" method="POST" class="delete-form" onsubmit="return confirm('Delete this task permanently?');"><input type="hidden" name="action" value="delete_task"><input type="hidden" name="task_id" value="<?php echo $task['id']; ?>"><button type="submit" class="btn-danger" title="Delete Task"><i class="fas fa-trash-alt"></i></button></form>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endforeach; ?>
                        <p id="no-matching-tasks" style="display:none; text-align:center; padding: 20px;">No tasks match the selected metric.</p>
                    <?php else: ?><p>No tasks are currently active for this criterion.</p><?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Section 3: Manage Standard Metric Documents -->
          <!-- Section 3: Manage Standard Metric Documents -->
          <div id="manage-documents" class="content-section">
             <div class="dashboard-section">
                <!-- ... (keep the 'Add a New Metric' form) ... -->

                <h4><i class="fas fa-paperclip"></i> Current Metric Documents</h4>
                <p>View current metric documents and request updates. Upload a new reference document for a metric to request its replacement. Your request will be sent to the admin for approval.</p>
                
                <!-- Current Metric Documents Table -->
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Metric</th>
                            <th>Current Document</th>
                            <th>Last Updated</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Fetch current metric attachments for this criterion
                        $current_docs_query = "
                            SELECT 
                                m.id as metric_id,
                                m.name as metric_name,
                                ma.file_path,
                                ma.original_filename,
                                ma.uploaded_at
                            FROM metrics m
                            LEFT JOIN metric_attachments ma ON m.id = ma.metric_id
                            WHERE m.criterion_id = ?
                            ORDER BY m.name ASC
                        ";
                        $stmt_current = $mysqli->prepare($current_docs_query);
                        $stmt_current->bind_param("i", $criterion_id_in_charge);
                        $stmt_current->execute();
                        $current_docs_result = $stmt_current->get_result();
                        
                        if ($current_docs_result && $current_docs_result->num_rows > 0):
                            while ($doc = $current_docs_result->fetch_assoc()):
                        ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($doc['metric_name']); ?></strong></td>
                                <td>
                                    <?php if ($doc['file_path']): ?>
                                        <a href="<?php echo htmlspecialchars($doc['file_path']); ?>" target="_blank" class="btn-action btn-download" title="Download Current Document">
                                            <i class="fas fa-file-download"></i> <?php echo htmlspecialchars($doc['original_filename']); ?>
                                        </a>
                                    <?php else: ?>
                                        <span class="text-muted"><i class="fas fa-file"></i> No document uploaded</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($doc['uploaded_at']): ?>
                                        <?php echo date('d M, Y H:i', strtotime($doc['uploaded_at'])); ?>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <button type="button" class="btn btn-primary btn-sm" onclick="openRequestModal(<?php echo $doc['metric_id']; ?>, '<?php echo htmlspecialchars($doc['metric_name']); ?>', '<?php echo htmlspecialchars($doc['original_filename'] ?? ''); ?>')" title="Request Update">
                                        <i class="fas fa-edit"></i> Request Update
                                    </button>
                                </td>
                            </tr>
                        <?php 
                            endwhile;
                        else:
                        ?>
                            <tr>
                                <td colspan="4" style="text-align: center; padding: 30px; color: #666;">
                                    <i class="fas fa-folder-open" style="font-size: 2em; margin-bottom: 10px; display: block; color: #ddd;"></i>
                                    <strong>No metric documents found</strong><br>
                                    <small>There are no documents uploaded for metrics in this criterion yet.</small>
                                </td>
                            </tr>
                        <?php 
                        endif;
                        $stmt_current->close();
                        ?>
                    </tbody>
                </table>

                <!-- NEW: Pending Requests Section -->
                <hr style="margin-top: 30px;">
                <h4 style="margin-top: 20px;"><i class="fas fa-history"></i> Your Document Update Requests</h4>
                
                <!-- NEW: Filter Controls -->
                <div class="approval-filters" style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 20px; display: flex; gap: 20px;">
                    <div class="form-group">
                        <label for="approval_status_filter">Filter by Status:</label>
                        <select id="approval_status_filter" class="form-control">
                            <option value="all">All</option>
                            <option value="Pending">Pending</option>
                            <option value="Approved">Approved</option>
                            <option value="Rejected">Rejected</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="approval_type_filter">Filter by Type:</label>
                        <select id="approval_type_filter" class="form-control">
                            <option value="all">All</option>
                            <option value="metric_attachment">Metric Attachment</option>
                            <option value="criterion_template">Criterion Template</option>
                        </select>
                    </div>
                </div>

                <!-- Request Statistics -->
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px; margin-bottom: 20px;">
                    <div style="background: #fff3cd; border: 1px solid #ffeaa7; border-radius: 6px; padding: 15px; text-align: center;">
                        <div id="pending_count" style="font-size: 1.5rem; font-weight: bold; color: #856404;"><?php echo $approval_stats['Pending']; ?></div>
                        <div style="font-size: 0.9rem; color: #856404;">Pending</div>
                    </div>
                    <div style="background: #d4edda; border: 1px solid #c3e6cb; border-radius: 6px; padding: 15px; text-align: center;">
                        <div id="approved_count" style="font-size: 1.5rem; font-weight: bold; color: #155724;"><?php echo $approval_stats['Approved']; ?></div>
                        <div style="font-size: 0.9rem; color: #155724;">Approved</div>
                    </div>
                    <div style="background: #f8d7da; border: 1px solid #f5c6cb; border-radius: 6px; padding: 15px; text-align: center;">
                        <div id="rejected_count" style="font-size: 1.5rem; font-weight: bold; color: #721c24;"><?php echo $approval_stats['Rejected']; ?></div>
                        <div style="font-size: 0.9rem; color: #721c24;">Rejected</div>
                    </div>
                </div>
                
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Request For</th>
                            <th>Target Metric</th>
                            <th>File Name</th>
                            <th>Status</th>
                            <th>Requested On</th>
                            <th>Reviewed On</th>
                            <th>Admin Remarks</th>
                        </tr>
                    </thead>
                    <tbody id="metric-requests-table-body">
                        <?php if (!empty($all_requests)): ?>
                            <?php foreach (array_filter($all_requests, fn($req) => $req['update_type'] === 'metric_attachment') as $req): ?>
                            <tr class="request-row <?php echo $req['status'] === 'Pending' ? 'pending-row' : ($req['status'] === 'Approved' ? 'approved-row' : 'rejected-row'); ?>" data-status="<?php echo $req['status']; ?>" data-type="metric_attachment">
                                <td>
                                    <span class="badge bg-info" style="font-size: 0.8em;">Metric Attachment</span>
                                </td>
                                <td><strong><?php echo htmlspecialchars($req['target_name']); ?></strong></td>
                                <td>
                                    <a href="<?php echo htmlspecialchars($req['new_file_path']); ?>" target="_blank" class="btn-action btn-download" title="Download Submitted File">
                                        <i class="fas fa-file-download"></i> <?php echo htmlspecialchars($req['original_filename']); ?>
                                    </a>
                                </td>
                                <td>
                                    <span class="status-badge status-<?php echo strtolower($req['status']); ?>" style="padding: 5px 10px; border-radius: 4px; font-size: 0.9em; font-weight: 500;">
                                        <?php echo htmlspecialchars($req['status']); ?>
                                    </span>
                                </td>
                                <td><?php echo date('d M, Y H:i', strtotime($req['requested_at'])); ?></td>
                                <td>
                                    <?php if ($req['status'] !== 'Pending' && $req['reviewed_at']): ?>
                                        <?php echo date('d M, Y H:i', strtotime($req['reviewed_at'])); ?>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if (!empty($req['remarks'])): ?>
                                        <div style="max-width: 200px; word-wrap: break-word;">
                                            <?php echo htmlspecialchars($req['remarks']); ?>
                                        </div>
                                    <?php else: ?>
                                        <span class="text-muted">No remarks</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" style="text-align: center; padding: 30px; color: #666;">
                                    <i class="fas fa-inbox" style="font-size: 2em; margin-bottom: 10px; display: block; color: #ddd;"></i>
                                    <strong>No document requests found</strong><br>
                                    <small>You haven't submitted any metric document update requests yet.</small>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                
                <!-- Request Update Modal -->
                <div id="requestUpdateModal" class="modal" style="display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.4);">
                    <div class="modal-content" style="background-color: #fefefe; margin: 5% auto; padding: 20px; border: 1px solid #888; width: 80%; max-width: 600px; border-radius: 8px;">
                        <div class="modal-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                            <h3><i class="fas fa-edit"></i> Request Document Update</h3>
                            <span class="close" onclick="closeRequestModal()" style="color: #aaa; font-size: 28px; font-weight: bold; cursor: pointer;">&times;</span>
                        </div>
                        
                        <form action="lead_actions.php" method="POST" enctype="multipart/form-data" id="requestUpdateForm">
                            <input type="hidden" name="action" value="upload_metric_attachment">
                            <input type="hidden" name="metric_id" id="modalMetricId">
                            
                            <div class="form-group" style="margin-bottom: 15px;">
                                <label for="modalMetricName"><strong>Metric:</strong></label>
                                <div id="modalMetricName" style="padding: 10px; background: #f8f9fa; border: 1px solid #dee2e6; border-radius: 4px; font-weight: 500;"></div>
                            </div>
                            
                            <div class="form-group" style="margin-bottom: 15px;">
                                <label for="modalCurrentFile"><strong>Current Document:</strong></label>
                                <div id="modalCurrentFile" style="padding: 10px; background: #f8f9fa; border: 1px solid #dee2e6; border-radius: 4px;"></div>
                            </div>
                            
                            <div class="form-group" style="margin-bottom: 15px;">
                                <label for="newDocumentFile"><strong>New Document:</strong> <span style="color: #dc3545;">*</span></label>
                                <input type="file" name="attachment_file" id="newDocumentFile" required 
                                       accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png" 
                                       style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                                <small style="color: #6c757d;">Accepted formats: PDF, DOC, DOCX, XLS, XLSX, JPG, JPEG, PNG (Max 5MB)</small>
                            </div>
                            
                            <div class="form-group" style="margin-bottom: 20px;">
                                <label for="requestReason"><strong>Reason for Update:</strong> <span style="color: #dc3545;">*</span></label>
                                <textarea name="request_reason" id="requestReason" rows="3" required 
                                          placeholder="Please explain why you're requesting this update..." 
                                          style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px; resize: vertical;"></textarea>
                            </div>
                            
                            <div class="modal-actions" style="display: flex; gap: 10px; justify-content: flex-end;">
                                <button type="button" onclick="closeRequestModal()" class="btn btn-secondary" style="padding: 10px 20px;">Cancel</button>
                                <button type="submit" class="btn btn-primary" style="padding: 10px 20px;">
                                    <i class="fas fa-paper-plane"></i> Submit Request
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Section 4: Manage Criterion Task Format -->
        <div id="manage-format" class="content-section">
             <div class="dashboard-section">
                <div class="table-header"><h2><i class="fas fa-file-word"></i> Manage Official Task Format</h2></div>
                <div class="format-management-box">
                    <p>View the current task format template and request updates. Upload a new .docx task format to request its replacement. The request will be sent to the admin for approval.</p>
                    
                    <!-- Current Template Display -->
                    <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                        <h5><i class="fas fa-file-word"></i> Current Task Format Template</h5>
                        <?php
                        // Fetch current criterion template
                        $template_query = "SELECT file_path, original_filename, uploaded_at FROM criterion_templates WHERE criterion_id = ?";
                        $stmt_template = $mysqli->prepare($template_query);
                        $stmt_template->bind_param("i", $criterion_id_in_charge);
                        $stmt_template->execute();
                        $template_result = $stmt_template->get_result();
                        $current_template = $template_result->fetch_assoc();
                        $stmt_template->close();
                        ?>
                        
                        <?php if ($current_template): ?>
                            <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 15px;">
                                <a href="<?php echo htmlspecialchars($current_template['file_path']); ?>" target="_blank" class="btn-action btn-download" title="Download Current Template">
                                    <i class="fas fa-file-download"></i> <?php echo htmlspecialchars($current_template['original_filename']); ?>
                                </a>
                                <span style="color: #6c757d; font-size: 0.9em;">
                                    Last updated: <?php echo date('d M, Y H:i', strtotime($current_template['uploaded_at'])); ?>
                                </span>
                            </div>
                        <?php else: ?>
                            <div style="color: #6c757d; font-style: italic;">
                                <i class="fas fa-file"></i> No template uploaded yet
                            </div>
                        <?php endif; ?>
                        
                        <button type="button" class="btn btn-primary" onclick="openTemplateRequestModal()" title="Request Template Update">
                            <i class="fas fa-edit"></i> Request Template Update
                        </button>
                    </div>

                     <!-- NEW: Pending Requests Section -->
                    <hr style="margin-top: 30px;">
                    <h4 style="margin-top: 20px;"><i class="fas fa-history"></i> Your Template Update Requests</h4>
                    
                    <!-- Request Statistics -->
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px; margin-bottom: 20px;">
                        <div style="background: #fff3cd; border: 1px solid #ffeaa7; border-radius: 6px; padding: 15px; text-align: center;">
                            <div style="font-size: 1.5rem; font-weight: bold; color: #856404;"><?php echo $approval_stats['Pending']; ?></div>
                            <div style="font-size: 0.9rem; color: #856404;">Pending</div>
                        </div>
                        <div style="background: #d4edda; border: 1px solid #c3e6cb; border-radius: 6px; padding: 15px; text-align: center;">
                            <div style="font-size: 1.5rem; font-weight: bold; color: #155724;"><?php echo $approval_stats['Approved']; ?></div>
                            <div style="font-size: 0.9rem; color: #155724;">Approved</div>
                        </div>
                        <div style="background: #f8d7da; border: 1px solid #f5c6cb; border-radius: 6px; padding: 15px; text-align: center;">
                            <div style="font-size: 1.5rem; font-weight: bold; color: #721c24;"><?php echo $approval_stats['Rejected']; ?></div>
                            <div style="font-size: 0.9rem; color: #721c24;">Rejected</div>
                        </div>
                    </div>
                    
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Request For</th>
                                <th>Target Criterion</th>
                                <th>File Name</th>
                                <th>Status</th>
                                <th>Requested On</th>
                                <th>Reviewed On</th>
                                <th>Admin Remarks</th>
                            </tr>
                        </thead>
                        <tbody id="template-requests-table-body">
                            <?php if (!empty($all_requests)): ?>
                                <?php foreach (array_filter($all_requests, fn($req) => $req['update_type'] === 'criterion_template') as $req): ?>
                                <tr class="request-row <?php echo $req['status'] === 'Pending' ? 'pending-row' : ($req['status'] === 'Approved' ? 'approved-row' : 'rejected-row'); ?>" data-status="<?php echo $req['status']; ?>" data-type="criterion_template">
                                    <td>
                                        <span class="badge bg-primary" style="font-size: 0.8em;">Criterion Template</span>
                                    </td>
                                    <td><strong><?php echo htmlspecialchars($req['target_name']); ?></strong></td>
                                    <td>
                                        <a href="<?php echo htmlspecialchars($req['new_file_path']); ?>" target="_blank" class="btn-action btn-download" title="Download Submitted File">
                                            <i class="fas fa-file-download"></i> <?php echo htmlspecialchars($req['original_filename']); ?>
                                        </a>
                                    </td>
                                    <td>
                                        <span class="status-badge status-<?php echo strtolower($req['status']); ?>" style="padding: 5px 10px; border-radius: 4px; font-size: 0.9em; font-weight: 500;">
                                            <?php echo htmlspecialchars($req['status']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo date('d M, Y H:i', strtotime($req['requested_at'])); ?></td>
                                    <td>
                                        <?php if ($req['status'] !== 'Pending' && $req['reviewed_at']): ?>
                                            <?php echo date('d M, Y H:i', strtotime($req['reviewed_at'])); ?>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if (!empty($req['remarks'])): ?>
                                            <div style="max-width: 200px; word-wrap: break-word;">
                                                <?php echo htmlspecialchars($req['remarks']); ?>
                                            </div>
                                        <?php else: ?>
                                            <span class="text-muted">No remarks</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="7" style="text-align: center; padding: 30px; color: #666;">
                                        <i class="fas fa-inbox" style="font-size: 2em; margin-bottom: 10px; display: block; color: #ddd;"></i>
                                        <strong>No template requests found</strong><br>
                                        <small>You haven't submitted any criterion template update requests yet.</small>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    
                    <!-- Template Request Modal -->
                    <div id="templateRequestModal" class="modal" style="display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.4);">
                        <div class="modal-content" style="background-color: #fefefe; margin: 5% auto; padding: 20px; border: 1px solid #888; width: 80%; max-width: 600px; border-radius: 8px;">
                            <div class="modal-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                                <h3><i class="fas fa-file-word"></i> Request Template Update</h3>
                                <span class="close" onclick="closeTemplateRequestModal()" style="color: #aaa; font-size: 28px; font-weight: bold; cursor: pointer;">&times;</span>
                            </div>
                            
                            <form action="lead_actions.php" method="POST" enctype="multipart/form-data" id="templateRequestForm">
                                <input type="hidden" name="action" value="upload_criterion_template">
                                
                                <div class="form-group" style="margin-bottom: 15px;">
                                    <label for="modalCriterionName"><strong>Criterion:</strong></label>
                                    <div id="modalCriterionName" style="padding: 10px; background: #f8f9fa; border: 1px solid #dee2e6; border-radius: 4px; font-weight: 500;"><?php echo htmlspecialchars($criterion_name); ?></div>
                                </div>
                                
                                <div class="form-group" style="margin-bottom: 15px;">
                                    <label for="modalCurrentTemplate"><strong>Current Template:</strong></label>
                                    <div id="modalCurrentTemplate" style="padding: 10px; background: #f8f9fa; border: 1px solid #dee2e6; border-radius: 4px;">
                                        <?php if ($current_template): ?>
                                            <a href="<?php echo htmlspecialchars($current_template['file_path']); ?>" target="_blank" class="btn-action btn-download" title="Download Current Template">
                                                <i class="fas fa-file-download"></i> <?php echo htmlspecialchars($current_template['original_filename']); ?>
                                            </a>
                                        <?php else: ?>
                                            <span class="text-muted"><i class="fas fa-file"></i> No template uploaded yet</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div class="form-group" style="margin-bottom: 15px;">
                                    <label for="newTemplateFile"><strong>New Template:</strong> <span style="color: #dc3545;">*</span></label>
                                    <input type="file" name="template_file" id="newTemplateFile" required 
                                           accept=".docx" 
                                           style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                                    <small style="color: #6c757d;">Only .docx files are accepted (Max 5MB)</small>
                                </div>
                                
                                <div class="form-group" style="margin-bottom: 20px;">
                                    <label for="templateRequestReason"><strong>Reason for Update:</strong> <span style="color: #dc3545;">*</span></label>
                                    <textarea name="request_reason" id="templateRequestReason" rows="3" required 
                                              placeholder="Please explain why you're requesting this template update..." 
                                              style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px; resize: vertical;"></textarea>
                                </div>
                                
                                <div class="modal-actions" style="display: flex; gap: 10px; justify-content: flex-end;">
                                    <button type="button" onclick="closeTemplateRequestModal()" class="btn btn-secondary" style="padding: 10px 20px;">Cancel</button>
                                    <button type="submit" class="btn btn-primary" style="padding: 10px 20px;">
                                        <i class="fas fa-paper-plane"></i> Submit Request
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // ==== HAMBURGER MENU SCRIPT ====
    const hamburgerBtn = document.getElementById('hamburger-btn');
    const closeSidebarBtn = document.getElementById('close-sidebar-btn');
    const sidebar = document.querySelector('.dashboard-sidebar');
    const menuOverlay = document.getElementById('menu-overlay');

    // Debug: Check if elements exist
    console.log('Hamburger button:', hamburgerBtn);
    console.log('Close button:', closeSidebarBtn);
    console.log('Sidebar:', sidebar);
    console.log('Menu overlay:', menuOverlay);

    // Make functions globally accessible
    window.openMenu = function() {
        console.log('Opening menu...');
        if (sidebar) {
            sidebar.classList.add('is-open');
            menuOverlay.classList.add('is-visible');
            console.log('Menu opened successfully');
        } else {
            console.error('Sidebar element not found');
        }
    };

    window.closeMenu = function() {
        console.log('Closing menu...');
        if (sidebar) {
            sidebar.classList.remove('is-open');
            menuOverlay.classList.remove('is-visible');
            console.log('Menu closed successfully');
        }
    };

    if (hamburgerBtn) {
        hamburgerBtn.addEventListener('click', function(e) {
            e.preventDefault();
            window.openMenu();
        });
    } else {
        console.error('Hamburger button not found');
    }

    if (closeSidebarBtn) {
        closeSidebarBtn.addEventListener('click', function(e) {
            e.preventDefault();
            window.closeMenu();
        });
    } else {
        console.error('Close button not found');
    }

    if (menuOverlay) {
        menuOverlay.addEventListener('click', window.closeMenu);
    }

    // Fallback: Add keyboard support for menu
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            window.closeMenu();
        }
    });

    // Test menu functionality on page load
    setTimeout(function() {
        console.log('Testing menu functionality...');
        console.log('Sidebar classes:', sidebar ? sidebar.className : 'Sidebar not found');
        console.log('Menu overlay classes:', menuOverlay ? menuOverlay.className : 'Overlay not found');
    }, 1000);

    // ==== REVISED SCRIPT for Navigation and Filtering ====
    const allNavLinks = document.querySelectorAll('.dashboard-sidebar .nav-link');
    const contentSections = document.querySelectorAll('.dashboard-content .content-section');
    const submenuToggle = document.getElementById('submenu-toggle');
    const tasksSubmenu = document.getElementById('tasks-submenu');

    function filterCurrentTasks() {
        const activeMetricLink = document.querySelector('.dashboard-sidebar .nav-link.active[data-metric-id]');
        const selectedMetric = activeMetricLink ? activeMetricLink.dataset.metricId : 'all';
        const allMetricGroups = document.querySelectorAll('#task-list-container .metric-group');
        let visibleGroups = 0;

        allMetricGroups.forEach(group => {
            const metricId = group.dataset.metricId;
            const metricMatch = (selectedMetric === 'all') || (metricId === selectedMetric);
            if (metricMatch) {
                group.style.display = 'block';
                visibleGroups++;
            } else {
                group.style.display = 'none';
            }
        });

        const noResultsMsg = document.getElementById('no-matching-tasks');
        if (noResultsMsg) {
             const anyTasksExist = document.querySelector('#task-list-container .metric-group');
             noResultsMsg.style.display = (anyTasksExist && visibleGroups === 0) ? 'block' : 'none';
        }
    }

    submenuToggle.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation(); // Prevent closing the menu
        this.classList.toggle('active');
        tasksSubmenu.classList.toggle('open');
    });

    allNavLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.dataset.target;
            
            // Handle URL hash for page reloads
            if (window.location.hash !== targetId) {
                // Use history.pushState to change hash without reloading/jumping
                history.pushState(null, null, targetId);
            }

            const targetSection = document.querySelector(targetId);

            contentSections.forEach(section => section.classList.remove('active'));
            if (targetSection) {
                targetSection.classList.add('active');
            }

            allNavLinks.forEach(navLink => navLink.classList.remove('active'));
            this.classList.add('active');

            if (this.closest('.submenu')) {
                submenuToggle.classList.add('active');
                if (!tasksSubmenu.classList.contains('open')) {
                    tasksSubmenu.classList.add('open');
                }
            } else if (this !== submenuToggle) {
                 submenuToggle.classList.remove('active');
                 tasksSubmenu.classList.remove('open');
            }

            if (this.dataset.metricId) {
                filterCurrentTasks();
            }
            
            if (!this.classList.contains('submenu-parent')) {
                window.closeMenu();
            }
        });
    });

    // ==== MODAL FUNCTIONS ====
    // Metric Document Request Modal
    window.openRequestModal = function(metricId, metricName, currentFileName) {
        document.getElementById('modalMetricId').value = metricId;
        document.getElementById('modalMetricName').textContent = metricName;
        
        if (currentFileName) {
            document.getElementById('modalCurrentFile').innerHTML = '<i class="fas fa-file"></i> ' + currentFileName;
        } else {
            document.getElementById('modalCurrentFile').innerHTML = '<span class="text-muted"><i class="fas fa-file"></i> No document uploaded</span>';
        }
        
        document.getElementById('requestUpdateModal').style.display = 'block';
    };

    window.closeRequestModal = function() {
        document.getElementById('requestUpdateModal').style.display = 'none';
        document.getElementById('requestUpdateForm').reset();
    };

    // Template Request Modal
    window.openTemplateRequestModal = function() {
        document.getElementById('templateRequestModal').style.display = 'block';
    };

    window.closeTemplateRequestModal = function() {
        document.getElementById('templateRequestModal').style.display = 'none';
        document.getElementById('templateRequestForm').reset();
    };

    // Close modals when clicking outside
    window.onclick = function(event) {
        const requestModal = document.getElementById('requestUpdateModal');
        const templateModal = document.getElementById('templateRequestModal');
        
        if (event.target === requestModal) {
            closeRequestModal();
        }
        if (event.target === templateModal) {
            closeTemplateRequestModal();
        }
    };

    // --- NEW: Approval Hub Filtering ---
    const statusFilter = document.getElementById('approval_status_filter');
    const typeFilter = document.getElementById('approval_type_filter');

    const metricTableBody = document.getElementById('metric-requests-table-body');
    const templateTableBody = document.getElementById('template-requests-table-body');
    
    const metricRequestRows = metricTableBody ? metricTableBody.querySelectorAll('.request-row') : [];
    const templateRequestRows = templateTableBody ? templateTableBody.querySelectorAll('.request-row') : [];

    const pendingCountSpan = document.querySelector('#pending_count');
    const approvedCountSpan = document.querySelector('#approved_count');
    const rejectedCountSpan = document.querySelector('#rejected_count');

    function filterApprovalRequests() {
        const selectedStatus = statusFilter.value;
        const selectedType = typeFilter.value;
        let visiblePending = 0;
        let visibleApproved = 0;
        let visibleRejected = 0;

        const filterTable = (rows) => {
            rows.forEach(row => {
                const rowStatus = row.dataset.status;
                const rowType = row.dataset.type;
                const statusMatch = selectedStatus === 'all' || selectedStatus === rowStatus;
                const typeMatch = selectedType === 'all' || selectedType === rowType;

                if (statusMatch && typeMatch) {
                    row.style.display = '';
                    if (rowStatus === 'Pending') visiblePending++;
                    if (rowStatus === 'Approved') visibleApproved++;
                    if (rowStatus === 'Rejected') visibleRejected++;
                } else {
                    row.style.display = 'none';
                }
            });
        };

        if (metricRequestRows.length > 0) filterTable(metricRequestRows);
        if (templateRequestRows.length > 0) filterTable(templateRequestRows);

        // Only update counters if filters are applied, otherwise show original counts
        if (selectedStatus !== 'all' || selectedType !== 'all') {
            if (pendingCountSpan) pendingCountSpan.textContent = visiblePending;
            if (approvedCountSpan) approvedCountSpan.textContent = visibleApproved;
            if (rejectedCountSpan) rejectedCountSpan.textContent = visibleRejected;
        } else {
            // Reset to original PHP-generated counts
            if (pendingCountSpan) pendingCountSpan.textContent = '<?php echo $approval_stats['Pending']; ?>';
            if (approvedCountSpan) approvedCountSpan.textContent = '<?php echo $approval_stats['Approved']; ?>';
            if (rejectedCountSpan) rejectedCountSpan.textContent = '<?php echo $approval_stats['Rejected']; ?>';
        }
    }

    if (statusFilter && typeFilter) {
        statusFilter.addEventListener('change', filterApprovalRequests);
        typeFilter.addEventListener('change', filterApprovalRequests);
        // Initial filter on page load
        filterApprovalRequests();
    }


    const notificationBell = document.getElementById('notification-bell');
    const notificationDropdown = document.getElementById('notification-dropdown');

    if (notificationBell) {
        notificationBell.addEventListener('click', function() {
            notificationDropdown.style.display = notificationDropdown.style.display === 'block' ? 'none' : 'block';
        });

        document.addEventListener('click', function(e) {
            if (!notificationBell.contains(e.target) && !notificationDropdown.contains(e.target)) {
                notificationDropdown.style.display = 'none';
            }
        });

        const notificationLinks = notificationDropdown.querySelectorAll('a');
        notificationLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const notificationId = this.dataset.id;
                fetch('lead_actions.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `action=mark_notification_read&notification_id=${notificationId}`
                }).then(() => {
                    window.location.href = this.href;
                });
            });
        });
    }

    // Function to activate tab based on URL hash
    function activateTabFromHash() {
        const hash = window.location.hash;
        if (hash) {
            const linkToActivate = document.querySelector(`.nav-link[data-target='${hash}']`);
            if (linkToActivate) {
                linkToActivate.click();
            }
        }
    }
    
    // Initial activation on page load
    activateTabFromHash();


    // ==== Assign New Task Section Script (MODIFIED for Job Description) ====
    const facultyData = <?php echo json_encode($all_users_for_filter); ?>;
    const facultyCheckboxList = document.getElementById('faculty-checkbox-list');
    const assignDeptFilter = document.getElementById('filter_dept');
    const assignRoleFilter = document.getElementById('filter_role');
    const assignJobFilter = document.getElementById('filter_job');
    const metricCheckboxList = document.getElementById('metric-checkbox-list');

    function updateMetricAvailability() {
        const selectedDept = parseInt(assignDeptFilter.value, 10);
        metricCheckboxList.querySelectorAll('label').forEach(label => {
            label.querySelector('input').disabled = false;
            if (!isNaN(selectedDept)) {
                const isAssigned = JSON.parse(label.dataset.assignedDepts || '[]').includes(selectedDept);
                label.classList.toggle('disabled-metric', isAssigned);
                label.title = isAssigned ? 'Note: Metric already assigned to this department.' : 'Select to assign this metric.'
            } else {
                label.classList.remove('disabled-metric');
                label.title = 'Select to assign this metric.'
            }
        });
    }

    function populateFacultyList() {
        const selectedDept = assignDeptFilter.value;
        const selectedRole = assignRoleFilter.value;
        const selectedJob = assignJobFilter.value;
        const filteredFaculty = facultyData.filter(user =>
            (selectedDept === 'all' || user.department_id == selectedDept) &&
            (selectedRole === 'all' || user.role_id == selectedRole) &&
            (selectedJob === 'all' || user.job_description == selectedJob)
        );
        facultyCheckboxList.innerHTML = '';
        if (filteredFaculty.length > 0) {
            filteredFaculty.forEach(user => {
                const label = document.createElement('label');
                label.innerHTML = `<input type="checkbox" name="faculty_ids[]" value="${user.id}"> ${user.name}`;
                facultyCheckboxList.appendChild(label)
            });
        } else {
            facultyCheckboxList.innerHTML = '<p>No users match filters.</p>'
        }
        updateMetricAvailability();
    }

    assignDeptFilter.addEventListener('change', populateFacultyList);
    assignRoleFilter.addEventListener('change', populateFacultyList);
    assignJobFilter.addEventListener('change', populateFacultyList);
    populateFacultyList();

    // ==== Review Form Dynamic Controls (Unchanged) ====
    document.querySelectorAll('.review-decision-dd').forEach(dd=>{dd.addEventListener('change',function(){const form=this.closest('.review-form');const remarksField=form.querySelector('.remarks-field');const reassignField=form.querySelector('.reassign-field');remarksField.style.display='none';reassignField.style.display='none';remarksField.querySelector('textarea').required=false;if(this.value==='Reject'){remarksField.style.display='block';remarksField.querySelector('textarea').required=true}else if(this.value==='Reassign'){remarksField.style.display='block';reassignField.style.display='block'}else if(this.value==='Approve'){remarksField.style.display='block'}})});
});
</script>

<?php require_once 'includes/footer.php'; ?>